package nts.gul.mail.send.strategy.impls;

import javax.mail.Session;

import lombok.RequiredArgsConstructor;
import lombok.val;
import nts.gul.mail.send.MailToSend;
import nts.gul.mail.send.exceptions.FailedAuthenticateException;
import nts.gul.mail.send.exceptions.FailedConnectSmtpServerException;
import nts.gul.mail.send.strategy.Mailer;
import nts.gul.mail.send.strategy.helper.SendMailProperties;
import nts.gul.mail.send.strategy.helper.SendMailUtil;
import nts.gul.misc.ServerLocator;

@RequiredArgsConstructor
public class NoAuthenticationMailer implements Mailer {

	private final ServerLocator smtpServer;
	
	private final int secondsToTimeout;

	@Override
	public void send(MailToSend mail)
			throws FailedConnectSmtpServerException, FailedAuthenticateException {
		
		val session = Session.getInstance(new SendMailProperties(this.smtpServer, this.secondsToTimeout), null);
		session.setDebug(Mailer.DEBUG_MODE);
		
		SendMailUtil.send(session, mail);
	}

}

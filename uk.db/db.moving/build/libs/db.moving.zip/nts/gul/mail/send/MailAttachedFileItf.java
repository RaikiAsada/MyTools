package nts.gul.mail.send;

import java.io.InputStream;

public interface MailAttachedFileItf {

	InputStream getInputStream();
	String getName();
}

package nts.gul.mail.send.strategy;

import nts.gul.mail.send.setting.SendMailSetting;
import nts.gul.mail.send.strategy.impls.ImapBeforeSmtpMailer;
import nts.gul.mail.send.strategy.impls.NoAuthenticationMailer;
import nts.gul.mail.send.strategy.impls.PopBeforeSmtpMailer;
import nts.gul.mail.send.strategy.impls.SmtpAuthCramMd5Mailer;
import nts.gul.mail.send.strategy.impls.SmtpAuthLoginMailer;
import nts.gul.mail.send.strategy.impls.SmtpAuthPlainMailer;

public class MailerFactory {

	public static Mailer create(SendMailSetting setting) {
		
		switch (setting.getAuthenticationMethod()) {
		case NONE:
			return new NoAuthenticationMailer(
					setting.getSmtpServer(),
					setting.getSecondsToTimeout());
		case POP_BEFORE_SMTP:
			return new PopBeforeSmtpMailer(
					setting.getSmtpServer(),
					setting.getAuthenticationServer().get(),
					setting.getAuthenticationAccount().get(),
					setting.getSecondsToTimeout());
		case IMAP_BEFORE_SMTP:
			return new ImapBeforeSmtpMailer(
					setting.getSmtpServer(),
					setting.getAuthenticationServer().get(),
					setting.getAuthenticationAccount().get(),
					setting.getSecondsToTimeout());
		case SMTP_AUTH_LOGIN:
			return new SmtpAuthLoginMailer(
					setting.getSmtpServer(),
					setting.getAuthenticationAccount().get(),
					setting.getEncryptionType().get(),
					setting.getSecondsToTimeout());
		case SMTP_AUTH_PLAIN:
			return new SmtpAuthPlainMailer(
					setting.getSmtpServer(),
					setting.getAuthenticationAccount().get(),
					setting.getEncryptionType().get(),
					setting.getSecondsToTimeout());
		case SMTP_AUTH_MD5:
			return new SmtpAuthCramMd5Mailer(
					setting.getSmtpServer(),
					setting.getAuthenticationAccount().get(),
					setting.getSecondsToTimeout());
		default:
			throw new RuntimeException("unknown method: " + setting.getAuthenticationMethod());
		}
	}
}

package nts.gul.mail.send.strategy.impls;

import org.apache.geronimo.javamail.authentication.AuthenticatorFactory;

import lombok.RequiredArgsConstructor;
import lombok.val;
import nts.gul.mail.send.MailToSend;
import nts.gul.mail.send.exceptions.FailedAuthenticateException;
import nts.gul.mail.send.exceptions.FailedConnectAuthServerException;
import nts.gul.mail.send.exceptions.FailedConnectSmtpServerException;
import nts.gul.mail.send.setting.SendMailAuthenticationAccount;
import nts.gul.mail.send.setting.SendMailEncryptedConnectionType;
import nts.gul.mail.send.strategy.Mailer;
import nts.gul.mail.send.strategy.helper.SendMailProperties;
import nts.gul.mail.send.strategy.helper.SendMailUtil;
import nts.gul.misc.ServerLocator;

@RequiredArgsConstructor
public class SmtpAuthPlainMailer implements Mailer {

	private final ServerLocator smtpServer;
	
	private final SendMailAuthenticationAccount account;
	
	private final SendMailEncryptedConnectionType encryptionType;

	private final int secondsToTimeout;

	@Override
	public void send(MailToSend mail)
			throws FailedConnectSmtpServerException, FailedAuthenticateException, FailedConnectAuthServerException {

        val session = SendMailUtil.createSessionWithAuthentication(this.setupProperties(), this.account);
        SendMailUtil.sendWithAuthentication(session, mail);
	}

    private SendMailProperties setupProperties() {
        
        val property = new SendMailProperties(this.smtpServer, this.secondsToTimeout);

        property.setProperty("mail.smtp.auth", true);
        property.setProperty("mail.smtp.auth.plain", true);
        property.setProperty("mail.smtp.auth.mechanisms", AuthenticatorFactory.AUTHENTICATION_PLAIN);
        
        SendMailUtil.setupPropertiesForEncryption(property, this.encryptionType, this.smtpServer);
        
        return property;
    }

}

package nts.gul.mail.send;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;

/**
 * Contents of mail
 */
@Getter
public class MailContents {

	/** subject of mail */
	private final String subject;
	
	/** body message of mail */
	private final String body;
	
	/** attached files */
	private final List<MailAttachedFileItf> attachedFiles = new ArrayList<>();
	
	/**
	 * Constructs.
	 * @param subject subject
	 * @param body body
	 */
	public MailContents(String subject, String body) {
		this.subject = subject;
		this.body = body;
	}
	
	/**
	 * Constructs with attached files.
	 * @param subject subject
	 * @param body body
	 * @param attachedFiles attached files
	 */
	public MailContents(String subject, String body, List<MailAttachedFileItf> attachedFiles) {
		this(subject, body);
		this.attachedFiles.addAll(attachedFiles);
	}
	
	/**
	 * Returns true if attached files exist.
	 * @return true if attached files exist
	 */
	public boolean hasAttachedFiles() {
		return !this.attachedFiles.isEmpty();
	}
}


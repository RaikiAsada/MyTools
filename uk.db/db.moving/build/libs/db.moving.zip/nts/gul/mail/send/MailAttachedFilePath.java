package nts.gul.mail.send;

import java.io.InputStream;
import java.nio.file.Path;

import lombok.Value;
import nts.gul.file.FileUtil;

@Value
public class MailAttachedFilePath implements MailAttachedFileItf {

	/** path to file */
	private final Path path;
	
	/** name of file */
	private final String name;
	
	@Override
	public InputStream getInputStream() {
		return FileUtil.NoCheck.newInputStream(this.path);
	}

}

package nts.gul.mail.send.strategy;

import nts.gul.mail.send.MailToSend;
import nts.gul.mail.send.exceptions.FailedAuthenticateException;
import nts.gul.mail.send.exceptions.FailedConnectAuthServerException;
import nts.gul.mail.send.exceptions.FailedConnectSmtpServerException;

public interface Mailer {
	
	public static boolean DEBUG_MODE = true;

	void send(MailToSend mail)
			throws FailedConnectSmtpServerException,
			FailedConnectAuthServerException,
			FailedAuthenticateException;
}

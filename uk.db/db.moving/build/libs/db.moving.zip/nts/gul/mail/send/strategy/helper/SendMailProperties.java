package nts.gul.mail.send.strategy.helper;

import java.util.Properties;

import nts.gul.misc.ServerLocator;

/**
 * SendMailProperties
 */
public class SendMailProperties extends Properties {
    
    /** serialVersionUID */
	private static final long serialVersionUID = 1L;

    /**
     * Set SMTP server settings.
     * 
     * @param smtpServer smtpServer
     */
    public SendMailProperties(ServerLocator smtpServer, int secondsToTimeout) {
        this.setProperty("mail.smtp.host", smtpServer.getAddress());
        this.setProperty("mail.smtp.port", smtpServer.getPort());
        this.setProperty("mail.smtp.connectiontimeout", secondsToTimeout * 1000);
        this.setProperty("mail.smtp.timeout", secondsToTimeout * 1000);
    }
    
	/**
     * Set property as int.
     * 
     * @param key key
     * @param value value
     */
    public void setProperty(String key, int value) {
        this.setProperty(key, Integer.toString(value));
    }
    
    /**
     * Set property as boolean.
     * 
     * @param key key
     * @param value value
     */
    public void setProperty(String key, boolean value) {
        this.setProperty(key, Boolean.toString(value));
    }
}

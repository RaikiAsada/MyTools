package nts.gul.mail.send.setting;

/**
 * Encrypted connection types to send mail
 */
public enum SendMailEncryptedConnectionType {

	/** No encription */
	NONE,
	
	/** SSL */
	SSL,
	
	/** TLS */
	TLS,
}

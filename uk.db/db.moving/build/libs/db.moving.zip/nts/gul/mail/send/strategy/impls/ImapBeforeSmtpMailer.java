package nts.gul.mail.send.strategy.impls;

import nts.gul.mail.send.setting.SendMailAuthenticationAccount;
import nts.gul.misc.ServerLocator;

public class ImapBeforeSmtpMailer extends AnyBeforeSmtpMailerBase {

	public ImapBeforeSmtpMailer(
			ServerLocator smtpServer,
			ServerLocator authServer,
			SendMailAuthenticationAccount account,
			int secondsToTimeout) {
		super(smtpServer, authServer, account, secondsToTimeout);
	}

	@Override
	protected String getStoreName() {
		return "imap";
	}

}

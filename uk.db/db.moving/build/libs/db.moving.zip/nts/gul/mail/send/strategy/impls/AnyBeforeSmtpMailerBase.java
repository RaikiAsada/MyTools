package nts.gul.mail.send.strategy.impls;

import java.net.ConnectException;
import java.net.UnknownHostException;

import javax.mail.AuthenticationFailedException;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

import lombok.RequiredArgsConstructor;
import lombok.val;
import nts.gul.mail.send.MailToSend;
import nts.gul.mail.send.exceptions.FailedAuthenticateException;
import nts.gul.mail.send.exceptions.FailedConnectAuthServerException;
import nts.gul.mail.send.exceptions.FailedConnectSmtpServerException;
import nts.gul.mail.send.setting.SendMailAuthenticationAccount;
import nts.gul.mail.send.strategy.Mailer;
import nts.gul.mail.send.strategy.helper.SendMailProperties;
import nts.gul.mail.send.strategy.helper.SendMailUtil;
import nts.gul.misc.ServerLocator;

@RequiredArgsConstructor
public abstract class AnyBeforeSmtpMailerBase implements Mailer {

	private final ServerLocator smtpServer;
	
	private final ServerLocator authServer;
	
	private final SendMailAuthenticationAccount account;

	private final int secondsToTimeout;

	@Override
	public void send(MailToSend mail)
			throws FailedConnectSmtpServerException,
			FailedConnectAuthServerException,
			FailedAuthenticateException {
		
		val session = Session.getInstance(new SendMailProperties(this.smtpServer, this.secondsToTimeout), null);
		session.setDebug(Mailer.DEBUG_MODE);
		
		this.connectStore(session);
        SendMailUtil.sendWithAuthentication(session, mail);
	}

	protected abstract String getStoreName();
	
	private void connectStore(Session session)
			throws FailedConnectAuthServerException, FailedAuthenticateException {
		try {
            Store store = session.getStore(this.getStoreName());
            store.connect(
            		this.authServer.getAddress(),
            		this.authServer.getPort(),
            		this.account.getName(),
            		this.account.getPassword());
		} catch (AuthenticationFailedException e) {
			if (e.getMessage().contains("invalid password")) { // case: invalid password or even when invalid accout name
				throw new FailedAuthenticateException();
			} else if (e.getMessage().contains("failed to connect")) { // case: server address is null or empty
				throw new FailedConnectAuthServerException();
			}
			throw new RuntimeException(e);
        } catch (MessagingException e) {
        	val next = e.getNextException();
        	if (next instanceof UnknownHostException 			// case: strange string
        			|| next instanceof ConnectException) { 		// case: valid address string but cannot connect
        		throw new FailedConnectAuthServerException();
        	}
            throw new RuntimeException(e);
        }
	}
}

package nts.gul.mail.send.strategy.helper;

import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.util.Properties;

import javax.mail.AuthenticationFailedException;
import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import org.apache.geronimo.javamail.transport.smtp.SMTPTransport;

import lombok.val;
import nts.gul.mail.send.MailToSend;
import nts.gul.mail.send.exceptions.FailedAuthenticateException;
import nts.gul.mail.send.exceptions.FailedConnectAuthServerException;
import nts.gul.mail.send.exceptions.FailedConnectSmtpServerException;
import nts.gul.mail.send.setting.SendMailAuthenticationAccount;
import nts.gul.mail.send.setting.SendMailEncryptedConnectionType;
import nts.gul.mail.send.strategy.Mailer;
import nts.gul.misc.ServerLocator;

public class SendMailUtil {

	public static Session createSessionWithAuthentication(Properties properties, SendMailAuthenticationAccount account) {
		val session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(account.getName(), account.getPassword());
            }
        });

		session.setDebug(Mailer.DEBUG_MODE);
		
		return session;
	}
	
	public static void send(Session session, MailToSend mail)
			throws FailedConnectSmtpServerException {
		
        try {
			SMTPTransport.send(MimeMessageBuilder.withSendOptions(
					session,
					mail.buildSendOptions(),
					mail.contents()));
        } catch (MessagingException e) {
    		throw new FailedConnectSmtpServerException();
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
		}
	}

	public static void sendWithAuthentication(Session session, MailToSend mail)
			throws FailedAuthenticateException, FailedConnectAuthServerException {
		
        try {
			SMTPTransport.send(MimeMessageBuilder.withSendOptions(
					session,
					mail.buildSendOptions(),
					mail.contents()));
        } catch (AuthenticationFailedException e) {
        	throw new FailedAuthenticateException();
        } catch (MessagingException e) {
        	val next = e.getNextException();
        	if (next instanceof SocketTimeoutException) {
        		throw new FailedConnectAuthServerException();
        	}
        	
            throw new RuntimeException(e);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
		}
	}

	public static void setupPropertiesForEncryption(
			SendMailProperties property,
			SendMailEncryptedConnectionType encryptionType,
			ServerLocator smtpServer) {
		switch (encryptionType) {
        case SSL:
        	SendMailUtil.setPropertiesForSSL(property, smtpServer);
        	break;
        case TLS:
        	SendMailUtil.setPropertiesForTLS(property, smtpServer);
        case NONE:
        	break;
    	default:
        	throw new RuntimeException("unknown encryption type: " + encryptionType);
        }
	}
	
	private static void setPropertiesForSSL(SendMailProperties property, ServerLocator smtpServer) {
		property.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		property.setProperty("mail.smtp.socketFactory.fallback", false);
		property.setProperty("mail.smtp.socketFactory.port", smtpServer.getPort());
		property.setProperty("mail.protocol.ssl.trust",smtpServer.getAddress());
	}

	private static void setPropertiesForTLS(SendMailProperties property, ServerLocator smtpServer) {
		property.setProperty("mail.smtp.socketFactory.fallback", false);
		property.setProperty("mail.smtp.socketFactory.port", smtpServer.getPort());
		property.setProperty("mail.smtp.starttls.enable", true);
	}

}

package nts.gul.mail.send.strategy.helper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.activation.DataSource;

/**
 * InputStreamDataSource
 */
public class InputStreamDataSource implements DataSource {

	/** buffer */
    private ByteArrayOutputStream buffer = new ByteArrayOutputStream();

    /**
     * constructor.
     * 
     * @param inputStream InputStream
     */
    public InputStreamDataSource(InputStream inputStream) {
        //InputStream to ByteArrayOutputStream
    	try {
            int nRead;
            byte[] data = new byte[16384];
            while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }

            buffer.flush();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getContentType() {
        return "*/*";
    }

    @Override
    public InputStream getInputStream() throws IOException {
    	//DataSource作成時、複数回getInputStream()を呼び出すが、常に新しいオブジェクトを返すため instance生成
        return new ByteArrayInputStream(buffer.toByteArray());
    }

    @Override
    public String getName() {
        return "InputStreamDataSource";
    }

    @Override
    public OutputStream getOutputStream() throws IOException {
        throw new IOException("Read-only data");
    }
}

package nts.gul.mail.send;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.Value;

@Value
public class MailSendOptions {
	
	private final String from;

	private final List<String> replyToList;
	
	private final List<String> toList;
	
	private final List<String> ccList;
	
	private final List<String> bccList;
	
	public static Builder builder(String from) {
		return new Builder(from);
	}

	@SneakyThrows
	public void fillInto(MimeMessage message) {
		message.setFrom(new InternetAddress(from));
		message.setReplyTo(this.getReplyToArray());

		if (!this.toList.isEmpty()) {
			message.setRecipients(RecipientType.TO, this.getToArray());
		}

		if (!this.ccList.isEmpty()) {
			message.setRecipients(RecipientType.CC, this.getCcArray());
		}
		
		if (!this.bccList.isEmpty()) {
			message.setRecipients(RecipientType.BCC, this.getBccArray());
		}
	}
	
	private InternetAddress[] getReplyToArray() {
		return this.replyToList.stream().map(MailSendOptions::addr).toArray(InternetAddress[]::new);
	}
	
	private InternetAddress[] getToArray() {
		return this.toList.stream().map(MailSendOptions::addr).toArray(InternetAddress[]::new);
	}
	
	private InternetAddress[] getCcArray() {
		return this.ccList.stream().map(MailSendOptions::addr).toArray(InternetAddress[]::new);
	}
	
	private InternetAddress[] getBccArray() {
		return this.bccList.stream().map(MailSendOptions::addr).toArray(InternetAddress[]::new);
	}
	
	@RequiredArgsConstructor
	public static class Builder {
		
		private final String from;
		private final List<String> replyToList = new ArrayList<>();
		private final List<String> toList = new ArrayList<>();
		private final List<String> ccList = new ArrayList<>();
		private final List<String> bccList = new ArrayList<>();
		
		public Builder addReplyTo(String replyTo) {
			this.replyToList.add(replyTo);
			return this;
		}
		
		public Builder addAllReplyTo(Collection<String> replyTo) {
			this.replyToList.addAll(replyTo);
			return this;
		}
		
		public Builder addTo(String to) {
			this.toList.add(to);
			return this;
		}
		
		public Builder addAllTo(Collection<String> to) {
			this.toList.addAll(to);
			return this;
		}
		
		public Builder addCc(String cc) {
			this.ccList.add(cc);
			return this;
		}
		
		public Builder addAllCc(Collection<String> cc) {
			this.ccList.addAll(cc);
			return this;
		}
		
		public Builder addBcc(String bcc) {
			this.bccList.add(bcc);
			return this;
		}
		
		public Builder addAllBcc(Collection<String> bcc) {
			this.bccList.addAll(bcc);
			return this;
		}
		
		public MailSendOptions build() {
			return new MailSendOptions(from, replyToList, toList, ccList, bccList);
		}
	}
	
	@SneakyThrows
	private static InternetAddress addr(String address) {
		return new InternetAddress(address);
	}
}

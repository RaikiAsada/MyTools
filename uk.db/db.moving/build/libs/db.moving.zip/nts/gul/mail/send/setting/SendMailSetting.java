package nts.gul.mail.send.setting;

import java.util.Optional;

import lombok.Value;
import nts.gul.misc.ServerLocator;

@Value
public class SendMailSetting {

	/** SMTP server */
	private final ServerLocator smtpServer;
	
	/** seconds to timeout connection to server */
	private final int secondsToTimeout;

	/** authentication method */
	private final SendMailAuthenticationMethod authenticationMethod;
	
	/** authentication account */
	private final Optional<SendMailAuthenticationAccount> authenticationAccount;
	
	/** authentication server */
	private final Optional<ServerLocator> authenticationServer;
	
	/** encryption type */
	private final Optional<SendMailEncryptedConnectionType> encryptionType;
}

package nts.gul.mail.send;

import java.util.Optional;

/**
 * Mail to send.
 */
public interface MailToSend {
	
	default Optional<MailSendOptions> sendOptions() {
		return Optional.empty();
	}
	
	default MailSendOptions buildSendOptions() {
		return this.sendOptions().orElseGet(() -> MailSendOptions
				.builder(this.originator().mailAddress())
				.addTo(this.recipient().mailAddress())
				.build());
	}
	
	/**
	 * Returns originator.
	 * @return originator
	 */
	default MailOriginator originator() {
		throw new RuntimeException("originator is not implemented!!");
	}
	
	/**
	 * Returns recipient.
	 * @return recipient
	 */
	default MailRecipient recipient() {
		throw new RuntimeException("recipient is not implemented!!");
	}

	/**
	 * Returns contents.
	 * @return contents
	 */
	MailContents contents();
}

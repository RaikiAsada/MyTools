package nts.gul.mail.send;

import java.io.InputStream;

import lombok.Value;

/**
 * Attached file of mail
 */
@Value
public class MailAttachedFile implements MailAttachedFileItf {

	/** input stream of file*/
	private final InputStream inputStream;
	
	/** name of file */
	private final String name;
}

package nts.gul.mail.send.setting;

import lombok.Value;

/**
 * Authentication account to send mail.
 */
@Value
public class SendMailAuthenticationAccount {

	/** name */
	private final String name;
	
	/** password */
	private final String password;
}

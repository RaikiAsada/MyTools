package nts.gul.mail.send.exceptions;

public class FailedAuthenticateException extends Exception {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

}

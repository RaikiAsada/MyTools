package nts.gul.mail.send.strategy.impls;

import nts.gul.mail.send.setting.SendMailAuthenticationAccount;
import nts.gul.misc.ServerLocator;

public class PopBeforeSmtpMailer extends AnyBeforeSmtpMailerBase {

	public PopBeforeSmtpMailer(
			ServerLocator smtpServer,
			ServerLocator authServer,
			SendMailAuthenticationAccount account,
			int secondsToTimeout) {
		super(smtpServer, authServer, account, secondsToTimeout);
	}

	@Override
	protected String getStoreName() {
		return "pop3";
	}

}

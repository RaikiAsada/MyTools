package nts.gul.mail.send.strategy.helper;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

import lombok.Getter;
import lombok.val;
import nts.gul.datetime.DateTimeUtility;
import nts.gul.mail.send.MailAttachedFileItf;
import nts.gul.mail.send.MailContents;
import nts.gul.mail.send.MailSendOptions;

public class MimeMessageBuilder {

    /**
     * MAIL_ENCODING
     */
	private static final String MAIL_ENCODING = "UTF-8";

    /**
     * message
     */
    @Getter
    private final MimeMessage message;

    /**
     * Constructs.
     * 
     * @param session session
     */
    MimeMessageBuilder(Session session) {
        this.message = new MimeMessage(session);
    }

    /**
     * Set from.
     * @param from from
     * @throws MessagingException MessagingException
     */
    public MimeMessageBuilder from(String from) throws MessagingException {
        this.message.setFrom(new InternetAddress(from));
        return this;
    }

    /**
     * Set to.
     * @param to to
     * @throws MessagingException MessagingException
     */
    public MimeMessageBuilder to(String to) throws MessagingException {
        InternetAddress[] addresses = { new InternetAddress(to) };
        this.message.setRecipients(Message.RecipientType.TO, addresses);
        return this;
    }
    
    public MimeMessageBuilder sendOptions(MailSendOptions options) {
    	options.fillInto(this.message);
    	return this;
    }
    
    public MimeMessageBuilder contents(MailContents contents) throws MessagingException, UnsupportedEncodingException {

        this.subject(contents.getSubject());

        if (contents.hasAttachedFiles()) {
        	this.body(contents.getBody(), contents.getAttachedFiles());
        } else {
        	this.body(contents.getBody());
        }
        
        return this;
    }

    /**
     * Set subject.
     * @param subject subject
     * @throws MessagingException MessagingException
     */
    public MimeMessageBuilder subject(String subject) throws MessagingException {
        this.message.setSubject(subject, MAIL_ENCODING);
        return this;
    }

    /**
     * Set sent date now.
     * 
     * @throws MessagingException MessagingException
     */
    public MimeMessageBuilder sendingNow() throws MessagingException {
        this.message.setSentDate(DateTimeUtility.nowAsOldDate());
        return this;
    }

    /**
     * Set body.
     * 
     * @param body body
     * @throws MessagingException MessagingException
     */
    public MimeMessageBuilder body(String body) throws MessagingException {
        this.message.setText(fixBodyTextToAvoidJavaMailBug(body), MAIL_ENCODING);
        return this;
    }

    /**
     * Set body with attached files.
     * 
     * @param body body
     * @param attachedFiles attached files.
     * @throws MessagingException MessagingException
     * @throws UnsupportedEncodingException UnsupportedEncodingException
     */
    public MimeMessageBuilder body(String body, List<MailAttachedFileItf> attachedFiles)
            throws MessagingException, UnsupportedEncodingException {

        Multipart multiPart = new MimeMultipart();

        // text body part
        {
	        MimeBodyPart text = new MimeBodyPart();
	        text.setText(fixBodyTextToAvoidJavaMailBug(body), MAIL_ENCODING);
	        multiPart.addBodyPart(text);
        }

        // attach body part
        for (val file : attachedFiles) {
            MimeBodyPart attach = new MimeBodyPart();
            attach.setDataHandler(new DataHandler(new InputStreamDataSource(file.getInputStream())));
            attach.setFileName(MimeUtility.encodeWord(file.getName(), "utf-8", "B"));
            
            multiPart.addBodyPart(attach);
        }

        this.message.setContent(multiPart);
        
        return this;
    }

    /**
     * 単一の宛先に送るメールを構築する
     * 
     * @param session session
     * @param from from
     * @param to to
     * @param contents contents
     * @return MimeMessage
     * @throws MessagingException
     * @throws UnsupportedEncodingException
     */
    public static MimeMessage singleTo(Session session, String from, String to, MailContents contents)
            throws MessagingException, UnsupportedEncodingException {
    	
    	return withSendOptions(session, MailSendOptions.builder(from).addTo(to).build(), contents);
    }
    
    /**
     * 複雑な送信設定（CCとかReplyToとか）を使うメールを構築する
     * 
     * @param session
     * @param sendOptions
     * @param contents
     * @return
     */
    public static MimeMessage withSendOptions(Session session, MailSendOptions sendOptions, MailContents contents) 
            throws MessagingException, UnsupportedEncodingException {

        return new MimeMessageBuilder(session)
        		.sendOptions(sendOptions)
        		.sendingNow()
        		.contents(contents)
        		.getMessage();
        
    }

    /**
     * 本文が日本語で終わると末尾に w) という文字列が表示されてしまうJavaMailのバグを回避する
     * @param originalBody body
     * @return 補正後のbody
     */
    private static String fixBodyTextToAvoidJavaMailBug(String originalBody) {
    	return originalBody + " ";
    }
}

package nts.gul.mail.send;

/**
 * Recipient
 */
public interface MailRecipient {

	/**
	 * Returns E-mail address
	 * @return E-mail address
	 */
	String mailAddress();
}

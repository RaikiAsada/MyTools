package nts.gul.mail.send.setting;

/**
 * Methods to authenticate to send mail
 */
public enum SendMailAuthenticationMethod {
	
	/** No Authentication */
    NONE,

    /** POP before SMTP */
    POP_BEFORE_SMTP,
    
    /** IMAP before SMTP */
    IMAP_BEFORE_SMTP,
    
    /** SMTP AUTH LOGIN */
    SMTP_AUTH_LOGIN,
    
    /** SMTP AUTH PLAIN */
    SMTP_AUTH_PLAIN,
    
    /** SMTP AUTH CRAM-MD5 */
    SMTP_AUTH_MD5,
}

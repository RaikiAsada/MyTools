package nts.gul.mail.send.exceptions;

public class FailedConnectAuthServerException extends Exception {

	/**　serialVersionUID　*/
	private static final long serialVersionUID = 1L;

}

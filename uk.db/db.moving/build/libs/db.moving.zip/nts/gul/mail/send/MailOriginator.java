package nts.gul.mail.send;

/**
 * Originator
 */
public interface MailOriginator {

	/**
	 * Returns E-mail address
	 * @return E-mail address
	 */
	String mailAddress();
}

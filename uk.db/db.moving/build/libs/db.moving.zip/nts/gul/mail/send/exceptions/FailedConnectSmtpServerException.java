package nts.gul.mail.send.exceptions;

public class FailedConnectSmtpServerException extends Exception {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

}

package nts.gul.excel;

@SuppressWarnings("unused")
public class ExcelFileTypeException extends Exception {

	/** */
	private static final long serialVersionUID = 1L;
	
	private Exception base;
	
	public ExcelFileTypeException(Exception e){
		this.base = e;
	}
	
	@Override
	public String toString(){
		return "FILE IS NOT XLSX FILE";
	}
}

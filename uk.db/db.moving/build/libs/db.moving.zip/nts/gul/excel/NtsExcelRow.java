package nts.gul.excel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class NtsExcelRow {

	private Map<Integer, NtsExcelCell> cells;
	
	private final int row;
	
	public NtsExcelRow(int row){
		this.cells = new HashMap<>();
		this.row = row;
	}
	
	private NtsExcelRow(Map<Integer, NtsExcelCell> cells, int row){
		this.cells = cells;
		this.row = row;
	}
	
	public List<NtsExcelCell> cells(){
		return this.cells.values().stream().map(c -> c.clone()).collect(Collectors.toList());
	}
	
	public void addCell(NtsExcelCell cell){
		this.cells.put(cell.getColumn(), cell);
	}
	
	public NtsExcelRow clone(){
		return new NtsExcelRow(this.cells.values().stream().collect(Collectors.toMap(c -> c.getColumn(), c -> c.clone())), this.row);
	}
	
	public NtsExcelCell getCellAt(int column) {
		return this.cells.get(column);
	}
	
	public int getRow(){
		return this.row;
	}
}

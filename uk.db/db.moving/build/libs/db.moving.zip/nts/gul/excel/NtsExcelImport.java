package nts.gul.excel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import lombok.Getter;


public class NtsExcelImport {

	@Getter
	List<NtsExcelHeader> headers;
	
	Map<Integer, NtsExcelRow> rows;
	
	public NtsExcelImport(){
		this.headers = new ArrayList<>();
		this.rows = new HashMap<>();
	}
	
	public List<NtsExcelHeader> headers(){
		return this.headers.stream().map(c -> c.clone()).collect(Collectors.toList());
	}
	
	public void addHeader(NtsExcelHeader cell){
		this.headers.add(cell);
	}
	
	public List<NtsExcelRow> rows(){
		return this.rows.values().stream().map(c -> c.clone()).collect(Collectors.toList());
	}
	
	public void addRow(NtsExcelRow row){
		this.rows.put(row.getRow(), row);
	}
	
	public Optional<NtsExcelHeader> getHeaderAt(int column){
		return headers.stream().filter(c -> c.getFirstColumnIndex() <= column && c.getLastColumnIndex() >= column).findFirst();
	}
	
	public NtsExcelRow getRowAt(int row){
		return rows.get(row);
	}
	
	public void addInRow(int row, NtsExcelCell cell){
		if(rows.get(row) == null){
			rows.put(row, new NtsExcelRow(row));
		}
		rows.get(row).addCell(cell);
	}
	
	public boolean isExistPairHeader(){
		return headers.stream().anyMatch(c -> c.isPairHeader());
	}
	
	public boolean addHeaderIfCan(NtsExcelHeader header){
		if(isHeaderCanPut(header)){
			addHeader(header);
			return true;
		}
		
		return false;
	}
	
	private boolean isHeaderCanPut(NtsExcelHeader header){
		return headers.isEmpty() || headers.stream().mapToInt(c -> c.getLastColumnIndex()).max().getAsInt() + 1 == header.getFirstColumnIndex();
	}
}

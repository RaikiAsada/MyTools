package nts.gul.excel;

import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.aspose.cells.BorderType;
import com.aspose.cells.Cell;
import com.aspose.cells.CellBorderType;
import com.aspose.cells.Cells;
import com.aspose.cells.LoadFormat;
import com.aspose.cells.LoadOptions;
import com.aspose.cells.Range;
import com.aspose.cells.Style;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;

import lombok.val;

public class NtsExcelReader {

	public static NtsExcelImport read(InputStream stream) throws ExcelFileTypeException {
		try {
			Workbook workbook = new Workbook(stream, new LoadOptions(LoadFormat.XLSX));
			NtsExcelImport result = processSheet(workbook, 0);

			return result;
		} catch (Exception e) {
			throw new ExcelFileTypeException(e);
		}
	}

	public static Map<String, NtsExcelImport> readAllSheets(InputStream stream) throws ExcelFileTypeException {
		
		Map<String, NtsExcelImport> results = new HashMap<>();
		
		try {
			Workbook workbook = new Workbook(stream, new LoadOptions(LoadFormat.XLSX));
			val sheets = workbook.getWorksheets();
			for (int i = 0; i < sheets.getCount(); i++) {
				val sheet = sheets.get(i);
				results.put(sheet.getName(), processSheet(workbook, i));
			}
		} catch (Exception e) {
			throw new ExcelFileTypeException(e);
		}
		
		return results;
	}

	@SuppressWarnings("unchecked")
	private static NtsExcelImport processSheet(Workbook workbook, int sheetIdx) {
		Worksheet sheet = workbook.getWorksheets().get(sheetIdx);
		Cells cells = sheet.getCells();
		Iterator<Cell> iterator = cells.iterator();

		NtsExcelImport result = new NtsExcelImport();

		int headerRow = -1, startColumn = -1, maxColumn = -1;
		
		while (iterator.hasNext()) {
			Cell cell = iterator.next();
			if (isHaveBorder(cells, cell)) {
				headerRow = cell.getRow();
				startColumn = cell.getColumn();
				break;
			}
		}

		if (headerRow >= 0 && startColumn >= 0) {
			processData(cells, result, headerRow, startColumn, maxColumn);
		}

		return result;
	}

	private static void processData(Cells cells, NtsExcelImport result, int headerRow, int startColumn, int maxColumn) {
		int colIdx = startColumn;
		while (true) {
			Cell cell = cells.get(headerRow, colIdx);
			if (!isHaveBorder(cells, cell)) {
				maxColumn = cell.getColumn();
				break;
			}

			result.addHeaderIfCan(processHeader(cells, headerRow, colIdx, cell));
			colIdx++;
		}
		processRecord(cells, result, startColumn, maxColumn, 
				result.isExistPairHeader() ? headerRow + 2 : headerRow + 1);
	}

	private static NtsExcelHeader processHeader(Cells cells, int headerRow, int colIdx, Cell cell) {
		NtsExcelHeader header = new NtsExcelHeader(NtsExcelCell.initAs(cell, colIdx + 1, headerRow + 1, null, 
																		cell.getStyle().getBackgroundColor().toArgb(),
																		cell.getStyle().getForegroundColor().toArgb()));
		if (cell.isMerged()) {
			Range headerRange = cell.getMergedRange();
			for (int idx = headerRange.getFirstColumn(); 
					idx < headerRange.getFirstColumn() + headerRange.getColumnCount(); idx++) {
				Cell subCell = cells.get(headerRow + 1, idx);
				header.addSubHeader(NtsExcelCell.initAs(subCell, idx + 1, headerRow + 2, null, 
														subCell.getStyle().getBackgroundColor().toArgb(),
														subCell.getStyle().getForegroundColor().toArgb()));
			}
		} else {
			header.syncMainAndSub();
		}
		
		return header;
	}

	private static void processRecord(Cells cells, NtsExcelImport result, int startColumn, int maxColumn, int startRow) {
		while(true){
			if(!isRowRecord(startRow, startColumn, maxColumn, cells)){
				break;
			}
			for(int i = startColumn; i < maxColumn; i++){
				Cell cell = cells.get(startRow, i);
				result.addInRow(startRow + 1, NtsExcelCell.initAs(cell, i + 1, startRow + 1, 
																result.getHeaderAt(cell.getColumn() + 1).get(),
																cell.getStyle().getBackgroundColor().toArgb(),
																cell.getStyle().getForegroundColor().toArgb()));
			}
			startRow++;
		}
	}
	
	private static boolean isRowRecord(int row, int startColumn, int maxColumn, Cells cells) {
		for(int i = startColumn; i < maxColumn; i++){
			Cell cell = cells.get(row, i);
			if(!checkBorder(cell.getStyle(), Arrays.asList(BorderType.BOTTOM_BORDER, BorderType.LEFT_BORDER,
					BorderType.RIGHT_BORDER, BorderType.TOP_BORDER))){
				return false;
			}
		}
		return true;
	} 

	private static boolean isHaveBorder(Cells cells, Cell cell) {
		if (cell.isMerged()) {
			int row = cell.getRow();
			Range mergedRange = cell.getMergedRange();
			int first = mergedRange.getFirstColumn();
			if (cell.getColumn() > first) {
				return false;
			}
			int last = mergedRange.getFirstColumn() + mergedRange.getColumnCount() - 1;
			if (!checkBorder(cell.getStyle(),
					Arrays.asList(BorderType.BOTTOM_BORDER, BorderType.LEFT_BORDER, BorderType.TOP_BORDER))
					|| !checkBorder(cells.get(row, last).getStyle(),
							Arrays.asList(BorderType.BOTTOM_BORDER, BorderType.RIGHT_BORDER, BorderType.TOP_BORDER))) {
				return false;
			}

			for (int i = first + 1; i < last; i++) {
				if (!checkBorder(cells.get(row, i).getStyle(),
						Arrays.asList(BorderType.BOTTOM_BORDER, BorderType.TOP_BORDER))) {
					return false;
				}
			}
			return true;
		}

		return checkBorder(cell.getStyle(), Arrays.asList(BorderType.BOTTOM_BORDER, BorderType.LEFT_BORDER,
				BorderType.RIGHT_BORDER, BorderType.TOP_BORDER));
	}

	private static boolean checkBorder(Style style, List<Integer> borders) {
		return borders.stream().allMatch(b -> style.getBorders().getByBorderType(b).getLineStyle() != CellBorderType.NONE);
	}
}

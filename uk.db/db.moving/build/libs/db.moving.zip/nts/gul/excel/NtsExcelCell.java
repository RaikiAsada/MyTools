package nts.gul.excel;

import java.awt.Color;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.aspose.cells.Cell;
import com.aspose.cells.CellValueType;
import com.aspose.cells.DateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import nts.gul.util.value.ValueWithType;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class NtsExcelCell {

	private NtsExcelHeader header;
	
	private ValueWithType value;
	
	private int row;
	
	private int column;
	
	private String format;
	
	private Color backgroundColor;
	
	private Color textColor;
	
	public NtsExcelCell clone(){
		return new NtsExcelCell(header == null ? null : header.clone(), value, row, column, format, backgroundColor, textColor);
	}
	
	protected static NtsExcelCell initAs(Cell cell, int column, int row, NtsExcelHeader header) {
		 
		return initAs(cell, column, row, header, null);
	}
	
	protected static NtsExcelCell initAs(Cell cell, int column, int row, NtsExcelHeader header, Integer backgroundColor) {
		 
		return initAs(cell, column, row, header, backgroundColor, null);
	}
	
	protected static NtsExcelCell initAs(Cell cell, int column, int row, NtsExcelHeader header, Integer backgroundColor, Integer textColor){
		NtsExcelCell ntsCell = new NtsExcelCell();
		ntsCell.column = column;
		ntsCell.row = row;
		ntsCell.header = header;
		ntsCell.backgroundColor = new Color(backgroundColor, true);
		ntsCell.textColor = new Color(textColor, true);
		switch (cell.getType()) {
		case CellValueType.IS_BOOL:
			ntsCell.value = new ValueWithType(cell.getBoolValue());
			break;
		case CellValueType.IS_DATE_TIME:
			DateTime date = cell.getDateTimeValue();
			if(date.getHour() == 0 && date.getMinute() == 0 && date.getSecond() == 0){
				ntsCell.value = new ValueWithType(LocalDate.of(date.getYear(), date.getMonth(), date.getDay()));
			} else {
				ntsCell.value = new ValueWithType(LocalDateTime.of(date.getYear(), date.getMonth(), date.getDay(), date.getHour(), date.getMinute(), date.getSecond()));
			}
			break;
		case CellValueType.IS_ERROR:
		case CellValueType.IS_NULL:
			ntsCell.value = new ValueWithType();
			break;
		case CellValueType.IS_NUMERIC:
			ntsCell.value = new ValueWithType(BigDecimal.valueOf(cell.getDoubleValue()));
			break;
		case CellValueType.IS_UNKNOWN:
			ntsCell.value = new ValueWithType(cell.getValue());
			break;
		case CellValueType.IS_STRING:
		default:
			ntsCell.value = new ValueWithType(cell.getStringValue());
			break;
		}
		if(cell.isFormula()){
			ntsCell.format = cell.getFormula();
		}
		 
		return ntsCell;
	}
	
}

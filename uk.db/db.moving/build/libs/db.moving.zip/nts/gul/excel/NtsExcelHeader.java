package nts.gul.excel;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import lombok.Getter;

public class NtsExcelHeader {

	@Getter
	private NtsExcelCell main;
	
	@Getter
	private List<NtsExcelCell> sub;

	public NtsExcelHeader(NtsExcelCell main, List<NtsExcelCell> sub) {
		super();
		this.main = main;
		this.sub = sub;
	}
	
	public NtsExcelHeader(NtsExcelCell main) {
		super();
		this.main = main;
		this.sub = new ArrayList<>();
	}
	
	public int getLastColumnIndex(){
		return sub.get(sub.size() - 1).getColumn();
	}
	
	public int getFirstColumnIndex(){
		return sub.get(0).getColumn();
	}
	
	public Integer[] getColumnRange(){
		Integer[] range = {getFirstColumnIndex(), getLastColumnIndex()};
		
		return range;
	}
	
	public NtsExcelHeader clone(){
		return new NtsExcelHeader(main.clone(), sub.stream().map(c -> c.clone()).collect(Collectors.toList()));
	}
	
	public boolean isPairHeader(){
		return sub.size() > 1;
	}
	
	public boolean addSubHeader(NtsExcelCell sub){
		this.sub.add(sub);
		return true;
	}
	
	public void syncMainAndSub(){
		this.sub.add(main);
	}
}

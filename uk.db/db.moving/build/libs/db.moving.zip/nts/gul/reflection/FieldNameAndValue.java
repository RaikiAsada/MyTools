package nts.gul.reflection;

import lombok.Value;

@Value
public class FieldNameAndValue {
	private String name;
	private Object value;
}

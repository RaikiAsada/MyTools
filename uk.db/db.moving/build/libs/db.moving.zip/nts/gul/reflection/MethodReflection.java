package nts.gul.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class MethodReflection {

	public static Method getMethod(Class<?> targetClass, String methodName) {
		try {
			return targetClass.getMethod(methodName);
		} catch (NoSuchMethodException | SecurityException ex) {
			throw new RuntimeException(ex);
		}
	}
	
	public static Invoker invoker(Class<?> targetClass, String methodName, Class<?>... parameterTypes) {
		try {
			Method method = targetClass.getDeclaredMethod(methodName, parameterTypes);
			return new Invoker(method);
		} catch (NoSuchMethodException | SecurityException e) {
			throw new RuntimeException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public synchronized static <T> T invokeStatic(Class<?> targetClass, String methodName, Object... args) {
		Boolean accessible = null;
		Method method = null;
		try {
			method = targetClass.getDeclaredMethod(methodName);
			accessible = method.isAccessible();
			return (T) method.invoke(null, args);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e) {
			throw new RuntimeException(e);
		} finally {
			if (method != null) {
				method.setAccessible(accessible);
			}
		}
	}
	
	public static class Invoker {
		private final Method method;
		private final boolean isAccessible;
		
		Invoker(Method method) {
			this.method = method;
			this.isAccessible = method.isAccessible();
		}

		@SuppressWarnings("unchecked")
		public <T> T invoke(Object instance, Object... args) {
			try {
				return (T) method.invoke(instance, args);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new RuntimeException(e);
			}
		}
		
		public synchronized <T> T invokePrivate(Object instance, Object... args) {
			if (isAccessible) {
				throw new RuntimeException("not private");
			}
			
			try {
				method.setAccessible(true);
				return invoke(instance, args);
			} catch (IllegalArgumentException | SecurityException e) {
				throw new RuntimeException(e);
			} finally {
				method.setAccessible(false);
			}
		}
		
		public <T> T invokeStatic(Object... args) {
			return invoke(null, args);
		}
		
		public <T> T invokeStaticPrivate(Object... args) {
			return invokePrivate(null, args);
		}
	}
}

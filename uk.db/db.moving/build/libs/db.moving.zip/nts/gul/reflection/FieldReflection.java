package nts.gul.reflection;

import java.lang.reflect.Field;

public final class FieldReflection {

	@SuppressWarnings("unchecked")
	public synchronized static <V> V getField(Field field, Object instance) {
		boolean accessible = field.isAccessible();
		try {
			field.setAccessible(true);
			return (V) field.get(instance);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException(ex);
		} finally {
			// if the method is private, set false
			field.setAccessible(accessible);
		}
	}
	
	public static Field getField(Class<?> targetClass, String name) {
		try {
			return targetClass.getField(name);
		} catch (NoSuchFieldException | SecurityException e) {
			throw new RuntimeException(e);
		}
	}

	public synchronized static void setField(Field field, Object instance, Object newValue) {
		boolean accessible = field.isAccessible();
		try {
			field.setAccessible(true);
			field.set(instance, newValue);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException(ex);
		} finally {
			// if the method is private, set false
			field.setAccessible(accessible);
		}
	}
}

package nts.gul.reflection;

import java.lang.reflect.Field;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import nts.gul.collection.StreamWrapper;

public class FieldsWorkerStream extends StreamWrapper<Field>{

	public FieldsWorkerStream(Stream<Field> source) {
		super(source);
	}

	public Set<FieldNameAndValue> toNameAndValues(Object obj) {
		return this.map(f -> new FieldNameAndValue(f.getName(), ReflectionUtil.getFieldValue(f, obj)))
				.collect(Collectors.toSet());
	}
	
}

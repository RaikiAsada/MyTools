package nts.gul.reflection;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import nts.gul.reflection.ReflectionUtil.Condition;
import nts.gul.util.logical.predicate.PredicateSet;

/**
 * Utilities for annotation
 */
public class AnnotationUtil {

	public static Optional<Field> getFieldAnnotated(Class<?> targetClass, Class<? extends Annotation> annotationClass) {

		return getStreamOfFieldsAnnotated(targetClass, annotationClass).findAny();
	}

	public static FieldsWorkerStream getStreamOfFieldsAnnotated(Class<?> targetClass,
			Class<? extends Annotation> annotationClass) {

		return getStreamOfFieldsAnnotated(targetClass, Condition.ALL, annotationClass);
	}

	@SafeVarargs
	public static FieldsWorkerStream getStreamOfFieldsAnnotated(Class<?> targetClass, Condition annotationCondition,
			Class<? extends Annotation>... annotationClasses) {

		PredicateSet<Class<? extends Annotation>> setPredicate;
		switch (annotationCondition) {
		case ALL:
			setPredicate = PredicateSet.and(annotationClasses);
			break;
		case ANY:
			setPredicate = PredicateSet.or(annotationClasses);
			break;
		case NONE:
			setPredicate = PredicateSet.none(annotationClasses);
			break;
		default:
			throw new RuntimeException("unknown: " + annotationCondition);
		}

		return new FieldsWorkerStream(Arrays.asList(targetClass.getDeclaredFields()).stream()
				.filter(f -> setPredicate.operate(an -> f.isAnnotationPresent(an))));
	}

	@SafeVarargs
	public static FieldsWorkerStream getStreamOfFieldsAnnotated(List<Field> fields, Condition annotationCondition,
			Class<? extends Annotation>... annotationClasses) {

		PredicateSet<Class<? extends Annotation>> setPredicate;
		switch (annotationCondition) {
		case ALL:
			setPredicate = PredicateSet.and(annotationClasses);
			break;
		case ANY:
			setPredicate = PredicateSet.or(annotationClasses);
			break;
		case NONE:
			setPredicate = PredicateSet.none(annotationClasses);
			break;
		default:
			throw new RuntimeException("unknown: " + annotationCondition);
		}

		return new FieldsWorkerStream(fields.stream().filter(f -> setPredicate.operate(an -> f.isAnnotationPresent(an))));
	}
}

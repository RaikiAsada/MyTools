package nts.gul.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class Decapsulation {

	@SuppressWarnings("unchecked")
	public static <T> T invoke(Object targetInstance, String methodName) {
		Method method = null;
		boolean accessible = true;
		try {
			method = MethodReflection.getMethod(targetInstance.getClass(), methodName);
			accessible = method.isAccessible();
			return (T) method.invoke(targetInstance);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
			throw new RuntimeException(ex);
		} finally {
			// if the method is private, set false
			if (method != null) {
				method.setAccessible(accessible);
			}
		}
	}
	
	public static <V> V getField(Object instance, String fieldName) {
		return FieldReflection.getField(FieldReflection.getField(instance.getClass(), fieldName), instance);
	}

	public static void setfield(Object instance, String fieldName, Object value) {
		FieldReflection.setField(FieldReflection.getField(instance.getClass(), fieldName), instance, value);
	}
}

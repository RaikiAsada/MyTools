package nts.gul.reflection;

public class ClassReflection {

	/**
	 * targetがbaseのサブクラスならtrueを返す
	 * @param target
	 * @param base
	 * @return
	 */
	public static boolean isSubclass(Class<?> target, Class<?> base) {
		
		Class<?> superClass = target.getSuperclass();
		if (superClass == null) {
			return false;
		}
		
		if (superClass.equals(base)) {
			return true;
		}
		
		return isSubclass(superClass, base);
	}
}

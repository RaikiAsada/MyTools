package nts.gul.reflection;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Utilities for reflection
 */
public final class ReflectionUtil {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> T newInstance(Class targetClass) {
		try {
			return (T) targetClass.newInstance();
		} catch (InstantiationException | IllegalAccessException ex) {
			throw new RuntimeException(ex);
		}
	}

	public static <T> T newInstance(Constructor<T> ctor, Object... args) {
		try {
			return ctor.newInstance(args);
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> T invoke(Class<?> targetClass, Object targetInstance, String methodName) {
		return Decapsulation.invoke(targetInstance, methodName);
	}

	public static Method getMethod(Class<?> targetClass, String methodName) {
		return MethodReflection.getMethod(targetClass, methodName);
	}

	public static <V> V getFieldValue(Field field, Object instance) {
		return FieldReflection.getField(field, instance);
	}

	public static void setFieldValue(Field field, Object instance, Object newValue) {
		FieldReflection.setField(field, instance, newValue);
	}

	@SafeVarargs
	public static FieldsWorkerStream getStreamOfFieldsAnnotated(Class<?> targetClass, Condition annotationCondition,
			Class<? extends Annotation>... annotationClasses) {

		return AnnotationUtil.getStreamOfFieldsAnnotated(targetClass, annotationCondition, annotationClasses);
	}

	@SafeVarargs
	public static FieldsWorkerStream getStreamOfAllFieldsAnnotated(Class<?> targetClass, List<Class<?>> exclusiveParents,
			Condition annotationCondition, Class<? extends Annotation>... annotationClasses) {

		return AnnotationUtil.getStreamOfFieldsAnnotated(getAllFieldFromClass(targetClass, exclusiveParents), annotationCondition,
				annotationClasses);
	}
	
	public static List<Field> getAllFieldFromClass(Class<?> targetClass) {
		return getAllFieldFromClass(targetClass, Arrays.asList(Object.class));
	}
	
	public static List<Field> getAllFieldFromClass(Class<?> targetClass, List<Class<?>> exclusiveParents) {
		
		exclusiveParents = exclusiveParents != null ? exclusiveParents : Collections.emptyList();
		
		List<Field> fields = new ArrayList<>();
		
		Class<?> current = targetClass;

		while (current != Object.class) {
			if (!exclusiveParents.contains(current)) {
				fields.addAll(Arrays.asList(current.getDeclaredFields()));
			}
			
			current = current.getSuperclass();
		}
	
		return fields;
	}

	public static enum Condition {
		ALL, ANY, NONE,
	}
	
    @SuppressWarnings("unchecked")
	public static <E extends Enum<?>> List<E> getEnumValues(Class<E> enumClass) {
    	
        Method valuesMethod;
		try {
			valuesMethod = enumClass.getDeclaredMethod("values");
		} catch (SecurityException | NoSuchMethodException e) {
			throw new RuntimeException(e);
		}
        
        Object value;
		try {
			value = valuesMethod.invoke(null);
		} catch (IllegalArgumentException | IllegalAccessException | InvocationTargetException e) {
			throw new RuntimeException(e);
		}
		
        return Arrays.asList((E[]) value);
    }
}

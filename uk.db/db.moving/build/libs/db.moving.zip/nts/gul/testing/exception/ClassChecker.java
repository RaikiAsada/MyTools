package nts.gul.testing.exception;

/**
 * 例外のクラスをチェックする.
 */
class ClassChecker implements ExceptionChecker {

    /**
     * expectedExceptionClass
     */
    private final Class<?> expectedExceptionClass;

    /**
     * Constructs.
     *
     * @param expectedException exptected exception
     */
    public ClassChecker(Class<?> expectedException) {
        this.expectedExceptionClass = expectedException;
    }

    @Override
    public void check(Exception occuredException) {
        Class<?> occuredExceptionClass = occuredException.getClass();

        if (this.expectedExceptionClass != occuredExceptionClass) {
            throw new RuntimeException(
                    String.format(
                            "'%s' を期待しましたが '%s' が発生しました。",
                            expectedExceptionClass.getName(),
                            occuredExceptionClass.getName()));
        }
    }

}

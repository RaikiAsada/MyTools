package nts.gul.testing.exception;

/**
 * ExceptionChecker
 */
public interface ExceptionChecker {
    
    /**
     * check
     *
     * @param occuredException occuredException
     */
    void check(Exception occuredException);
}

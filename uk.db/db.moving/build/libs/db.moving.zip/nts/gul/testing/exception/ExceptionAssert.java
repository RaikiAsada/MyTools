package nts.gul.testing.exception;

/**
 * 例外が発生することをテストするユーティリティ.
 */
public final class ExceptionAssert {

    /**
     * this class is static
     */
    private ExceptionAssert() {
    }

}

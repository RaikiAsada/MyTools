package nts.gul.testing;

import java.lang.reflect.Method;

import lombok.SneakyThrows;
import lombok.val;

/**
 * ユニットテストでGetterのカバレッジを確保するためだけのユーティリティ
 */
public class GetterInvoker {

	@SneakyThrows
	public static void invoke(Object obj) {
		val methods = obj.getClass().getMethods();
		
		for(val method : methods) {
			if (isGetter(method)) {
				method.invoke(obj);
			}
		}
	}
	
	private static boolean isGetter(Method method) {
		return method.getParameterCount() == 0
				&& (method.getName().startsWith("get") || isBooleanGetter(method));
	}
	
	private static boolean isBooleanGetter(Method method) {
		return (method.getReturnType() == boolean.class || method.getReturnType() == Boolean.class)
				&& method.getName().startsWith("is");
	}
}

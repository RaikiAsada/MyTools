package nts.gul.testing.exception;

import java.util.ArrayList;
import java.util.List;

/**
 * ExceptionTester
 */
public class ExceptionTester {
    
    /**
     * checkers
     */
    private final List<ExceptionChecker> checkers;

    /**
     * Constructs.
     *
     * @param expectedException expectedException
     */
    public ExceptionTester(Class<?> expectedException) {
        this.checkers = new ArrayList<>();
        this.checkers.add(new ClassChecker(expectedException));
    }
    
    /**
     * テストを開始する.
     *
     * @param testcode 例外が発生するコードを含む関数
     */
    public void test(Runnable testcode) { // NOPMD
        try {
            testcode.run();
        } catch (Exception ex) {
            this.getCheckers().stream().forEach(checker -> checker.check(ex));
            return;
        }

        throw new RuntimeException("例外が発生しませんでした。");
    }
    
    /**
     * checkers
     * 
     * @return checkers
     */
    protected List<ExceptionChecker> getCheckers() {
        return this.checkers;
    }
}

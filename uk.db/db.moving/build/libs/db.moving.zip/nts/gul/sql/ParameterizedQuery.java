package nts.gul.sql;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import lombok.RequiredArgsConstructor;
import lombok.Value;
import lombok.val;
import nts.gul.text.RegexUtil;

/**
 * 標準SQLのパラメタライズドクエリを生成するためのクラス
 * @author m_kitahira
 *
 * @param <E> setParameterの際に自由に指定できるEnum（type-safeなwrapper APIを実装する使い方を想定）
 */
public class ParameterizedQuery<E extends ParameterizedQuery.ParameterType> {
	
	public static interface ParameterType {
		String toAdHockValue(Object value);
	}

	private final String sql;
	private final Map<String, NamedParameter<E>> parameters;
	private String parameterPrefix = "@";
	private boolean isAdHock = false;
	
	/**
	 * 名前付きパラメータを含むSQLを受け取る
	 * @param sql
	 */
	public ParameterizedQuery(String sql) {
		this.sql = sql;
		this.parameters = new HashMap<>();
	}
	
	/**
	 * アドホッククエリにする（SQL文字列にパラメータを直接埋め込む）
	 * @return
	 */
	public ParameterizedQuery<E> adHock() {
		isAdHock = true;
		return this;
	}
	
	public ParameterizedQuery<E> setParameter(String name, Object value, E type) {
		val param = new NamedParameter<>(name, value, type);
		parameters.put(param.name, param);
		return this;
	}
	
	public ParameterizedQuery<E> setParameterPrefix(String prefix) {
		parameterPrefix = prefix;
		return this;
	}
	
	public Built<E> build() {
		
		if (isAdHock) {
			return buildAdHock();
		}
		
		List<IndexedParameter<E>> indexedParameters = new ArrayList<>();
		val paramContainer = new ParametersContainer<E>(parameters);
		
		String standardSql = RegexUtil.replaceAll(sql, parameterPrefix + "\\w+", match -> {
			
			String parameterName = match.group().substring(parameterPrefix.length());
			
			NamedParameter<E> param = paramContainer.get(parameterName);
			if (param == null) {
				return match.group();
			}
			
			if (param.isList()) {
				List<IndexedParameter<E>> list = IndexedParameter.list(param);
				indexedParameters.addAll(list);
				
				return "(?" + StringUtils.repeat(",?", list.size() - 1) + ")";
			}
			
			indexedParameters.add(IndexedParameter.single(param));
			return "?";
		});
		
		paramContainer.validate();
		
		return new Built<>(standardSql, indexedParameters);
	}
	
	private Built<E> buildAdHock() {

		val paramContainer = new ParametersContainer<E>(parameters);
		
		String standardSql = RegexUtil.replaceAll(sql, parameterPrefix + "\\w+", match -> {
			
			String parameterName = match.group().substring(parameterPrefix.length());
			NamedParameter<E> param = paramContainer.get(parameterName);
			if (param == null) {
				return match.group();
			}
			
			return param.toAdHockValue();
		});
		
		return new Built<>(standardSql, Collections.emptyList());
	}
	
	@Value
	public static class Built<E extends ParameterizedQuery.ParameterType> {
		/** 標準SQL(パラメータは ? に置換されている) */
		String sql;
		
		/** パラメータ */
		List<IndexedParameter<E>> parameters;
	}
	
	@Value
	public static class IndexedParameter<E extends ParameterizedQuery.ParameterType> {
		Object value;
		E parameterType;
		
		static <E extends ParameterizedQuery.ParameterType> IndexedParameter<E> single(NamedParameter<E> named) {
			return new IndexedParameter<E>(named.value, named.type);
		}
		
		static <E extends ParameterizedQuery.ParameterType> List<IndexedParameter<E>> list(NamedParameter<E> named) {
			return named.valueAsList().stream()
					.map(v -> new IndexedParameter<>(v, named.type))
					.collect(Collectors.toList());
		}
	}
	
	@RequiredArgsConstructor
	private static class NamedParameter<E extends ParameterizedQuery.ParameterType> {
		final String name;
		final Object value;
		final E type;
		
		public boolean isList() {
			return value instanceof List; 
		}

		@SuppressWarnings("unchecked")
		public List<Object> valueAsList() {
			return (List<Object>) value;
		}
		
		public String toAdHockValue() {
			
			if (isList()) {
				return "(" + valueAsList().stream()
						.map(v -> type.toAdHockValue(v))
						.collect(Collectors.joining(","))
						+ ")";
			} else {
				return type.toAdHockValue(value);
			}
		}
	}
	
	private static class ParametersContainer<E extends ParameterizedQuery.ParameterType> {
		private final Map<String, NamedParameter<E>> defined;
		private final Set<String> undefined;
		private final Set<String> unused;
		
		ParametersContainer(Map<String, NamedParameter<E>> defined) {
			this.defined = defined;
			this.undefined = new HashSet<>();
			this.unused = new HashSet<>(defined.keySet());
		}
		
		NamedParameter<E> get(String usedParameterName) {
			val param = defined.get(usedParameterName);
			
			if (param == null) {
				undefined.add(usedParameterName);
			} else {
				unused.remove(usedParameterName);
			}
			
			return param;
		}
		
		void validate() {
			
			if (!undefined.isEmpty()) {
				throw new RuntimeException("undefined parameters: " + undefined);
			}
			
			if (!unused.isEmpty()) {
				throw new RuntimeException("unused parameters: " + unused);
			}
		}
	}
}

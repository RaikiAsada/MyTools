package nts.gul.location;

import lombok.Getter;

/**
 * 地理座標
 */
public class GeoCoordinate {
	
	/** 緯度 */
	@Getter
	private final double latitude;
	
	/** 経度 */
	@Getter
	private final double longitude;
	
	public GeoCoordinate(double latitude, double longitude) {
		if(latitude > 90 || latitude < -90 || longitude > 180 || longitude < -180) {
			System.out.println("Error");
		}		
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	/**
	 * 指定座標との距離を取得する（メートル）
	 * ヒュベニの公式を使用
	 * 
	 * @param double latitude, double longitude
	 * @return double distance
	 */
	public double getDistanceAsMeter(GeoCoordinate target) {
		
		//赤道半径(GRS80)
		double rx = 6378137.000;
		//極半径(GRS80)
		//double ry = 6356752.314140;
		double ry = 6378137;
		//離心率
		double e = Math.sqrt((rx * rx - ry * ry)/(rx * rx));
		
		//緯度の差
		double dy = deg2rad(this.latitude - target.latitude); 
		//経度の差
		double dx = deg2rad(this.longitude - target.longitude);
		//緯度の平均値
		double p = deg2rad((this.latitude + target.latitude) / 2.0); 

		double sinMy = Math.sin(p);
		double w = Math.sqrt(1.0 - e * sinMy * sinMy);

		
		//子午線曲線半径
		double m = (rx * (1.0 - e)) / (w * w * w);
		
		//卯酉線曲率半径
		double n = rx / w;

		//ヒュベニの公式
		double dym = dy * m;
		double dxncos = dx * n * Math.cos(p);
		return Math.sqrt(dym * dym + dxncos * dxncos);
	}
	
	/**
	 * 度→ラジアン
	 * @param deg
	 * @return rad
	 */
    private static double deg2rad(double deg){
        return deg * Math.PI / 180.0;
    }
}

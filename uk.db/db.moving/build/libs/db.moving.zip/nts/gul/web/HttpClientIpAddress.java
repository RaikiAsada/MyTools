package nts.gul.web;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

public class HttpClientIpAddress {

	public static String get(HttpServletRequest httpRequest) {
		String clientIpAddress;
		clientIpAddress = httpRequest.getHeader("X-Forwarded-For");
		if (!StringUtils.isEmpty(clientIpAddress)) {
			return clientIpAddress.split(",")[0];
		}
		clientIpAddress = httpRequest.getHeader("X-Real-IP");
		if (!StringUtils.isEmpty(clientIpAddress)) {
			return clientIpAddress;
		}
		return httpRequest.getRemoteAddr();		
	}
}

package nts.gul.web;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class URLEncode {

	public static String encodeAsUtf8(String source) {
		try {
			return URLEncoder.encode(source, "UTF-8").replaceAll("\\+", "%20");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}
}

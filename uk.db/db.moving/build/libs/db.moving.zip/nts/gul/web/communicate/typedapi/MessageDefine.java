package nts.gul.web.communicate.typedapi;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.ParseException;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import nts.gul.web.communicate.typedapi.EntityDefine.ParseResult;

@RequiredArgsConstructor
public abstract class MessageDefine<E> {
	
	@Getter
	private final EntityDefine<E> entity;
	
	public String entityToString(HttpEntity entity) throws ParseException, IOException {
		return this.entity.entityToString(entity);
	}
	
	public ParseResult<E> parseStringEntity(String entityString) {
		return this.entity.parseStringEntity(entityString);
	}
}

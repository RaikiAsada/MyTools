package nts.gul.web.communicate.typedapi;

import lombok.Getter;
import nts.gul.web.communicate.HttpStatusCode;

public class ResponseDefine<E> extends MessageDefine<E> {
	
	@Getter
	private String expectedStatusCode = HttpStatusCode.acceptAny();
	
	public ResponseDefine(EntityDefine<E> entityDefine) {
		super(entityDefine);
	}
	
	public static <E> ResponseDefine<E> create(EntityDefine<E> entityDefine) {
		return new ResponseDefine<>(entityDefine);
	}
	
	public static <E> ResponseDefine<E> json(Class<E> entityClass) {
		return create(EntityDefine.json(entityClass));
	}
	
	public static ResponseDefine<Void> noEntity() {
		return ResponseDefine.create(EntityDefine.none());
	}

	public ResponseDefine<E> expectedStatusCode(String code) {
		this.expectedStatusCode = code;
		return this;
	}

	public boolean matchesStatusCode(int actualCode) {
		return HttpStatusCode.matchesCodes(this.expectedStatusCode, String.valueOf(actualCode));
	}
}

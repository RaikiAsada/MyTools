package nts.gul.web;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;

public class HttpFullPath {
	
	@Getter
	private final String path;
	
	public HttpFullPath(String path) {
		this.path = path;
	}
	
	/**
	 * Pathクラスのrelatevizeメソッドが使えなかったので自作
	 * @param subjectFullPath
	 * @param targetFullPath
	 * @return relativePath
	 */
	public String relativize(HttpFullPath targetFullPath) {
		//URLパラメータに"/"が含まれている場合の例外処理
		String[] subjectParts1 = this.path.split("\\?", -1);	
		String[] subjectParts = subjectParts1[0].split("/", -1);
		if (subjectParts1.length == 2) {
			subjectParts[subjectParts.length - 1] += "?" + subjectParts1[1];
		}

		//URLパラメータに"/"が含まれている場合の例外処理
		String[] targetParts1 = targetFullPath.path.split("\\?", -1);
		String[] targetParts = targetParts1[0].split("/", -1);
		if (targetParts1.length == 2) {
			targetParts[targetParts.length - 1] += "?" + targetParts1[1];
		}

		
		//完全一致の場合、末尾のみ返す
		if (this.path.equals(targetFullPath.path)) {
			return targetParts[targetParts.length - 1];
		}

		//Pathのうち先頭から一致している階層数をカウント
		int equalCount = 0;
		for (int i = 0; ; i++) {
			if(!subjectParts[i].equals(targetParts[i])) {
				equalCount = i + 1;
				break;
			}
		}
		
		//遡る階層数をカウント
		int raises = subjectParts.length - equalCount;
		//遡る部分を生成
		String raisesPath = StringUtils.repeat("../", raises);
		//差分Pathを生成
		String differencePath = Arrays.asList(targetParts).stream()
				.skip(equalCount - 1)
				.collect(Collectors.joining("/"));
		
		//完全一致ではなくPathが""の場合はルート階層
		String relativePath = raisesPath + differencePath;
		if(relativePath.equals("")) {
			return "./";
		}
		
		return relativePath;
		
		
	}
}

package nts.gul.web.communicate.typedapi;

import java.util.function.Consumer;

import org.apache.http.impl.client.CloseableHttpClient;

public interface TypedCommunication<Q, S> {
	
	TypedCommunication<Q, S> header(String name, String value);

	TypedCommunication<Q, S> entity(Q requestEntity);
	
	TypedCommunication<Q, S> succeeded(Consumer<S> succeeded);
	
	TypedCommunication<Q, S> failed(Consumer<FailureCause> failed);
	
	void execute(TypedWebAPI<Q, S> api, CloseableHttpClient client);
}

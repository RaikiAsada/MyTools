package nts.gul.web.communicate.typedapi;

import java.net.URI;

import org.apache.http.client.methods.HttpUriRequest;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class TypedWebAPI<Q, S> {

	@Getter
	private final URI uri;
	
	@Getter
	private final RequestDefine<Q> requestDefine;
	
	@Getter
	private final ResponseDefine<S> responseDefine;

	public boolean matchesStatusCode(int actualCode) {
		return this.responseDefine.matchesStatusCode(actualCode);
	}
	
	public HttpUriRequest uriRequest() {
		return this.requestDefine.uriRequest(this.uri);
	}
	
	public HttpUriRequest uriRequest(Q requestEntity) {
		return this.requestDefine.uriRequest(this.uri, requestEntity);
	}
}

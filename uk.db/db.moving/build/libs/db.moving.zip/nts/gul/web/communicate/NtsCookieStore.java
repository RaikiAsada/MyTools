package nts.gul.web.communicate;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.http.client.CookieStore;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;

import nts.gul.serialize.ObjectSerializer;

public class NtsCookieStore implements CookieStore, Serializable {
	
	/** serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	private final CookieStore store;
	
	private NtsCookieStore(CookieStore store) {
		this.store = store;
	}
	
	public static NtsCookieStore createNew() {
		return new NtsCookieStore(new BasicCookieStore());
	}
	
	public static NtsCookieStore restore(String serializedCookieStore) {
		return ObjectSerializer.restore(serializedCookieStore);
	}
	
	public String serialize() {
		return ObjectSerializer.toBase64(this);
	}

	@Override
	public void addCookie(Cookie cookie) {
		this.store.addCookie(cookie);
	}

	@Override
	public List<Cookie> getCookies() {
		return this.store.getCookies();
	}

	@Override
	public boolean clearExpired(Date date) {
		return this.store.clearExpired(date);
	}

	@Override
	public void clear() {
		this.store.clear();
	}

}

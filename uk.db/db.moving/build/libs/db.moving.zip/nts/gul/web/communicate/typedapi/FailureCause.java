package nts.gul.web.communicate.typedapi;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@ToString
public class FailureCause {
	
	@Getter
	private final CauseType causeType;
	
	@Getter
	private final Exception exception;
	
	@Getter
	private final String responseText;
	
	@Getter
	private final int actualStatusCode;

	private FailureCause(CauseType causeType) {
		this(causeType, null);
	}

	private FailureCause(CauseType causeType, Exception exception) {
		this(causeType, exception, "");
	}
	
	private FailureCause(CauseType causeType, Exception exception, String responseText) {
		this(causeType, exception, responseText, 0);
	}
	
	public static FailureCause lowLevelException(Exception exception) {
		return new FailureCause(CauseType.LOW_LEVEL_EXCEPTION, exception);
	}
	
	public static FailureCause connectTimeout() {
		return new FailureCause(CauseType.CONNECT_TIMEOUT);
	}
	
	public static FailureCause invalidEntityFormat(Exception exception, String responseText) {
		return new FailureCause(CauseType.INVALID_ENTITY_FORMAT, exception, responseText);
	}
	
	public static FailureCause couldNotMap(Exception exception, String responseText) {
		return new FailureCause(CauseType.COULD_NOT_MAP, exception, responseText);
	}
	
	public static FailureCause unexpectedStatusCode(int code, String responseText) {
		return new FailureCause(CauseType.UNEXPECTED_STATUS_CODE, null, responseText, code);
	}
	
	public FailureCause ifConnectTimeout(Runnable handler) {
		if (this.causeType == CauseType.CONNECT_TIMEOUT) {
			handler.run();
		}
		return this;
	}
	
	public FailureCause ifUnexpectedStatusCode(Runnable handler) {
		if (this.causeType == CauseType.UNEXPECTED_STATUS_CODE) {
			handler.run();
		}
		return this;
	}
	
	public void throwException() {
		throw new RuntimeException(toString());
	}
	
	public enum CauseType {
		LOW_LEVEL_EXCEPTION,
		CONNECT_TIMEOUT,
		INVALID_ENTITY_FORMAT,
		COULD_NOT_MAP,
		UNEXPECTED_STATUS_CODE,
	}
}

package nts.gul.web.communicate;

import java.util.function.Consumer;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;

import lombok.Getter;
import lombok.val;
import nts.gul.web.communicate.typedapi.DefaultTypedCommunication;
import nts.gul.web.communicate.typedapi.TypedCommunication;
import nts.gul.web.communicate.typedapi.TypedWebAPI;

public class DefaultNtsHttpClient implements NtsHttpClient {
	
	public static class DEFAULT_SETTINGS {
		public static int CONNECT_TIMEOUT = 3000;
	}
	
	@Getter
	private final CloseableHttpClient rawClient;
	
	@Getter
	private final NtsCookieStore cookieStore;
	
	private DefaultNtsHttpClient(HttpClientBuilder clientBuilder, NtsCookieStore cookieStore) {
		this.rawClient = clientBuilder.setDefaultCookieStore(cookieStore).build();
		this.cookieStore = cookieStore;
	}
	
	public static DefaultNtsHttpClient createDefault() {
		return createWithCookieStore(NtsCookieStore.createNew());
	}
	
	public static DefaultNtsHttpClient createWithCookieStore(NtsCookieStore cookieStore) {
		return custom(cookieStore, b -> {});
	}
	
	public static DefaultNtsHttpClient custom(NtsCookieStore cookieStore, Consumer<HttpClientBuilder> builderConsumer) {
		val builder = HttpClients.custom()
				.setDefaultRequestConfig(RequestConfig.custom()
						.setConnectTimeout(DEFAULT_SETTINGS.CONNECT_TIMEOUT)
						.build());
		
		builderConsumer.accept(builder);
		return new DefaultNtsHttpClient(builder, cookieStore);
	}

	@Override
	public <Q, S> TypedCommunication<Q, S> createCommunicationFor(TypedWebAPI<Q, S> api) {
		return new DefaultTypedCommunication<Q, S>();
	}
}

package nts.gul.web.communicate.typedapi;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import org.apache.http.ParseException;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.CloseableHttpClient;

import lombok.val;

public class DefaultTypedCommunication<Q, S> implements TypedCommunication<Q, S> {

	private final Map<String, String> headers = new HashMap<>();
	private Q requestEntity = null;
	private Consumer<S> succeeded = r -> {};
	private Consumer<FailureCause> failed = r -> {};

	@Override
	public TypedCommunication<Q, S> header(String name, String value) {
		headers.put(name, value);
		return this;
	}
	
	@Override
	public TypedCommunication<Q, S> entity(Q requestEntity) {
		this.requestEntity = requestEntity;
		return this;
	}

	@Override
	public TypedCommunication<Q, S> succeeded(Consumer<S> succeeded) {
		this.succeeded = succeeded;
		return this;
	}

	@Override
	public TypedCommunication<Q, S> failed(Consumer<FailureCause> failed) {
		this.failed = failed;
		return this;
	}

	@Override
	public void execute(TypedWebAPI<Q, S> api, CloseableHttpClient client) {
		val request = this.requestEntity == null
				? api.uriRequest() : api.uriRequest(this.requestEntity);
				
		headers.forEach((name, value) -> {
			request.addHeader(name, value);
		});
		
		try (val response = client.execute(request)) {

			val responseEntity = response.getEntity();
			String entityString = api.getResponseDefine().entityToString(responseEntity);
			
			int statusCode = response.getStatusLine().getStatusCode();
			if (!api.matchesStatusCode(statusCode)) {
				this.failed.accept(FailureCause.unexpectedStatusCode(statusCode, entityString));
				return;
			}

			if (api.getResponseDefine().getEntity().isNone()) {
				this.succeeded.accept(null);
				return;
			}
			
			val result = api.getResponseDefine().parseStringEntity(entityString);
			if (result.isFailure()) {
				this.failed.accept(result.getFailureCause());
			} else {
				this.succeeded.accept(result.getParsedEntity());
			}
		} catch (ConnectTimeoutException e) {
			this.failed.accept(FailureCause.connectTimeout());
		} catch (ParseException | IOException e) {
			e.printStackTrace();
			this.failed.accept(FailureCause.lowLevelException(e));
			return;
		}
	}

	
	
}

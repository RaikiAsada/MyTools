package nts.gul.web.communicate.typedapi;

import java.net.URI;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;

import lombok.Getter;
import lombok.val;
import nts.gul.web.communicate.HttpMethod;

public class RequestDefine<E> extends MessageDefine<E> {

	@Getter
	private final HttpMethod method;
	
	@Getter
	private final Map<String, String> customHeaders = new HashMap<>();

	private RequestDefine(EntityDefine<E> entityDefine, HttpMethod method) {
		super(entityDefine);
		this.method = method;
	}
	
	public static <E> RequestDefine<E> create(EntityDefine<E> entityDefine, HttpMethod method) {
		return new RequestDefine<>(entityDefine, method);
	}
	
	public static <E> RequestDefine<E> json(Class<E> entityClass, HttpMethod method) {
		return create(EntityDefine.json(entityClass), method);
	}
	
	public static RequestDefine<Void> noEntity(HttpMethod method) {
		return RequestDefine.create(EntityDefine.none(), method);
	}

	public RequestDefine<E> charset(Charset charset) {
		this.getEntity().setCharset(charset);
		return this;
	}
	
	public RequestDefine<E> customHeader(String name, String value) {
		this.customHeaders.put(name, value);
		return this;
	}
	
	public HttpUriRequest uriRequest(URI uri) {
		
		val request = this.httpMethod(uri);
		this.setCustomHeaders(request);
		
		return request;
	}
	
	public HttpUriRequest uriRequest(URI uri, E requestEntity) {
		
		HttpEntityEnclosingRequestBase request;
		switch (method) {
		case POST:
			request = new HttpPost(uri);
			break;
		case PUT:
			request = new HttpPut(uri);
			break;
		default:
			throw new RuntimeException("invalid method: " + this.method);
		}
		
		this.getEntity().setupRequest(request, requestEntity);
		this.setCustomHeaders(request);
		
		return request;
	}

	private void setCustomHeaders(final org.apache.http.client.methods.HttpUriRequest request) {
		this.customHeaders.entrySet().stream().forEach(e -> {
			request.setHeader(e.getKey(), e.getValue());
		});
	}
	
	private HttpUriRequest httpMethod(URI uri) {
		
		switch (method) {
		case DELETE:
			return new HttpDelete(uri);
		case GET:
			return new HttpGet(uri);
		case HEAD:
			return new HttpHead(uri);
		case OPTIONS:
			return new HttpOptions(uri);
		case POST:
			return new HttpPost(uri);
		case PUT:
			return new HttpPut(uri);
		default:
			throw new RuntimeException("invalid method: " + this.method);
		}
	}
}

package nts.gul.web.communicate;

import java.util.Arrays;
import java.util.Collection;

public class HttpStatusCode {
	
	public static String acceptAny() {
		return "***";
	}
	
	public static String acceptMultiple(Collection<String> codes) {
		return String.join(",", codes);
	}

	public static boolean matchesCodes(String expected, String actual) {
		
		String[] expectedCodes = expected.split(",");
		if (expectedCodes.length >= 2) {
			return Arrays.stream(expectedCodes).anyMatch(e -> matchesCodes(e, actual));
		}
		
		String expectedCode = expectedCodes[0];
		
		for (int i = 0; i < 3; i++) {
			char expectedChar = expectedCode.charAt(i);
			if (expectedChar == '*') {
				continue;
			}
			
			if (expectedChar != actual.charAt(i)) {
				return false;
			}
		}
		
		return true;
	}
}

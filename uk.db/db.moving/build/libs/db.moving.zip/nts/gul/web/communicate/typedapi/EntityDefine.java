package nts.gul.web.communicate.typedapi;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.core.type.TypeReference;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.Value;
import nts.gul.serialize.json.JsonMapping;
import nts.gul.web.communicate.EntityFormat;

/**
 * リクエストやレスポンスでやり取りするエンティティの定義
 * JSONのトップレベルが配列である場合、Classの代わりにTypeReferenceを使用する
 * 入らない方はnull
 *
 * @param <E>
 */
@RequiredArgsConstructor
@Getter
public class EntityDefine<E> {
	private final EntityFormat format;
	
	private final Class<E> entityClass;
	private final TypeReference<E> entityTypeReference;
	
	@Setter
	private Charset charset = StandardCharsets.UTF_8;
	
	public static EntityDefine<Void> none() {
		return new EntityDefine<>(null, null, null);
	}
	
	public static <E> EntityDefine<E> json(Class<E> entityClass) {
		return new EntityDefine<>(EntityFormat.JSON, entityClass, null);
	}
	
	public static <E> EntityDefine<E> json(TypeReference<E> entityTypeReference) {
		return new EntityDefine<>(EntityFormat.JSON, null, entityTypeReference);
	}
	
	public boolean isNone() {
		return this.format == null;
	}
	
	public void setupRequest(HttpEntityEnclosingRequestBase request, E requestEntity) {

		switch (this.format) {
		case JSON:
			request.setEntity(new StringEntity(JsonMapping.toJson(requestEntity), this.charset));
			request.addHeader("Content-type", "application/json");
			break;
		default:
			throw new RuntimeException("invalid format: " + this.format);
		}
	}
	
	public String entityToString(HttpEntity entity) throws ParseException, IOException {
		return (entity != null)
				? EntityUtils.toString(entity, this.charset)
				: null;
	}
	
	public ParseResult<E> parseStringEntity(String entityString) {
		
		ParseResult<E> result;
		switch (this.format) {
		case JSON:
			result = this.processJsonEntity(entityString);
			break;
		default:
			throw new RuntimeException("invalid format: " + this.format);
		}
		
		result.printStackTraceIfException();
		
		return result;
			
	}

	private ParseResult<E> processJsonEntity(String entityString) {
		try {
			E entity;
			if (this.entityClass != null) {
				entity = JsonMapping.parse(entityString, this.entityClass);
			} else {
				entity = JsonMapping.parse(entityString, this.entityTypeReference);
			}
			
			return new ParseResult<E>(entity, null);
		} catch (JsonMapping.ParseException e) {
			return new ParseResult<E>(null, FailureCause.invalidEntityFormat(e, entityString));
		} catch (JsonMapping.MappingException e) {
			return new ParseResult<E>(null, FailureCause.couldNotMap(e, entityString));
		} catch (RuntimeException e) {
			return new ParseResult<E>(null, FailureCause.invalidEntityFormat(e, entityString));
		}
	}
	
	@Value
	public static class ParseResult<E> {
		
		private final E parsedEntity;
		private final FailureCause failureCause;
		
		public boolean isFailure() {
			return this.failureCause != null;
		}
		
		public void printStackTraceIfException() {
			if (this.failureCause != null && this.failureCause.getException() != null) {
				this.failureCause.getException().printStackTrace();
			}
		}
	}
}
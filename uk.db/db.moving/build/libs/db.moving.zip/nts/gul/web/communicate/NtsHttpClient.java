package nts.gul.web.communicate;

import java.util.function.Consumer;

import org.apache.http.impl.client.CloseableHttpClient;

import lombok.val;
import nts.gul.util.value.MutableValue;
import nts.gul.web.communicate.typedapi.TypedCommunication;
import nts.gul.web.communicate.typedapi.TypedWebAPI;

public interface NtsHttpClient {
	
	CloseableHttpClient getRawClient();
	
	NtsCookieStore getCookieStore();
	
	<Q, S> TypedCommunication<Q, S> createCommunicationFor(TypedWebAPI<Q, S> api);

	default <Q, S> void request(TypedWebAPI<Q, S> api, Consumer<TypedCommunication<Q, S>> communicationBuilder) {
		
		val communication = this.createCommunicationFor(api);
		communicationBuilder.accept(communication);
		
		communication.execute(api, this.getRawClient());
	}
	
	default <S> S fetch(TypedWebAPI<Void, S> api) {
		return fetch(api, null);
	}
	
	default <Q, S> S fetch(TypedWebAPI<Q, S> api, Q requestEntity) {
		
		val response = new MutableValue<S>();
		
		request(api, c -> c
				.entity(requestEntity)
				.succeeded(res -> {
					response.set(res);
				})
				.failed(f -> {
					f.throwException();
				}));
		
		return response.get();
	}
}

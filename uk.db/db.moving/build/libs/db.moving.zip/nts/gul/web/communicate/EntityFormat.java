package nts.gul.web.communicate;

public enum EntityFormat {

	JSON,
}

package nts.gul.web.communicate;

public enum HttpMethod {

	DELETE,
	GET,
	HEAD,
	OPTIONS,
	POST,
	PUT,
}

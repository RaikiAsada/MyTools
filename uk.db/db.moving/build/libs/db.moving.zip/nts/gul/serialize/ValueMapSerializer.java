package nts.gul.serialize;

import static java.util.stream.Collectors.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import lombok.Value;
import lombok.val;

/**
 * Javaプリミティブ型の値を持つMapを１つの文字列にシリアライズする
 * 対応する値の型はEntryTypeに定義してあるもののみ
 */
public class ValueMapSerializer {
	
	private static final String ENTRY_DELIMITER = "¦";
	private static final String KEYVALUE_DELIMITER = "¬";
	
	private static final String ENTRYINFO_KEY = "_ENTRYINFO_";
	private static final String ENTRYINFO_DELIMITER = "¶";
	private static final String ENTRYINFO_UNIT_DELIMITER = "»";
	
	public static String serialize(Map<String, Object> map) {
		
		val entryInfos = map.entrySet().stream()
				.map(e -> EntryInfo.of(e.getKey(), e.getValue()))
				.collect(toList());
		
		String serializedEntryInfos = entryInfos.stream()
				.map(e -> e.serialize())
				.collect(Collectors.joining(ENTRYINFO_DELIMITER));

		val serializingEntries = new ArrayList<String>();
		serializingEntries.add(ENTRYINFO_KEY + KEYVALUE_DELIMITER + serializedEntryInfos);
		
		for (val entry : entryInfos) {
			Object entryValue = map.get(entry.getName());
			serializingEntries.add(entry.getName() + KEYVALUE_DELIMITER + entryValue);
		}
		
		return serializingEntries.stream()
				.collect(Collectors.joining(ENTRY_DELIMITER));
	}
	
	public static Map<String, Object> deserialize(String serialized) {
		
		Map<String, String> entreisMap = new HashMap<>();
		for (String entry : serialized.split(ENTRY_DELIMITER)) {
			String[] parts = entry.split(KEYVALUE_DELIMITER);
			if (parts.length == 2) {
				entreisMap.put(parts[0], parts[1]);
			}
		}
		
		if (entreisMap.isEmpty()) {
			return Collections.emptyMap();
		}
		
		List<EntryInfo> entryInfos = Arrays.asList(entreisMap.get(ENTRYINFO_KEY).split(ENTRYINFO_DELIMITER))
				.stream()
				.map(s -> EntryInfo.deserialize(s))
				.collect(toList());

		Map<String, Object> results = new HashMap<>();
		for (val entryInfo : entryInfos) {
			String valueString = entreisMap.get(entryInfo.getName());
			Object value = entryInfo.getType().convert(valueString);
			results.put(entryInfo.getName(), value);
		}
		
		return results;
	}

	enum EntryType {
		INT,
		LONG,
		BOOLEAN,
		STRING,
		;
		
		public static EntryType of(Class<?> valueClass) {
			
			if (valueClass.equals(int.class) || valueClass.equals(Integer.class)) {
				return EntryType.INT;
			} else if (valueClass.equals(long.class) || valueClass.equals(Long.class)) {
				return EntryType.LONG;
			} else if (valueClass.equals(boolean.class) || valueClass.equals(Boolean.class)) {
				return EntryType.BOOLEAN;
			} else if (valueClass.equals(String.class)) {
				return EntryType.STRING;
			} else {
				throw new RuntimeException("unkown type: " + valueClass);
			}
		}
		
		public Object convert(String valueString) {
			
			switch (this) {
			case INT:
				return Integer.valueOf(valueString);
			case LONG:
				return Long.valueOf(valueString);
			case BOOLEAN:
				return Boolean.valueOf(valueString);
			case STRING:
				return valueString;
			default:
				throw new RuntimeException("unknown: " + this);
			}
			
		}
	}

	@Value
	static class EntryInfo {
		String name;
		EntryType type;
		
		public static EntryInfo of(String name, Object value) {
			EntryType type = EntryType.of(value.getClass());
			return new EntryInfo(name, type);
		}
		
		public String serialize() {
			return name + ENTRYINFO_UNIT_DELIMITER + type;
		}
		
		public static EntryInfo deserialize(String serialized) {
			String[] parts = serialized.split(ENTRYINFO_UNIT_DELIMITER);
			String value = parts.length == 2 ? parts[1] : "";
			EntryType type = Enum.valueOf(EntryType.class, value);
			return new EntryInfo(parts[0], type);
		}
	}
}

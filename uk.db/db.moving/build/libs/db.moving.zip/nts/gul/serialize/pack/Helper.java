package nts.gul.serialize.pack;

import java.util.List;

class Helper {
	
	static byte[] toBits(byte v) {
		
		byte b1 = (byte) ((v & 0b10000000) >>> 7);
		byte b2 = (byte) ((v & 0b01000000) >>> 6);
		byte b3 = (byte) ((v & 0b00100000) >>> 5);
		byte b4 = (byte) ((v & 0b00010000) >>> 4);
		byte b5 = (byte) ((v & 0b00001000) >>> 3);
		byte b6 = (byte) ((v & 0b00000100) >>> 2);
		byte b7 = (byte) ((v & 0b00000010) >>> 1);
		byte b8 = (byte) (v & 0b00000001);
		
		return new byte[] { b1, b2, b3, b4, b5, b6, b7, b8 };
	}

	static byte toByte(List<Byte> bits, int startIndex) {
		
		byte[] array = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
		
		for (int i = 0; i < 8 && startIndex + i < bits.size(); i++) {
			array[i] = bits.get(startIndex + i);
		}
		
		return toByte(array);
	}

	static byte toByte(byte[] bits, int startIndex) {
		
		byte[] array = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
		
		for (int i = 0; i < 8 && startIndex + i < bits.length; i++) {
			array[i] = bits[startIndex + i];
		}
		
		return toByte(array);
	}
	
	static byte toByte(byte[] bits) {
		if (bits.length > 8) {
			throw new RuntimeException("invalid length: " + bits.length);
		}
		
		byte result = 0;
		
		for (int i = 0; i < bits.length; i++) {
			result |= (bits[i] << (7 - i));
		}
		
		return result;
	}
}

package nts.gul.serialize.pack;

import java.nio.ByteBuffer;

/**
 * ValuesPackerによって作られたbyte配列から整数値を取り出す。
 * このbyte配列は要素間の区切りの情報を持たないため、前から１つずつ順番に読んでいくことしかできない。
 */
public class ValuesUnpacker {

	private final byte[] packedBits;
	
	public ValuesUnpacker(byte[] packedBinary) {
		
		packedBits = new byte[packedBinary.length * 8];
		
		int bitIndex = 0;
		for (int i = 0; i < packedBinary.length; i++) {
			byte[] bits = Helper.toBits(packedBinary[i]);
			fill(bits, packedBits, bitIndex);
			bitIndex += bits.length;
		}
	}
	
	private static void fill(byte[] filler, byte[] filled, int startIndex) {
		for (int i = 0; i < filler.length; i++) {
			filled[startIndex + i] = filler[i];
		}
	}
	
	/**
	 * packedBinaryから次に読み取れる値のビット位置
	 */
	private int currentBitIndex = 0;
	
	public boolean readBoolean() {
		boolean b = packedBits[currentBitIndex] == (byte)1;
		currentBitIndex++;
		return b;
	}
	
	public byte readByte() {
		byte b = Helper.toByte(packedBits, currentBitIndex);
		currentBitIndex += 8;
		return b;
	}
	
	public short readShort() {
		byte[] bytes = readBytes(2);
		return ByteBuffer.wrap(bytes).getShort();
	}
	
	public int readInt() {
		byte[] bytes = readBytes(4);
		return ByteBuffer.wrap(bytes).getInt();
	}
	
	public long readLong() {
		byte[] bytes = readBytes(8);
		return ByteBuffer.wrap(bytes).getLong();
	}
	
	private byte[] readBytes(int length) {
		
		byte[] bytes = new byte[length];
		
		for (int i = 0; i < length; i++) {
			bytes[i] = readByte();
		}
		
		return bytes;
	}
	
}

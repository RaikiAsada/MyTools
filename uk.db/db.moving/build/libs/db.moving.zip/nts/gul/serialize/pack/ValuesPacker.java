package nts.gul.serialize.pack;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import lombok.RequiredArgsConstructor;

/**
 * booleanを含む整数値の配列をbyte配列に変換する。
 * このbyte配列はValuesUnpackerを使うことで元に戻せる。
 */
public class ValuesPacker {

	private final List<Object> values = new ArrayList<>();
	private final List<Type> types = new ArrayList<>();

	public ValuesPacker addBoolean(boolean value) {
		values.add(value);
		types.add(Type.BOOLEAN);
		return this;
	}

	public ValuesPacker addByte(int value) {
		return addByte((byte)value);
	}

	public ValuesPacker addByte(byte value) {
		values.add(value);
		types.add(Type.BYTE);
		return this;
	}

	public ValuesPacker addShort(int value) {
		return addShort((short)value);
	}

	public ValuesPacker addShort(short value) {
		values.add(value);
		types.add(Type.SHORT);
		return this;
	}

	public ValuesPacker addInt(int value) {
		values.add(value);
		types.add(Type.INT);
		return this;
	}

	public ValuesPacker addLong(long value) {
		values.add(value);
		types.add(Type.LONG);
		return this;
	}
	
	@RequiredArgsConstructor
	enum Type {
		BOOLEAN(1) {
			@Override
			byte[] toBits(Object value) {
				boolean booleanValue = (boolean) value;
				byte b = (byte) (booleanValue ? 1 : 0);
				return new byte[] { b };
			}
		},
		
		BYTE(8) {
			@Override
			byte[] toBits(Object value) {
				return Helper.toBits((byte) value);
			}
		},
		
		SHORT(16) {
			@Override
			byte[] toBits(Object value) {
				short shortValue = (short) value;
				byte[] bytes = ByteBuffer.allocate(2).putShort(shortValue).array();
				return toBits(bytes);
			}
		},
		INT(32) {
			@Override
			byte[] toBits(Object value) {
				int intValue = (int) value;
				byte[] bytes = ByteBuffer.allocate(4).putInt(intValue).array();
				return toBits(bytes);
			}
		},
		LONG(64) {
			@Override
			byte[] toBits(Object value) {
				long longValue = (long) value;
				byte[] bytes = ByteBuffer.allocate(8).putLong(longValue).array();
				return toBits(bytes);
			}
		},
		
		;
		final int size;
		
		abstract byte[] toBits(Object value);
		
		static byte[] toBits(byte[] bytes) {
			
			byte[] bits = new byte[bytes.length * 8];
			
			for (int i = 0; i < bytes.length; i++) {
				System.arraycopy(Helper.toBits(bytes[i]), 0, bits, i * 8, 8);
			}
			
			return bits;
		}
	}
	
	/**
	 * バイト配列に変換する
	 * @return
	 */
	public byte[] pack() {
		
		// bitのリストに詰め込む
		List<Byte> packedBits = new ArrayList<>();

		for (int i = 0; i < values.size(); i++) {
			Object value = values.get(i);
			Type type = types.get(i);
			
			byte[] bits = type.toBits(value);
			for (byte b : bits) {
				packedBits.add(b);
			}
		}
		
		// 8bitずつ取り出してbyte配列化
		List<Byte> packedBytes = new ArrayList<>();
		int extend = (packedBits.size() % 8 == 0) ? 0 : 8;
		for (int i = 0; i < packedBits.size() + extend; i += 8) {
			byte b = Helper.toByte(packedBits, i);
			packedBytes.add(b);
		}
		
		// 配列に詰め直す
		byte[] result = new byte[packedBytes.size()];
		for (int i = 0; i < packedBytes.size(); i++) {
			result[i] = packedBytes.get(i);
		}
		
		return result;
	}
}

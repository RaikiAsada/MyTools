package nts.gul.serialize;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Base64;

import lombok.val;

public final class ObjectSerializer {

	public static byte[] toBytes(Serializable obj) {
		val memoryOutput = new ByteArrayOutputStream();
		
		try(val oos = new ObjectOutputStream(memoryOutput)) {
			oos.writeObject(obj);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
		return memoryOutput.toByteArray();
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T restore(byte[] bytes) {
		val memoryInput = new ByteArrayInputStream(bytes);
		
		try (val ois = new ObjectInputStream(memoryInput)) {
			return (T)ois.readObject();
		} catch (IOException | ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static String toBase64(Serializable obj) {
		return Base64.getEncoder().encodeToString(toBytes(obj));
	}
	
	public static <T> T restore(String base64) {
		return restore(Base64.getDecoder().decode(base64));
	}
}

package nts.gul.serialize.binary;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

import lombok.SneakyThrows;
import lombok.val;

/**
 * Javaオブジェクトをバイナリファイルとして出力したり、バイナリファイルからJavaオブジェクトに復元したりする
 */
public final class ObjectBinaryFile {

	@SneakyThrows
	public static void write(Object source, Path destionationFile) {
		
		Files.deleteIfExists(destionationFile);
		
		try (val fos = Files.newOutputStream(destionationFile, StandardOpenOption.CREATE_NEW);
				val oos = new ObjectOutputStream(fos)) {
			
			oos.writeObject(source);
		}
	}

	@SuppressWarnings("unchecked")
	@SneakyThrows
	public static <T> T read(Path sourceFile) {
		
		try (val fis = Files.newInputStream(sourceFile, StandardOpenOption.READ);
				val ois = new ObjectInputStream(fis)) {
			
			return (T) ois.readObject();
		}
	}
}

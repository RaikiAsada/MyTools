package nts.gul.serialize.binary;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Optional;

import lombok.SneakyThrows;
import lombok.val;
import nts.gul.reflection.FieldReflection;

/**
 * ObjectBinaryFileを使うにあたって、Optionalフィールドがあるとシリアライズできない問題にぶつかった
 * Optionalフィールドは使いたいので、そこだけ自力でシリアライズする処理を実装。
 * 使い方はObjectBinaryFileのテストコードを参照
 */
public interface SerializableWithOptional extends Serializable {

	@SneakyThrows
	default void writeObjectWithOptional(ObjectOutputStream stream) {
		// とりあえず自動処理できるやつ（transientついてないやつ）は自動処理してもらう
		stream.defaultWriteObject();
		
		// Optionalの出力は自分で処理する
		for (val field : this.getClass().getDeclaredFields()) {
			if (field.getType() != java.util.Optional.class) {
				continue;
			}
			
			val optional = (Optional<?>)FieldReflection.getField(field, this);
			stream.writeObject(optional.orElse(null));
		}
	}

	@SneakyThrows
	default void readObjectWithOptional(ObjectInputStream stream) {
		// とりあえず自動処理できるやつ（transientついてないやつ）は自動処理してもらう
		stream.defaultReadObject();
		
		// Optionalの復元は自分で処理する
		for (val field : this.getClass().getDeclaredFields()) {
			if (field.getType() != java.util.Optional.class) {
				continue;
			}
			
			Object value = stream.readObject();
			FieldReflection.setField(field, this, Optional.ofNullable(value));
		}
	}
}

package nts.gul.serialize.json;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.val;

public class JsonMapping {
	
	public static ObjectMapper MAPPER = new ObjectMapper();
	
	public static String toJson(Object obj) {
		try {
			return MAPPER.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Parse json to object
	 * @param json json
	 * @param objectClass class
	 * @return parsed object
	 * @throws ParseException invalid json
	 * @throws MappingException could not map to objectClass
	 * @throws RuntimeException other exceptions
	 */
	public static <T> T parse(String json, Class<T> objectClass) {
		val mapper = new ObjectMapper();
		try {
			return (T) mapper.readValue(json, objectClass);
		} catch (JsonParseException e) {
			throw new ParseException(e);
		} catch (JsonMappingException e) {
			throw new MappingException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T parse(String json, TypeReference<T> objectClass) {
		val mapper = new ObjectMapper();
		try {
			return (T) mapper.readValue(json, objectClass);
		} catch (JsonParseException e) {
			throw new ParseException(e);
		} catch (JsonMappingException e) {
			throw new MappingException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static class ParseException extends RuntimeException {

		/** serialVersionUID */
		private static final long serialVersionUID = 1L;
		
		ParseException(Exception e){
			super(e);
		}
	}
	
	public static class MappingException extends RuntimeException {

		/** serialVersionUID */
		private static final long serialVersionUID = 1L;
		
		MappingException(Exception e){
			super(e);
		}
	}
}

package nts.gul.file.archive;

public enum ArchiveFormat {
	ZIP,
}

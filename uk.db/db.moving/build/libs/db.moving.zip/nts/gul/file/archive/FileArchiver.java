package nts.gul.file.archive;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;
import java.util.function.Function;

import lombok.val;
import nts.gul.file.archive.zip.ZipFileArchiver;

/**
 * FileArchiver
 */
public interface FileArchiver {

	/**
	 * Returns Archiver
	 * @param format format
	 * @return Archiver
	 */
	public static FileArchiver create(ArchiveFormat format) {
		switch (format) {
		case ZIP: return new ZipFileArchiver();
		default: throw new RuntimeException("unknown format: " + format);
		}
	}

	/**
	 * Pack files.
	 * @param sourceDirectory files are here
	 * @param destinationArchiveFile archive file
	 */
	default void pack(Path sourceDirectory, Path destinationArchiveFile) {
		tryWithOutputStream(destinationArchiveFile, os -> this.pack(sourceDirectory, os));
	}
	
	/**
	 * Pack files.
	 * @param sourceDirectory files are here
	 * @param destinationArchiveFile archive file
	 */
	void pack(Path sourceDirectory, OutputStream destinationArchiveFile);
	
	/**
	 * Pack files.
	 * @param sourceDirectory files are here
	 * @param destinationArchiveFile archive file
	 * @param includeRootFolder include Root Folder
	 */
	default void pack(Path sourceDirectory, Path destinationArchiveFile, boolean includeRootFolder) {
		tryWithOutputStream(destinationArchiveFile, os -> this.pack(sourceDirectory, os, includeRootFolder));
	}
	/**
	 * Pack files.
	 * @param sourceDirectory files are here
	 * @param destinationArchiveFile archive file
	 * @param includeRootFolder include Root Folder
	 */
	void pack(Path sourceDirectory, OutputStream destinationArchiveFile, boolean includeRootFolder);
	
	/**
	 * Pack files with password.
	 * @param sourceDirectory files are here
	 * @param password password
	 * @param destinationArchiveFile archive file
	 */
	default void pack(Path sourceDirectory, String password, Path destinationArchiveFile) {
		tryWithOutputStream(destinationArchiveFile, os -> this.pack(sourceDirectory, password, os));
	}

	/**
	 * Pack files with password.
	 * @param sourceDirectory files are here
	 * @param password password
	 * @param destinationArchiveFile archive file
	 */
	void pack(Path sourceDirectory, String password, OutputStream destinationArchiveFile);

	/**
	 * Pack files with password.
	 * @param sourceDirectory files are here
	 * @param password password
	 * @param destinationArchiveFile archive file
	 */
	default void pack(Path sourceDirectory, String password, Path destinationArchiveFile, boolean includeRootFolder) {
		tryWithOutputStream(destinationArchiveFile, os -> this.pack(sourceDirectory, password, os, includeRootFolder));
	}
	
	/**
	 * Pack files with password.
	 * @param sourceDirectory files are here
	 * @param password password
	 * @param destinationArchiveFile archive file
	 * @param includeRootFolder include Root Folder
	 */
	void pack(Path sourceDirectory, String password, OutputStream destinationArchiveFile, boolean includeRootFolder);
	
	/**
	 * Extract files.
	 * @param sourceArchiveFile archive file
	 * @param destinationDirectory files are extracted here
	 */
	default ExtractStatus extract(Path sourceArchiveFile, Path destinationDirectory) {
		return tryWithInputStream(sourceArchiveFile, is -> this.extract(is, destinationDirectory));
	}
	
	/**
	 * Extract files.
	 * @param sourceArchiveFile archive file
	 * @param destinationDirectory files are extracted here
	 */
	ExtractStatus extract(InputStream sourceArchiveFile, Path destinationDirectory);
	
	/**
	 * Extract files with password.
	 * @param sourceArchiveFile archive file
	 * @param password password
	 * @param destinationDirectory files are extracted here
	 */
	default ExtractStatus extract(Path sourceArchiveFile, String password, Path destinationDirectory) {
		return tryWithInputStream(sourceArchiveFile, is -> this.extract(is, password, destinationDirectory));
	}
	
	/**
	 * Extract files with password.
	 * @param sourceArchiveFile archive file
	 * @param password password
	 * @param destinationDirectory files are extracted here
	 */
	ExtractStatus extract(InputStream sourceArchiveFile, String password, Path destinationDirectory);

	
	static ExtractStatus tryWithInputStream(Path sourceArchiveFile, Function<InputStream, ExtractStatus> task) {
		try (val is = Files.newInputStream(sourceArchiveFile)) {
			return task.apply(is);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	static void tryWithOutputStream(Path destinationArchiveFile, Consumer<OutputStream> task) {
		try (val os = Files.newOutputStream(destinationArchiveFile)) {
			task.accept(os);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}

package nts.gul.file.archive;

public enum ExtractStatus {
	
	SUCCESS(0, "展開成功でした。"),
	NOT_VALID_FILE(1, "不正なファイルです。"),
	NONE_CORRECT_PASSWORD(2, "不正なパスワード。"),
	NEED_PASSWORD(3, "パスワードを入力してください。");
	
	public final int value;
	public final String description;
	
	private ExtractStatus(int value, String description) {
		this.value = value;
		this.description = description;
	}
}

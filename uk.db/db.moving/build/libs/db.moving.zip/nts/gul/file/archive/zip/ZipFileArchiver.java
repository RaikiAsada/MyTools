package nts.gul.file.archive.zip;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;

import org.apache.commons.io.IOUtils;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;
import nts.gul.file.FileUtil;
import nts.gul.file.archive.ExtractStatus;
import nts.gul.file.archive.FileArchiver;
import nts.gul.text.IdentifierUtil;
import nts.gul.text.StringUtil;
import nts.gul.text.charset.NtsCharset;

public class ZipFileArchiver implements FileArchiver {

	@Override
	public void pack(Path sourceDirectory, OutputStream destinationArchiveFile) {
		this.pack(sourceDirectory, null, destinationArchiveFile);
	}

	@Override
	public void pack(Path sourceDirectory, String password, OutputStream destinationArchiveFile) {
		this.pack(sourceDirectory, password, destinationArchiveFile, true);
	}

	@Override
	public void pack(Path sourceDirectory, OutputStream destinationArchiveFile, boolean includeRootFolder) {
		this.pack(sourceDirectory, null, destinationArchiveFile, includeRootFolder);
	}

	@Override
	public void pack(Path sourceDirectory, String password, OutputStream destinationArchiveFile,
			boolean includeRootFolder) {
		try {
			File zipTempFile = createTempFile();
			ZipFile zipFile = new ZipFile(zipTempFile);
			zipFile.setFileNameCharset(NtsCharset.SHIFT_JIS.name);

			ZipParameters parameters = getZipParameter(!StringUtil.isNullOrEmpty(password, true), password);
			parameters.setIncludeRootFolder(includeRootFolder);

			if (Files.isDirectory(sourceDirectory, LinkOption.NOFOLLOW_LINKS)) {
				zipFile.addFolder(sourceDirectory.toString(), parameters);
			} else {
				zipFile.addFile(new File(sourceDirectory.toString()), parameters);
			}
			try (InputStream is = new FileInputStream(zipTempFile)){ 
				IOUtils.copy(is, destinationArchiveFile);
			}
		} catch (ZipException | IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public ExtractStatus extract(InputStream sourceArchiveFile, Path destinationDirectory) {
		return extract(sourceArchiveFile, null, destinationDirectory);
	}

	@Override
	public ExtractStatus extract(InputStream sourceArchiveFile, String password, Path destinationDirectory) {
		try {
			ZipFile zipFile = new ZipFile(FileUtil.NoCheck.stream2file(sourceArchiveFile, "tmp", ".zip"));
			zipFile.setFileNameCharset(NtsCharset.SHIFT_JIS.name);
			if(!zipFile.isValidZipFile()){
				return ExtractStatus.NOT_VALID_FILE;
			}
			if (zipFile.isEncrypted()) {
				if(StringUtil.isNullOrEmpty(password, false)){
					return ExtractStatus.NEED_PASSWORD;
				}
				zipFile.setPassword(password);
			}
			zipFile.extractAll(destinationDirectory.toString());
			return ExtractStatus.SUCCESS;
		} catch (ZipException e) {
			e.printStackTrace();
			return ExtractStatus.NONE_CORRECT_PASSWORD;
		}
	}

	public static File createTempFile() throws IOException {
		File destination = new File(System.getProperty("java.io.tmpdir"), IdentifierUtil.randomUniqueId());
		destination.deleteOnExit();
		return destination;
	}
	
	private ZipParameters getZipParameter(boolean isEncryptFile, String password) {
		ZipParameters parameters = new ZipParameters();
		parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
		parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
		parameters.setEncryptFiles(isEncryptFile);
		if (isEncryptFile) {
			parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD);
			parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
			parameters.setPassword(password);
		}
		return parameters;
	}
}

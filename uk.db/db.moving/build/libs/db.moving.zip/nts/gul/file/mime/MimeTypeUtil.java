package nts.gul.file.mime;

import java.io.File;

import eu.medsea.mimeutil.MimeUtil;

/**
 * MimeTypeUtil
 */
public class MimeTypeUtil {

	static {
		// the order of registration has nothing to do with priority of detecting
		// detect by extension of file name (first)
		MimeUtil.registerMimeDetector("eu.medsea.mimeutil.detector.ExtensionMimeDetector");
		// detect by header of file (second)
		MimeUtil.registerMimeDetector("eu.medsea.mimeutil.detector.MagicMimeMimeDetector");
	}
	
	/**
	 * Detects MIME type of the file.
	 * 引数fileNameに拡張子が含まれるか、または拡張子だけ（必ずドットを含むこと）であれば、その拡張子で判定する。
	 * 拡張子による判定ができなければ、ファイルヘッダを見て判定するが、その場合にはfileNameがそのファイルへのパスでなければならない。
	 * 
	 * @param fileName file path or extension contains dot
	 * @return mime type (if cannot detect, returns 'application/octet-stream')
	 */
	public static String detect(String fileName) {
		return MimeUtil.getFirstMimeType(MimeUtil.getMimeTypes(fileName).toString()).toString();
	}
	
	/**
	 * Detects MIME type of the file.
	 * @param file file
	 * @return mime type
	 */
	public static String detect(File file) {
		return MimeUtil.getFirstMimeType(MimeUtil.getMimeTypes(file).toString()).toString();
	}
}

package nts.gul.file;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.Arrays;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;

public class FileUtil {
	
	private static final byte[] ZIP_HEX = { 0x50, 0x4b, 0x03, 0x04 };

	public static class NoCheck {
		
		public static long size(Path path) {
			try {
				return Files.size(path);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		
		public static InputStream newInputStream(Path path, OpenOption... options) {
			try {
				return Files.newInputStream(path, options);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		
		public static OutputStream newOutputStream(Path path, OpenOption... options) {
			try {
				return Files.newOutputStream(path, options);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		
		public static File stream2file(InputStream in, String name, String extension) {
			try {
				File tempFile = File.createTempFile(name, extension);
				tempFile.deleteOnExit();
				try (FileOutputStream out = new FileOutputStream(tempFile)) {
					IOUtils.copy(in, out);
				}
				return tempFile;
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	public static boolean isZip(File file, String originalName) {
		if (file.isDirectory()) return false;
		if (!file.canRead()) {
			throw new RuntimeException("Cannot read file " + file.getAbsolutePath());
		}
		try (DataInputStream is = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
			byte[] bytes = new byte[4];
			if (is.read(bytes) == 4) {
				return Arrays.equals(bytes, ZIP_HEX) && FilenameUtils.isExtension(originalName, "zip");
			}
			return false;
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}
	}
}

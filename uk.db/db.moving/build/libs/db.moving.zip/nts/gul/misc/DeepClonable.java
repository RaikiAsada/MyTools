package nts.gul.misc;

public interface DeepClonable<T> {

	T deepClone();
}

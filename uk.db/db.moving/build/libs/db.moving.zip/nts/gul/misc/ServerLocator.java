package nts.gul.misc;

import lombok.Value;

/**
 * ServerLocator
 */
@Value
public class ServerLocator {

	/** Address of server */
	private final String address;
	
	/** port of server */
	private final int port;
}

package nts.gul.datetime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import nts.gul.text.StringUtil;

public class DateTimeUtility {
	public static final String DATE_BASE_FORMAT = "yyyy/MM/dd";

	public static Date nowAsOldDate() {
		return Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
	}
	
	public static int lastDateInMonth(int year, int month) {
		return YearMonth.of(year, month).lengthOfMonth(); 
	}
	
	public static int lastDateInYear(int year, int month) {
		return YearMonth.of(year, month).lengthOfYear(); 
	}
	
	public static int lastDateInYear(int year) {
		return Year.of(year).length(); 
	}
	
	public static boolean isValidDate(int year, int month, int date) {
		if(year <= 0 || month <= 0 || date <= 0){
			return false;
		}
		String dateString = StringUtils.join(toFormat(year, 4), "/", toFormat(month, 2), "/", toFormat(date, 2));
		return isValidDate(dateString, DATE_BASE_FORMAT);
	}

	public static boolean isValidDate(String dateString, String format) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			dateFormat.setLenient(false);
			dateFormat.parse(dateString);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	private static String toFormat(int year, int size) {
		return StringUtil.padLeft(String.valueOf(year), size, '0');
	}
}

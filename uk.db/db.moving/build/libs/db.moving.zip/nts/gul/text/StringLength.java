package nts.gul.text;

import lombok.val;

/**
 * 文字列の長さに関するユーティリティ
 */
public final class StringLength {

	private StringLength() {}
	
	
    /**
     * Get text length as half width characters.
     *
     * @param text text
     * @return length
     */
    public static int lengthHalf(String text) {
        int count = 0;
        for (int i = 0, len = text.length(); i < len; i++) {
            int code = text.codePointAt(i);
            count += lengthHalf(code);
        }
        return count;
    }
    
    /**
     * Returns character length as half width characters.
     * 
     * @param codeOfCharacter code of character
     * @return length
     */
    public static int lengthHalf(int codeOfCharacter) {
        // 0x20 ～ 0x80: 半角記号と半角英数字
        // 0xff61 ～ 0xff9f: 半角カタカナ
        // 0x0a,0x0d: CR,LF
        if ((0x20 <= codeOfCharacter && codeOfCharacter <= 0x7e)
                || (0xff61 <= codeOfCharacter && codeOfCharacter <= 0xff9f)
                || codeOfCharacter == 0x0a
                || codeOfCharacter == 0x0d) {
            return 1;
        } else {
            return 2;
        }
    }

    /**
     * Cuts off string at given length as half width characters.
     * 
     * @param text source
     * @param maxLength max length
     * @return cut off string
     */
    public static String cutOffAsLengthHalf(String text, int maxLength) {
    	
    	int resultLength = 0;
    	val result = new StringBuilder();
    	
    	for (int i = 0, len = text.length(); i < len; i++) {
    		int code = text.codePointAt(i);
    		int charLength = lengthHalf(code);
    		
    		if (maxLength < resultLength + charLength) {
    			break;
    		}
    		
    		result.append(text.charAt(i));
    		resultLength += charLength;
    	}
    	
    	return result.toString();
    }
    
    /**
     * Cuts off string at given length as half width characters.
     * 
     * @param text source
     * @param startIndex index of start
     * @param maxLength max length
     * @return cut off string
     */
    public static String cutOffAsLengthHalf(String text, int startIndex, int maxLength) {
    	
    	if (startIndex == 0) {
    		return cutOffAsLengthHalf(text, maxLength);
    	}

    	int currentIndex = 0;
    	final int lastIndex = startIndex + maxLength;
    	val result = new StringBuilder();
    	
    	for (int i = 0, len = text.length(); i < len; i++) {
    		int code = text.codePointAt(i);
    		int currentCharLength = lengthHalf(code);
    		
    		if (currentIndex + currentCharLength > lastIndex) {
    			break;
    		}
    		
    		if (currentIndex >= startIndex) {
        		result.append(text.charAt(i));
    		}
    		
    		currentIndex += currentCharLength;
    	}
    	
    	return result.toString();
    }
    
}

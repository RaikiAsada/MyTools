package nts.gul.text;

import java.util.Map;
import java.util.function.Function;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Regular Excpression Utilities
 */
public final class RegexUtil {

    /**
     * static class
     */
    private RegexUtil() {
    }

    /**
     * Replace matched strings.
     * 
     * @param target target
     * @param pattern pattern
     * @param replacer replacer
     * @return replaced string
     */
    public static String replaceAll(String target, String pattern, Function<MatchResult, String> replacer) {
        return replaceAll(target, Pattern.compile(pattern), replacer);
    }

    /**
     * Replace matched strings.
     * 
     * @param target target
     * @param pattern pattern
     * @param replacer replacer
     * @return replaced string
     */
    public static String replaceAll(CharSequence target, Pattern pattern, Function<MatchResult, String> replacer) {
        Matcher matcher = pattern.matcher(target);
        
        if (!matcher.find()) {
            return target.toString();
        }
        
        StringBuilder result = new StringBuilder();

        int previousEnd = 0;
        do {
            result.append(target.subSequence(previousEnd, matcher.start()));
            result.append(replacer.apply(matcher.toMatchResult()));
            previousEnd = matcher.end();
        } while (matcher.find());

        result.append(target.subSequence(previousEnd, target.length()));

        return result.toString();
    }
    
    /**
     * Replace by mappings.
     * 
     * @param target target
     * @param mappings mappings
     * @return replaced string
     */
    public static String replaceAll(String target, Map<String, String> mappings) {
        String result = target;
        
        for (Map.Entry<String, String> mapping : mappings.entrySet()) {
            result = result.replace(mapping.getKey(), mapping.getValue());
        }
        
        return result;
    }
}

package nts.gul.text.mapping;

import java.util.HashMap;
import java.util.Map;

import lombok.val;

public class StringToStringMapper {

	private final Map<String, String> map;
	
	public StringToStringMapper(Map<String, String> map) {
		this.map = new HashMap<>(map);
	}
	
	public String map(String source) {
		val worker = new StringBuilder(source);
		
		for (Map.Entry<String, String> mapping : this.map.entrySet()) {
			int i;
			while ((i = worker.indexOf(mapping.getKey())) > -1) {
				worker.replace(i, i + mapping.getKey().length(), mapping.getValue());
			}
		}
		
		return worker.toString();
	}
}

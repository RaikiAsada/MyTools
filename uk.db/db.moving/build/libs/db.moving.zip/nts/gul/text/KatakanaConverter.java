package nts.gul.text;

import java.util.HashMap;
import java.util.Map;

/**
 * Convert katakana full - half
 */
public class KatakanaConverter {
    
    /**
     * 半角と全角のマッピング
     */
    private static final String mapping[][] = {
        // 変換の検索順は、濁点・半濁点付きの文字が先
        { "ｶﾞ", "ガ" }, { "ｷﾞ", "ギ" }, { "ｸﾞ", "グ" }, { "ｹﾞ", "ゲ" }, { "ｺﾞ", "ゴ" },
        { "ｻﾞ", "ザ" }, { "ｼﾞ", "ジ" }, { "ｽﾞ", "ズ" }, { "ｾﾞ", "ゼ" }, { "ｿﾞ", "ゾ" },
        { "ﾀﾞ", "ダ" }, { "ﾁﾞ", "ヂ" }, { "ﾂﾞ", "ヅ" }, { "ﾃﾞ", "デ" }, { "ﾄﾞ", "ド" },
        { "ﾊﾞ", "バ" }, { "ﾋﾞ", "ビ" }, { "ﾌﾞ", "ブ" }, { "ﾍﾞ", "ベ" }, { "ﾎﾞ", "ボ" },
        { "ﾊﾟ", "パ" }, { "ﾋﾟ", "ピ" }, { "ﾌﾟ", "プ" }, { "ﾍﾟ", "ペ" }, { "ﾎﾟ", "ポ" },
        { "ｳﾞ", "ヴ" },
        
        // 濁点が付かない文字
        { "ｱ", "ア" }, { "ｲ", "イ" }, { "ｳ", "ウ" }, { "ｴ", "エ" }, { "ｵ", "オ" },
        { "ｶ", "カ" }, { "ｷ", "キ" }, { "ｸ", "ク" }, { "ｹ", "ケ" }, { "ｺ", "コ" },
        { "ｻ", "サ" }, { "ｼ", "シ" }, { "ｽ", "ス" }, { "ｾ", "セ" }, { "ｿ", "ソ" },
        { "ﾀ", "タ" }, { "ﾁ", "チ" }, { "ﾂ", "ツ" }, { "ﾃ", "テ" }, { "ﾄ", "ト" },
        { "ﾅ", "ナ" }, { "ﾆ", "ニ" }, { "ﾇ", "ヌ" }, { "ﾈ", "ネ" }, { "ﾉ", "ノ" },
        { "ﾊ", "ハ" }, { "ﾋ", "ヒ" }, { "ﾌ", "フ" }, { "ﾍ", "ヘ" }, { "ﾎ", "ホ" },
        { "ﾏ", "マ" }, { "ﾐ", "ミ" }, { "ﾑ", "ム" }, { "ﾒ", "メ" }, { "ﾓ", "モ" },
        { "ﾔ", "ヤ" }, { "ﾕ", "ユ" }, { "ﾖ", "ヨ" }, { "ﾗ", "ラ" }, { "ﾘ", "リ" },
        { "ﾙ", "ル" }, { "ﾚ", "レ" }, { "ﾛ", "ロ" }, { "ﾜ", "ワ" }, { "ｦ", "ヲ" },
        { "ﾝ", "ン" }, { "ｧ", "ァ" }, { "ｨ", "ィ" }, { "ｩ", "ゥ" }, { "ｪ", "ェ" },
        { "ｫ", "ォ" }, { "ｬ", "ャ" }, { "ｭ", "ュ" }, { "ｮ", "ョ" }, { "ｯ", "ッ" },
        { "｡", "。" }, { "､", "、" }, 
        { "｢", "「" }, { "｣", "」" }, { "･", "・" }, { "ｰ", "ー" }, { " ", "　" },
        { "ﾞ", "゛" }, { "ﾟ", "゜" },
        { "", "" }
    };
    
    private static final Map<String, String> mapKatakanaFullToHalf;
    static {
    	mapKatakanaFullToHalf = new HashMap<>();
    	for (String[] mapping1 : mapping) {
    		mapKatakanaFullToHalf.put(mapping1[1], mapping1[0]);
    	}
    }
    
    /**
     * Convert katakana half-width to full-width in given string
     * @param source source string
     * @return converted string
     */
    public static String halfToFull(String source) {
    	
    	if (source == null) {
    		return null;
    	}
    	
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < source.length(); i++) {
            Character c = source.charAt(i);
            
            // 変換処理対象外
            if (!isHalfKatakanaInUnicode(c)) {
                sb.append(c);
                continue;
            }
        
            boolean found = false;
            for (String[] mapping1 : mapping) {
                if (source.substring(i).startsWith(mapping1[0])) {
                    
                    found = true;

                    sb.append(mapping1[1]);
                    
                    i += mapping1[0].length() - 1;

                    break;
                }
            }

            // マッピングが無かった
            if (!found) {
                sb.append(c);
            }
        }
        
        return sb.toString();
    }
    
    public static String fullKatakanaToHalf(String source) {
    	StringBuffer sb = new StringBuffer(source);
    	
    	for (int i = 0; i < sb.length(); i++) {
    		String c = sb.substring(i, i + 1);
    		String halfChar = mapKatakanaFullToHalf.get(c);
    		
    		if (halfChar == null) {
    			continue;
    		}

			sb.setCharAt(i, halfChar.charAt(0));
    		if (halfChar.length() == 2) {
    			sb.insert(i + 1, halfChar.charAt(1));
    			i++;
    		}
    	}
    	
    	return sb.toString();
    }
    
    /**
     * Convert hiragana in given string to full-width katakana.
     * @param source source string
     * @return converted string
     */
    public static String hiraganaToKatakana(String source) {
    	
        StringBuffer sb = new StringBuffer(source);
        
        for (int i = 0; i < sb.length(); i++) {
        	char c = sb.charAt(i);
        	if (c >= 'ぁ' && c <= 'ん') {
        		sb.setCharAt(i, (char)(c - 'ぁ' + 'ァ'));
        	}
        }
        
        return sb.toString();    
    }
    
    /**
     * Convert full-width katakana in given string to hiragana.
     * @param source source string
     * @return converted string
     */
    public static String fullKatakanaToHiragana(String source) {
    	
        StringBuffer sb = new StringBuffer(source);
        
        for (int i = 0; i < sb.length(); i++) {
        	char c = sb.charAt(i);
        	if (c >= 'ァ' && c <= 'ン') {
        		sb.setCharAt(i, (char)(c - 'ァ' + 'ぁ'));
        	}
        }
        
        return sb.toString();
    }
    
    /**
     * 指定した文字がUnicode上の半角カタカナかどうか判定する.
     * 
     * @param c character to be checked
     * @return trueなら該当
     */
    private static boolean isHalfKatakanaInUnicode(Character c) {
        return c.compareTo((char)0xff61) >= 0 && c.compareTo((char)0xff9f) <= 0
                || c == ' ';
    }
}
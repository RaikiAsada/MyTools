package nts.gul.text.mapping;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import lombok.val;

public class StringToSupplierMapper {

	private final Map<String, Supplier<String>> map;
	
	public StringToSupplierMapper(Map<String, Supplier<String>> map) {
		this.map = new HashMap<>(map);
	}
	
	public String map(String source) {
		val worker = new StringBuilder(source);
		
		for (Map.Entry<String, Supplier<String>> mapping : this.map.entrySet()) {
			int i;
			while ((i = worker.indexOf(mapping.getKey())) > -1) {
				worker.replace(i, i + mapping.getKey().length(), mapping.getValue().get());
			}
		}
		
		return worker.toString();
	}
}

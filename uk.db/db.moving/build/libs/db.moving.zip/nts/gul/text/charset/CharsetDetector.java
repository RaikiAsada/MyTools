package nts.gul.text.charset;

import java.io.IOException;
import java.io.InputStream;

import org.mozilla.universalchardet.UniversalDetector;

/**
 * CharsetDetector
 */
public final class CharsetDetector {
	
	private static final int BUFFER_SIZE = 4096;
	
	/**
	 * Detect charset of a given InputStream.
	 * @param is this InputStream should be disposed after detecting because offset of stream has already been moved by detector. 
	 * @return result. If detector could not determine, UNKNOWN is returned.
	 */
	public static NtsCharset detect(InputStream is) {
		try {
			return detectInternal(is);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	private static NtsCharset detectInternal(InputStream is) throws IOException {
		
		UniversalDetector detector = new UniversalDetector(null);
		byte[] buf = new byte[BUFFER_SIZE];
		int nread = is.read(buf, 0, BUFFER_SIZE);
		detector.handleData(buf, 0, nread);
		detector.dataEnd();

		String encoding = detector.getDetectedCharset();
		detector.reset();
		
		NtsCharset result = NtsCharset.UNKNOWN;
		
		// could determine charset
		if (encoding != null) {
			switch (encoding) {
			case "UTF-8":
				result = buf[0] == (byte)0xEF && buf[1] == (byte)0xBB && buf[2] == (byte)0xBF
							? NtsCharset.UTF8_WITH_BOM
							: NtsCharset.UTF8;
				break;
			case "SHIFT_JIS":
				result = NtsCharset.SHIFT_JIS;
			}
		}
		
		return result;
	}
}

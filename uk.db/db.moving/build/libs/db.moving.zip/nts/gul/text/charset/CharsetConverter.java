package nts.gul.text.charset;

import java.io.UnsupportedEncodingException;

public class CharsetConverter {
	
	public static boolean canConvert(String target, NtsCharset charsetToConvert) {
		byte[] bytes = getBytes(target, charsetToConvert);
		String restored = getString(bytes, charsetToConvert);
		return target.equals(restored);
	}

	public static byte[] getBytes(String source, NtsCharset charset) {
		try {
			return source.getBytes(charset.name);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static String getString(byte[] source, NtsCharset charset) {
		try {
			return new String(source, charset.name);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}
}

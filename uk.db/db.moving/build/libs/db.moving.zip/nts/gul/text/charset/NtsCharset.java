package nts.gul.text.charset;

public enum NtsCharset {

	UNKNOWN(0, "UNKNOWN"),
	UTF8(1, "UTF-8"),
	UTF8_WITH_BOM(2, "UTF-8"),
	SHIFT_JIS(3, "MS932"),//"SJIS")
	;
	
	public final int value;
	
	public final String name;
	
	NtsCharset(int value, String name) {
		this.value = value;
		this.name = name;
	}
}

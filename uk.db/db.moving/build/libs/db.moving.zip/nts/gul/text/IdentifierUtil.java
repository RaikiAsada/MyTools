package nts.gul.text;

import java.util.UUID;

/**
 * Utility to generate any identifier
 */
public class IdentifierUtil {
    
    /**
     * static class
     */
    private IdentifierUtil() {
    }
    
    /**
     * Generate a random unique ID.
     * 
     * @return ID
     */
    public static String randomUniqueId() {
        // UUID type 4
        return UUID.randomUUID().toString();
    }
}

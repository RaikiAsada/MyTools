package nts.gul.text;

import org.apache.commons.lang3.StringUtils;

public class StringUtil {

	/**
	 * Special characters 
	 */
	private static final String specialChars[] = { "\\", "/", ":", "*", "?", "\"", "<", ">", "|" };

    /**
     * Get text length as half width characters.
     *
     * @param text text
     * @return length
     */
    public static int lengthHalf(String text) {
        return StringLength.lengthHalf(text);
    }
    
    /**
     * Returns character length as half width characters.
     * 
     * @param codeOfCharacter code of character
     * @return length
     */
    public static int lengthHalf(int codeOfCharacter) {
        return StringLength.lengthHalf(codeOfCharacter);
    }
    
    /**
     * Cuts off string at given length as half width characters.
     * 
     * @param text source
     * @param maxLength max length
     * @return cut off string
     */
    public static String cutOffAsLengthHalf(String text, int maxLength) {
    	return StringLength.cutOffAsLengthHalf(text, maxLength);
    }
    
    /**
     * Convert to hex string from array of byte.
     * 
     * @param bytes bytes
     * @return hex string
     */
    public static String asHex(byte[] bytes) {

        StringBuilder result = new StringBuilder(bytes.length * 2);

        for (int index = 0; index < bytes.length; index++) {
            int num = bytes[index] & 0xff;

            if (num < 0x10) {
                result.append("0");
            }

            result.append(Integer.toHexString(num));
        }
        
        return result.toString();
    }
    
    
    /**
     * Checks if is null or empty.
     *
     * @param data the data
     * @param trim the trim
     * @return true, if is null or empty
     */
    public static boolean isNullOrEmpty(String data, boolean trim) {
    	if (data == null)
    		return true;
    	
    	if (trim) {
    		data = data.trim();
    	}
    	
    	return data.length() == 0;
    }
    
    /**
     * Replace special characters by hyphen character
     * 
     * @param text input string
     * @return converted string
     */
    public static String replaceSpecialChars(String text) {
    	StringBuilder convertedTextBuilder = new StringBuilder();
    	
    	for (int i = 0; i < text.length(); i++) {
    		Character character = text.charAt(i);
    		for (String specialChar : specialChars) {
    			if (character.toString().equals(specialChar)) {
    				convertedTextBuilder.append("-");
    				break;
    			}
    		}
    		if (convertedTextBuilder.length() == i + 1) continue;
    		convertedTextBuilder.append(character);
    	}
    	return convertedTextBuilder.toString();
    }
    
    public static String padLeft(String source, int size, char padder) {
        return StringUtils.leftPad(source, size, padder);
    }
    
    public static String padRight(String source, int size, char padder) {
        return StringUtils.rightPad(source, size, padder);
    }
}

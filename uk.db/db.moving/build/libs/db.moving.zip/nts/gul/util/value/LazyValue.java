package nts.gul.util.value;

import java.util.function.Supplier;

public class LazyValue<V> {

	private V actualValue;
	
	/**
	 * actualValueのnullチェックだと、lazyLoaderがnullを返す場合に正しく判断できないので、厳密にフラグ管理する
	 */
	private boolean hasLoaded;
	
	private final Supplier<V> lazyLoader;
	
	public LazyValue(Supplier<V> lazyLoader) {
		this.actualValue = null;
		this.hasLoaded = false;
		this.lazyLoader = lazyLoader;
	}
	
	public V get() {
		if (!this.hasLoaded) {
			this.actualValue = this.lazyLoader.get();
			this.hasLoaded = true;
		}
		
		return this.actualValue;
	}
}

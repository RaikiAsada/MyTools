package nts.gul.util.value;

import java.util.ArrayList;
import java.util.List;

public interface DiscreteValue<T> extends Comparable<T> {

	T nextValue(boolean isIncrement);
	
	default T increase() {
		return nextValue(true);
	}
	
	default T decrease() {
		return nextValue(false);
	}

	static <T extends DiscreteValue<T> & Comparable<T>> List<T> list(T from, T to) {

		List<T> results = new ArrayList<>();

		for (T cur = from; cur.compareTo(to) <= 0; cur = cur.increase()) {
			results.add(cur);
		}

		return results;
	}
}

package nts.gul.util.logical.predicate;

import java.util.Collection;
import java.util.function.Predicate;

public class NonePredicateSet<T> extends PredicateSet<T> {
	
	public NonePredicateSet(Collection<T> values) {
		super(values);
	}

	@Override
	public boolean operate(Predicate<T> predicate) {
		return this.values.stream().noneMatch(v -> predicate.test(v));
	}
}

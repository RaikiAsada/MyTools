package nts.gul.util;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Utility class for time processing.
 *
 */
public class Time {

	/**
	 * Step
	 */
	public static final long STEP = 60L;
	
	/**
	 * Square step
	 */
	public static final long SQUARE_STEP = 3600L;
	
	/**
	 * Max value of hour
	 */
	public static final int MAX_HOUR = 24;
	
	/**
	 * Max value of minute, second
	 */
	public static final int MAX_MS = 60;
	
	/**
	 * Minimum value of hour, minute, second
	 */
	public static final int MIN_TIME = 0;
	
	/**
	 * Time split character
	 */
	private static final String TIME_SPLIT_CHAR = ":";
	
	/**
	 * Time pattern
	 */
	private static final String TIME_PATTERN = "^\\d+:\\d+(:\\d+)?$";
	
	/**
	 * Get hour part of time.
	 * @param seconds
	 * @return hour
	 */
	public static Long getHour(long seconds) {
		return seconds / SQUARE_STEP;
	}
	
	/**
	 * Get minute part of time.
	 * @param seconds
	 * @return minute
	 */
	public static Long getMinute(long seconds) {
		return seconds / STEP - getHour(seconds) * STEP;
	}
	
	/**
	 * Get second part of time.
	 * @param seconds
	 * @return
	 */
	public static Long getSecond(long seconds) {
		return seconds - getHour(seconds) * SQUARE_STEP - getMinute(seconds) * STEP;
	}
	
	/**
	 * Convert seconds to hours
	 * @param seconds
	 * @return hours
	 */
	public static double toHours(long seconds) {
		return Long.valueOf(seconds).floatValue() / SQUARE_STEP;
	}
	
	/**
	 * Convert seconds to minutes.
	 * @param seconds
	 * @return minutes
	 */
	public static double toMinutes(long seconds) {
		return Long.valueOf(seconds).floatValue() / STEP;
	}
	
	/**
	 * Parse time string to time value object.<br/>
	 * Ex: hh:mm & hh:mm:ss
	 * @param time string
	 * @return time value
	 */
	public static Value parse(String time) {
		if (!Pattern.matches(TIME_PATTERN, time)) throw new RuntimeException("Invalid time format.");
		List<Integer> parts = Arrays.asList(time.split(TIME_SPLIT_CHAR)).stream()
				.map(t -> {
					try {
						return Integer.parseInt(t);
					} catch (NumberFormatException ex) {
						throw new RuntimeException("Invalid time format.");
					}
				}).collect(Collectors.toList());
		return Value.create(parts);
	}
	
	/**
	 * Parse time in hours, minutes, seconds to value object.
	 * @params
	 * @return time value
	 */
	public static Value parse(Long hours, Long minutes, Long seconds) {
		return Value.create(Arrays.asList(hours.intValue(), minutes.intValue(), seconds.intValue()));
	}
	
	/**
	 * Parse time in seconds to value object.
	 * @param seconds
	 * @return time value
	 */
	public static Value parse(long seconds) {
		return Value.create(Arrays.asList(getHour(seconds).intValue(), getMinute(seconds).intValue(), getSecond(seconds).intValue()));
	}
	
	public static class Value {
		int hour;
		int minute;
		int second;
		
		private Value() {}

		@Override
		public boolean equals(Object obj) {
			Value other = (Value) obj;
			if (hour != other.hour)
				return false;
			if (minute != other.minute)
				return false;
			if (second != other.second)
				return false;
			return true;
		}
		
		/**
		 * Compare self to other.
		 * @param other
		 * @return greater than/equals or not
		 */
		public boolean isGreaterThanEquals(Value other) {
			if (hour > other.hour) return true;
			if (hour == other.hour && minute > other.minute) return true;
			if (hour == other.hour && minute == other.minute && second >= other.second) return true;
			return false;
		}

		/**
		 * Create new instance of time value.
		 * @param values 
		 * @return time value
		 */
		public static Value create(List<Integer> values) {
			Value time = new Value();
			Field[] fs = time.getClass().getDeclaredFields();
			for (int i = 0; i < values.size(); i++) {
				try {
					fs[i].set(time, values.get(i));
				} catch (IllegalArgumentException | IllegalAccessException | SecurityException ex) {
					throw new RuntimeException(ex);
				}
			}
			return time;
		}
		
		/**
		 * Gets the hours component of the time interval represented by the current Time.Value structure.
		 * @return int
		 */
		public int hours() {
			return hour;
		}
		
		/**
		 * Gets the minutes component of the time interval represented by the current Time.Value structure.
		 * @return int
		 */
		public int minutes() {
			return minute;
		}
		
		/**
		 * Gets the seconds component of the time interval represented by the current Time.Value structure.
		 * @return int
		 */
		public int seconds() {
			return second;
		}
		
		/**
		 * Gets the value of the current Time.Value structure expressed in whole and fractional seconds.
		 * @return long
		 */
		public long totalSeconds() {
			return hour * SQUARE_STEP + minute * STEP + second;
		}
	}
}

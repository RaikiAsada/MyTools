package nts.gul.util.value;

import java.util.Optional;
import java.util.function.Function;

public class MutableValue<T> {

    private Optional<T> obj;

    public MutableValue() {
        this(null);
    }

    public MutableValue(T obj) {
        this.set(obj);
    }
    
    public static <T> MutableValue<T> of(T defaultValue) {
    	return new MutableValue<T>(defaultValue);
    }

    public final void set(T obj) {
        this.obj = obj != null ? Optional.of(obj) : Optional.empty();
    }
    
    public final void set(Function<T, T> calculator) {
    	this.set(calculator.apply(this.obj.get()));
    }

    public final T get() {
        return obj.get();
    }
    
    public final Optional<T> optional() {
        return this.obj;
    }
}

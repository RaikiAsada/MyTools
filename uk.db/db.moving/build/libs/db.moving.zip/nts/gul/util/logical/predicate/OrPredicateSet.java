package nts.gul.util.logical.predicate;

import java.util.Collection;
import java.util.function.Predicate;

public class OrPredicateSet<T> extends PredicateSet<T> {

	public OrPredicateSet(Collection<T> values) {
		super(values);
	}

	@Override
	public boolean operate(Predicate<T> predicate) {
		return this.values.stream().anyMatch(v -> predicate.test(v));
	}
}

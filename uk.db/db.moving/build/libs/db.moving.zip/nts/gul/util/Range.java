package nts.gul.util;

public class Range<T extends Comparable<T>> {
	private final org.apache.commons.lang3.Range<T> range;
	
	private Range(T from, T to) {
		this.range = org.apache.commons.lang3.Range.between(from, to);
	}
	
	public static <T extends Comparable<T>> Range<T> between(T from, T to) {
		return new Range<>(from, to);
	}
	
	public T min() {
		return this.range.getMinimum();
	}
	
	public T max() {
		return this.range.getMaximum();
	}
	
	public Range<T> cloneWithOtherMax(T max){
		return new Range<>(this.min(), max);
	}
	
	public Range<T> cloneWithOtherMin(T min){
		return new Range<>(min, this.max());
	}
	
	public boolean contains(T element) {
		return this.range.contains(element);
	}
	
	public boolean after(T element) {
		return this.range.isAfter(element);
	}
	
	public boolean before(T element) {
		return this.range.isBefore(element);
	}
	
	public boolean startedBy(T element) {
		return this.range.isStartedBy(element);
	}
	
	public boolean endedBy(T element) {
		return this.range.isEndedBy(element);
	}
	
	public boolean contains(Range<T> otherRange) {
		return this.range.containsRange(otherRange.range);
	}
	
	public boolean overlappedBy(Range<T> otherRange) {
		return this.range.isOverlappedBy(otherRange.range);
	}
	
	public boolean after(Range<T> otherRange) {
		return this.range.isAfterRange(otherRange.range);
	}
	
	public boolean before(Range<T> otherRange) {
		return this.range.isBeforeRange(otherRange.range);
	}
	
	@Override
    public boolean equals(final Object obj) {
        if (obj == this) {
            return true;
        } else if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        } else {
        	return this.range.equals(((Range<?>) obj).range);
        }
	}
	
	@Override
    public int hashCode() {
		return this.range.hashCode();
	}
	
	@Override
    public String toString() {
		return this.range.toString();
	}
}

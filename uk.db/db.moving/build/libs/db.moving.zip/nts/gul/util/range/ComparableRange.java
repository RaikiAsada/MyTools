package nts.gul.util.range;

import static java.util.stream.Collectors.*;
import static nts.gul.util.range.RangeDuplication.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import lombok.RequiredArgsConstructor;
import lombok.val;

public interface ComparableRange<S extends ComparableRange<S, T>, T extends Comparable<T>> {

	/**
	 * Returns start value of range.
	 * @return start
	 */
	T start();
	
	/**
	 * Returns end value of range.
	 * @return end
	 */
	T end();
	
	/**
	 * Returns next value of start.
	 * @param isIncrement true if incremented value needed
	 * @return next value of start
	 */
	T startNext(boolean isIncrement);
	
	/**
	 * Returns next value of end.
	 * @param isIncrement true if incremented value needed
	 * @return next value of end
	 */
	T endNext(boolean isIncrement);
	
	/**
	 * Creates new instance.
	 * @param newStart new start
	 * @param newEnd new end
	 * @return new instance
	 */
	S newSpan(T newStart, T newEnd);
	
	/**
	 * Compare ranges.
	 * @param other other range
	 * @return RangeDuplication state of duplication
	 */
	@SuppressWarnings("unchecked")
	default RangeDuplication compare(S other) {
		
		if (this.sameStart(other) && this.sameEnd(other)) {
			return SAME_COMPLETE;
		}
		
		if (this.contains(other)) {
			if (this.sameStart(other)) {
				return BASE_CONTAINS_SAME_START;
			} else if (this.sameEnd(other)) {
				return BASE_CONTAINS_SAME_END;
			} else {
				return BASE_CONTAINS_COMPLETE;
			}
		}
		
		if (other.contains((S)this)) {
			if (this.sameStart(other)) {
				return BASE_CONTAINED_SAME_START;
			} else if (this.sameEnd(other)) {
				return BASE_CONTAINED_SAME_END;
			} else {
				return BASE_CONTAINED_COMPLETE;
			}
		}
		
		if (other.end().equals(this.start())) {
			return CONTINUOUS_BEFORE_BASE;
		}
		
		if (other.isAdjacentBefore((S)this)) {
			return BASE_AFTER_COMPARED;
		}
		
		if (this.end().equals(other.start())) {
			return CONTINUOUS_AFTER_BASE;
		}
		
		if (other.isAdjacentAfter((S)this)) {
			return BASE_BEFORE_COMPARED;
		}
		
		if (this.isBefore(other)) {
			return BASE_BEFORE_COMPARED;
		}
		
		if (this.isAfter(other)) {
			return BASE_AFTER_COMPARED;
		}
		
		if (this.contains(other.start())) {
			return START_SANDWITCHED_BETWEEN_BASE;
		}
		
		if (this.contains(other.end())) {
			return END_SANDWITCHED_BETWEEN_BASE;
		}
		
		throw new RuntimeException("unknown State Start:End " + this.start().toString() + ":" + this.end().toString() + "，Start:End" + other.start().toString() + ":" + other.end().toString());
	}
	
	/**
	 * Returns true if this range contains a given point.
	 * @param point point
	 * @return result
	 */
	default boolean contains(T point) {
		return this.start().compareTo(point) <= 0 && this.end().compareTo(point) >= 0;
	}
	
	/**
	 * Returns true if this range contains a given range.
	 * @param other range to be compared
	 * @return　result
	 */
	default boolean contains(S other) {
		return this.start().compareTo(other.start()) <= 0 && this.end().compareTo(other.end()) >= 0;
	}

	/**
	 * Returns true if start of this range is equal to start of a given range.
	 * @param other range to be compared
	 * @return　result
	 */
	default boolean sameStart(S other) {
		return this.start().equals(other.start());
	}
	
	/**
	 * Returns true if end of this range is equal to end of a given range.
	 * @param other range to be compared
	 * @return result
	 */
	default boolean sameEnd(S other) {
		return this.end().equals(other.end());
	}
	
	/**
	 * Returns true if this range is before given range.
	 * @param other range to be compared
	 * @return result
	 */
	default boolean isBefore(S other) {
		return this.end().compareTo(other.start()) < 0;
	}
	
	/**
	 * Returns true if this range is after given range.
	 * @param other range to be compared
	 * @return result
	 */
	default boolean isAfter(S other) {
		return this.start().compareTo(other.end()) > 0;
	}
	
	/**
	 * Returns true if this range is adjacent before given range.
	 * @param other range to be compared
	 * @return result
	 */
	default boolean isAdjacentBefore(S other) {
		return this.endNext(true).equals(other.start());
	}
	
	/**
	 * Returns true if this range is adjacent after given range.
	 * @param other range to be compared
	 * @return result
	 */
	default boolean isAdjacentAfter(S other) {
		return other.endNext(true).equals(this.start());
	}
	
	default PointComparator<T> isStart() {
		return new PointComparator<>(this.start());
	}
	
	default PointComparator<T> isEnd() {
		return new PointComparator<>(this.end());
	}
	
	/**
	 * Returns true if start of this rannge is before given range.
	 * @param other range to be compared
	 * @return result
	 */
	default boolean startIsBefore(S other) {
		return this.start().compareTo(other.start()) < 0;
	}
	
	/**
	 * Returns true if end
	 * @param other
	 * @return
	 */
	default boolean endIsAfter(S other) {
		return this.end().compareTo(other.end()) > 0;
	}

	default S cutOffWithNewStart(T newStart) {
		if (this.contains(newStart)) {
			return this.newSpan(newStart, this.end());
		}
		
		return this.newSpan();
	}
	
	default S cutOffWithNewEnd(T newEnd) {
		if (this.contains(newEnd)) {
			return this.newSpan(this.start(), newEnd);
		}
		
		return this.newSpan();
	}
	
	default S newSpan() {
		return this.newSpan(this.start(), this.end());
	}
	
	default List<S> subtract(S subtractor) {
		val duplication = this.compare(subtractor);
		
		if (!duplication.isDuplicated()) {
			return Arrays.asList(this.newSpan());
		}
		
		if(duplication.isContinuous()) {
			if(duplication == CONTINUOUS_AFTER_BASE) {
				return Arrays.asList(newSpan(this.start(), subtractor.start()));
			}
			if(duplication == CONTINUOUS_BEFORE_BASE) {
				return Arrays.asList(newSpan(subtractor.end(), this.end()));
			}
		}
		
		if (duplication.isFullyIncluded()) {
			return Collections.emptyList();
		}
		
		if (duplication == BASE_CONTAINS_COMPLETE) {
			return Arrays.asList(
					newSpan(this.start(), subtractor.start()),
					newSpan(subtractor.end(), this.end()));
		}
		
		if (duplication == BASE_CONTAINS_SAME_END
				|| duplication == START_SANDWITCHED_BETWEEN_BASE) {
			return Arrays.asList(newSpan(this.start(), subtractor.start()));
		}
		
		if (duplication == BASE_CONTAINS_SAME_START
				|| duplication == END_SANDWITCHED_BETWEEN_BASE) {
			return Arrays.asList(newSpan(subtractor.end(), this.end()));
		}
		
		return Collections.emptyList();
	}

	default List<S> subtract(Collection<S> subtractors) {
		return subtract(subtractors,true);
	}
	
	/**
	 * 
	 * @param subtractors
	 * @param isDiscrete　ture; 時間・時間帯など, false:日付など
	 * @return
	 */
	default List<S> subtract(Collection<S> subtractors, boolean isDiscrete) {
		val substractorsList = subtractors.stream().collect(toList());
		@SuppressWarnings("unchecked")
		val subtractedData = subtract(Arrays.asList((S) this), substractorsList);
		
		return isDiscrete ?  getDiscreteResult(this, subtractedData, substractorsList) 
									 : subtractedData;
	}

	static <S extends ComparableRange<S, T>, T extends Comparable<T>> List<S> getDiscreteResult(
			ComparableRange<S , T> own, List<S> subtractedBaseData,List<S> targets){
		return subtractedBaseData.stream()
				.map(base -> shiftIfTargetConatainBase(own, targets, base))
				.filter(shiftedBase -> !shiftedBase.isReversed())
				.collect(toList());
	}

	default  boolean isReversed() {
		return this.start().compareTo(this.end()) > 0;
	}
	
	static  <S extends ComparableRange<S, T>, T extends Comparable<T>> S shiftIfTargetConatainBase(
			ComparableRange<S , T> own, List<S> targets, S base) {
		//ベースのStartをズラすかチェック
		boolean needShiftBaseStart = targets.stream()
				.anyMatch(target -> target.end().equals(base.start()));
		
		//ベースのEndをズラすかチェック		
		boolean needShiftBaseEnd = targets.stream()
				.anyMatch(target -> target.start().equals(base.end()));
		
		return own.newSpan(
					needShiftBaseStart ? base.startNext(true) : base.start(),
					needShiftBaseEnd ? base.endNext(false) : base.end()
				);
	}
	
	static <S extends ComparableRange<S, T>, T extends Comparable<T>> List<S> subtract(
			List<S> subtracteds,
			List<S> subtractors) {
		
		if (subtractors.isEmpty()) {
			return subtracteds;
		}
		
		// まず、subtractorsの先頭要素でsubtractする。
		// すると、subtractedが増える（かもしれない）ので、それら全てに対して、残りのsubtractorsを再帰的に処理
		val currentSubtractor = subtractors.get(0);
		val currentResults = subtracteds.stream()
				.flatMap(s -> s.subtract(currentSubtractor).stream())
				.collect(toList());
		
		val remainSubtractors = subtractors.stream().skip(1).collect(toList());
		return subtract(currentResults, remainSubtractors);
	}
	
	default S join(S other) {
		T start = this.start().compareTo(other.start()) < 0
				? this.start() : other.start();
		T end = this.end().compareTo(other.end()) > 0
				? this.end() : other.end();
		return newSpan(start, end);
	}
	
	@RequiredArgsConstructor
	public static class PointComparator<T extends Comparable<T>> {
		
		private final T point;
		
		public boolean before(T other) {
			return this.point.compareTo(other) < 0;
		}
		
		public boolean beforeOrEqual(T other) {
			return this.point.compareTo(other) <= 0;
		}
		
		public boolean after(T other) {
			return this.point.compareTo(other) > 0;
		}
		
		public boolean afterOrEqual(T other) {
			return this.point.compareTo(other) >= 0;
		}
	}
	
	/**
	 * コレクション内のComparableRange要素がお互いに全く重複していなければ true
	 * @param list1
	 * @param list2
	 * @return
	 */
	public static <S extends ComparableRange<S, T>, T extends Comparable<T>> boolean isMutuallyExclusive(Collection<S> ranges) {
		
		val list = new ArrayList<>(ranges);
		
		for (int i = 0; i < list.size(); i++) {
			S range1 = list.get(i);
			
			for (int j = i + 1; j < list.size(); j++) {
				S range2 = list.get(j);
				
				if (range1.compare(range2).isDuplicated()) {
					return false;
				}
			}
		}
		
		return true;
	}
}

package nts.gul.util.range;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum RangeDuplication {
	/**
	 * BASE *-------*
	 * COMP *-------*
	 */
	SAME_COMPLETE,
	
	/**
	 * BASE *-------*
	 * COMP   *---*
	 */
	BASE_CONTAINS_COMPLETE,
	
	/**
	 * BASE *-------*
	 * COMP *----*
	 */
	BASE_CONTAINS_SAME_START,
	
	/**
	 * BASE *-------*
	 * COMP    *----*
	 */
	BASE_CONTAINS_SAME_END,
	
	/**
	 * BASE   *---*
	 * COMP *-------*
	 */
	BASE_CONTAINED_COMPLETE,
	
	/**
	 * BASE *----*
	 * COMP *-------*
	 */
	BASE_CONTAINED_SAME_START,
	
	/**
	 * BASE    *----*
	 * COMP *-------*
	 */
	BASE_CONTAINED_SAME_END,
	
	/**
	 * BASE *---*
	 * COMP     *---*
	 */
	CONTINUOUS_AFTER_BASE,
	
	/**
	 * BASE     *---*
	 * COMP *---*
	 */
	CONTINUOUS_BEFORE_BASE,
	
	/**
	 * BASE *---*
	 * COMP        *---*
	 */
	BASE_BEFORE_COMPARED,
	
	/**
	 * BASE        *---*
	 * COMP *---*
	 */
	BASE_AFTER_COMPARED,
	
	/**
	 * BASE *----*
	 * COMP    *-----*
	 */
	START_SANDWITCHED_BETWEEN_BASE,
	
	/**
	 * BASE    *-----*
	 * COMP *----*
	 */
	END_SANDWITCHED_BETWEEN_BASE,
	
	;
	
	/**
	 * 重複している
	 */
	private static final Set<RangeDuplication> DUPLICATED = new HashSet<>(Arrays.asList(
			SAME_COMPLETE,
			BASE_CONTAINS_COMPLETE,
			BASE_CONTAINS_SAME_START,
			BASE_CONTAINS_SAME_END,
			BASE_CONTAINED_COMPLETE,
			BASE_CONTAINED_SAME_START,
			BASE_CONTAINED_SAME_END,
			CONTINUOUS_AFTER_BASE,
			CONTINUOUS_BEFORE_BASE,
			START_SANDWITCHED_BETWEEN_BASE,
			END_SANDWITCHED_BETWEEN_BASE
			));

	/**
	 * COMPを完全に包含している
	 */
	private static final Set<RangeDuplication> FULLY_INCLUDING = new HashSet<>(Arrays.asList(
			SAME_COMPLETE,
			BASE_CONTAINS_COMPLETE,
			BASE_CONTAINS_SAME_START,
			BASE_CONTAINS_SAME_END
			));

	/**
	 * COMPによって完全に包含されている
	 */
	private static final Set<RangeDuplication> FULLY_INCLUDED = new HashSet<>(Arrays.asList(
			SAME_COMPLETE,
			BASE_CONTAINED_COMPLETE,
			BASE_CONTAINED_SAME_START,
			BASE_CONTAINED_SAME_END
			));
	
	public boolean isDuplicated() {
		return DUPLICATED.contains(this);
	}
	
	public boolean isContinuous() {
		return this == CONTINUOUS_AFTER_BASE
				|| this == CONTINUOUS_BEFORE_BASE;
	}
	
	public boolean isFullyIncluding() {
		return FULLY_INCLUDING.contains(this);
	}
	
	public boolean isFullyIncluded() {
		return FULLY_INCLUDED.contains(this);
	}
}

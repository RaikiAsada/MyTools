package nts.gul.util.logical.predicate;

import java.util.Arrays;
import java.util.Collection;
import java.util.function.Predicate;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public abstract class PredicateSet<T> {

	protected final Collection<T> values;

	public abstract boolean operate(Predicate<T> predicate);
	
	@SafeVarargs
	public static <T> PredicateSet<T> and(T... values) {
		return new AndPredicateSet<>(Arrays.asList(values));
	}
	
	@SafeVarargs
	public static <T> PredicateSet<T> or(T... values) {
		return new OrPredicateSet<>(Arrays.asList(values));
	}
	
	@SafeVarargs
	public static <T> PredicateSet<T> none(T... values) {
		return new NonePredicateSet<>(Arrays.asList(values));
	}
}

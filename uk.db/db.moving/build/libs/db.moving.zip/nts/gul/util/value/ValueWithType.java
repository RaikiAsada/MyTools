package nts.gul.util.value;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Getter;

public class ValueWithType {

	@Getter
	private final Type type;
	private final Object value;
	
	public ValueWithType(LocalDate value) {
		this.type = Type.DATE;
		this.value = value;
	}
	
	public ValueWithType(LocalDateTime value) {
		this.type = Type.DATETIME;
		this.value = value;
	}
	
	public ValueWithType(Boolean value) {
		this.type = Type.BOOLEAN;
		this.value = value;
	}
	
	public ValueWithType(String value) {
		this.type = Type.TEXT;
		this.value = value;
	}
	
	public ValueWithType(BigDecimal value) {
		this.type = Type.NUMBER;
		this.value = value;
	}
	
	public ValueWithType(Object value) {
		this.type = Type.UNKNOWN;
		this.value = value;
	}
	
	public ValueWithType() {
		this.type = Type.UNKNOWN;
		this.value = null;
	}
	
	public static ValueWithType asNull() {
		return new ValueWithType();
	}
	
	public String getText() {
		return (String) this.value;
	}
	
	public LocalDate getDate() {
		return (LocalDate) this.value;
	}
	
	public LocalDateTime getDateTime() {
		return (LocalDateTime) this.value;
	}
	
	public BigDecimal getDecimal() {
		return (BigDecimal) this.value;
	}
	
	public Boolean getBoolean() {
		return (Boolean) this.value;
	}
	
	public boolean isNull() {
		return this.value == null;
	}
	
	public Object getObject() {
		return this.value;
	}

	public enum Type {
		TEXT,
		NUMBER,
		DATE,
		DATETIME,
		BOOLEAN,
		NULL,
		UNKNOWN;
	}
}

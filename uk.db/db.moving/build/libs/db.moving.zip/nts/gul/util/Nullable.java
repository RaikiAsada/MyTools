package nts.gul.util;

import java.util.function.Function;

public class Nullable<V> {

	private final V nullableValue;
	
	private Nullable(V value) {
		this.nullableValue = value;
	}
	
	public static <V> Nullable<V> of(V nullableValue) {
		return new Nullable<V>(nullableValue);
	}
	
	public static <V, R> R get(V nullableValue, Function<V, R> mapper) {
		return of(nullableValue).get(mapper);
	}
	
	public V get() {
		return this.nullableValue;
	}
	
	public <R> R get(Function<V, R> mapper) {
		return this.map(mapper).get();
	}
	
	public boolean isNull() {
		return this.nullableValue == null;
	}
	
	public boolean isPresent() {
		return this.nullableValue != null;
	}
	
	public <R> Nullable<R> map(Function<V, R> mapper) {
		if (this.isNull()) {
			return of(null);
		}
		
		return of(mapper.apply(this.nullableValue));
	}
}

package nts.gul.util;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.stream.Stream;

/**
 * Java8のOptionalのAPIがしょぼいのでサポートしたい
 */
public final class OptionalUtil {

	public static <T> Stream<T> stream(Optional<T> opt) {
		return opt.isPresent() ? Stream.of(opt.get()) : Stream.empty();
	}

	/**
	 * 2つのOptionalが同時にisPresentな場合の処理を書くための結合メソッド
	 * @param op1
	 * @param op2
	 * @param <O1>
	 * @param <O2>
	 * @return
	 */
	public static <O1, O2> AndOptional<O1, O2> and(Optional<O1> op1, Optional<O2> op2) {
		return AndOptional.of(op1, op2);
	}

	@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
	public static class AndOptional<O1, O2> {

		private final O1 op1;
		private final O2 op2;

		static <O1, O2> AndOptional<O1, O2> of(Optional<O1> op1, Optional<O2> op2) {
			return new AndOptional<>(op1.orElse(null), op2.orElse(null));
		}

		/**
		 * op1とop2が同時にisPresentな場合だけ変換する
		 * @param mapper
		 * @param <T>
		 * @return
		 */
		public <T> Optional<T> map(BiFunction<O1, O2, T> mapper) {
			if (isPresent()) {
				return Optional.of(mapper.apply(op1, op2));
			} else {
				return Optional.empty();
			}
		}

		/**
		 * op1とop2が同時にisPresentな場合だけ実行する
		 * @param consumer
		 */
		public void ifPresent(BiConsumer<O1, O2> consumer) {
			if (isPresent()) {
				consumer.accept(op1, op2);
			}
		}

		public boolean isPresent() {
			return op1 != null && op2 != null;
		}
	}
}

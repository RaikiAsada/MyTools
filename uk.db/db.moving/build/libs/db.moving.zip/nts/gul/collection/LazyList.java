package nts.gul.collection;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import nts.gul.util.value.LazyValue;

/**
 * LazyList
 * 
 * @param <TElement>
 * @see <a href="https://github.com/ns-codefarm/NtsCommons/blob/develop/products/nts.gul/src/test/java/nts/gul/collection/LazyListTest.java">How to use (test code)</a>
 */
public class LazyList<TElement> implements List<TElement> {
	
	private LazyValue<List<TElement>> lazyList;
	
	public LazyList(Supplier<List<TElement>> listLoader) {
		this.lazyList = new LazyValue<>(listLoader);
	}

	public static <TOriginal, TMapped> LazyList<TMapped> withMap(
			Supplier<List<TOriginal>> listLoader,
			Function<TOriginal, TMapped> mapper) {
		
		return new LazyList<>(() -> listLoader.get().stream()
				.map(mapper)
				.collect(Collectors.toList()));
	}

	@Override
	public boolean add(TElement e) {
		return this.lazyList.get().add(e);
	}

	@Override
	public void add(int index, TElement e) {
		this.lazyList.get().add(index, e);
	}

	@Override
	public boolean addAll(Collection<? extends TElement> c) {
		return this.lazyList.get().addAll(c);
	}

	@Override
	public boolean addAll(int index, Collection<? extends TElement> c) {
		return this.lazyList.get().addAll(index, c);
	}

	@Override
	public void clear() {
		this.lazyList.get().clear();
	}

	@Override
	public boolean contains(Object o) {
		return this.lazyList.get().contains(o);
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return this.lazyList.get().containsAll(c);
	}

	@Override
	public TElement get(int index) {
		return this.lazyList.get().get(index);
	}

	@Override
	public int indexOf(Object o) {
		return this.lazyList.get().indexOf(o);
	}

	@Override
	public boolean isEmpty() {
		return this.lazyList.get().isEmpty();
	}

	@Override
	public Iterator<TElement> iterator() {
		return this.lazyList.get().iterator();
	}

	@Override
	public int lastIndexOf(Object o) {
		return this.lazyList.get().lastIndexOf(o);
	}

	@Override
	public ListIterator<TElement> listIterator() {
		return this.lazyList.get().listIterator();
	}

	@Override
	public ListIterator<TElement> listIterator(int index) {
		return this.lazyList.get().listIterator(index);
	}

	@Override
	public boolean remove(Object o) {
		return this.lazyList.get().remove(o);
	}

	@Override
	public TElement remove(int index) {
		return this.lazyList.get().remove(index);
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		return this.lazyList.get().removeAll(c);
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		return this.lazyList.get().retainAll(c);
	}

	@Override
	public TElement set(int index, TElement element) {
		return this.lazyList.get().set(index, element);
	}

	@Override
	public int size() {
		return this.lazyList.get().size();
	}

	@Override
	public List<TElement> subList(int fromIndex, int toIndex) {
		return this.lazyList.get().subList(fromIndex, toIndex);
	}

	@Override
	public Object[] toArray() {
		return this.lazyList.get().toArray();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		return this.lazyList.get().toArray(a);
	}
}

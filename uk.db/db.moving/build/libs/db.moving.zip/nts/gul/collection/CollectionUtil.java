package nts.gul.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Utilities for collection
 * 
 * @see <a href="https://github.com/ns-codefarm/NtsCommons/blob/develop/products/nts.gul/src/test/java/nts/gul/collection/CollectionUtilTest.java">How to use (test code)</a>
 */
public class CollectionUtil {
	
	/**
	 * Checks if is empty.
	 *
	 * @param list the list
	 * @return true, if is empty
	 */
	public static boolean isEmpty(Collection<?> list) {
		return list == null || list.size() == 0;
	}
	
	/**
	 * Partition by size.
	 *
	 * @param <T> the generic type
	 * @param list the list
	 * @param size the size
	 * @return the collection
	 */
	public static <T> Collection<List<T>> partitionBySize(Collection<T> list, int size) {
		final AtomicInteger counter = new AtomicInteger(0);
		return list.stream().collect(Collectors.groupingBy(it -> counter.getAndIncrement() / size)).values();
	}
	
	public static <T> void split(List<T> source, int unitSize, Consumer<List<T>> consumer) {
		int startIndex;
        int nextStartIndex = 0;
		int sourceSize = source.size();
		
		do {
            startIndex = nextStartIndex;
            nextStartIndex = Math.min(startIndex + unitSize, sourceSize);
			List<T> subList = source.subList(startIndex, nextStartIndex);
            if (subList.size() == 0) {
                return;
            }
            consumer.accept(subList);
		} while (nextStartIndex < sourceSize);
	}
	
	public static <T> void split(Set<T> source, int unitSize, Consumer<Set<T>> consumer) {
		int startIndex;
        int nextStartIndex = 0;
		int sourceSize = source.size();
		List<T> sourceL = new ArrayList<>(source);
		do {
            startIndex = nextStartIndex;
            nextStartIndex = Math.min(startIndex + unitSize, sourceSize);
            Set<T> subList = sourceL.stream().skip(startIndex)
            		.limit(unitSize).collect(Collectors.toSet());
            		//subList(startIndex, nextStartIndex);
            if (subList.size() == 0) {
                return;
            }
            consumer.accept(subList);
		} while (nextStartIndex < sourceSize);
	}

	public static <T, V> void split(Map<T, V> source, int unitSize, Consumer<Map<T, V>> consumer) {
		int startIndex;
        int nextStartIndex = 0;
		int sourceSize = source.size();
		List<Entry<T, V>> set = new ArrayList<>(source.entrySet());
		
		do {
            startIndex = nextStartIndex;
            nextStartIndex = Math.min(startIndex + unitSize, sourceSize);
            Map<T, V> subMap = set.stream().skip(startIndex)
            		.limit(unitSize).collect(Collectors.toMap(k -> k.getKey(), v -> v.getValue()));
            		//subList(startIndex, nextStartIndex);
            if (subMap.size() == 0) {
                return;
            }
            consumer.accept(subMap);
		} while (nextStartIndex < sourceSize);
	}
}

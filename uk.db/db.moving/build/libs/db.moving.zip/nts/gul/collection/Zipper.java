package nts.gul.collection;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import lombok.Value;

public class Zipper {

	public static <A, B> Stream<ZippedItem<A, Optional<B>>> based(
			Collection<A> base,
			Collection<B> target,
			Function<A, Object> baseIdGetter,
			Function<B, Object> targetIdGetter) {
		
		Map<Object, B> targetsMap = target.stream()
				.collect(Collectors.toMap(t -> targetIdGetter.apply(t), t -> t));
		
		return base.stream()
				.map(a -> {
					B b = targetsMap.get(baseIdGetter.apply(a));
					return new ZippedItem<>(a, Optional.ofNullable(b));
				});
	}
	
	
	@Value
	public static class ZippedItem<A, B> {
		private final A a;
		private final B b;
	}
}

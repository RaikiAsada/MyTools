package nts.gul.collection;

import lombok.AllArgsConstructor;

/**
 * Easy access to object array's element (without casting)
 */
@AllArgsConstructor
public class ObjectArray {

	private final Object[] source;
	
	/**
	 * Returns element indicated by the index.
	 * @param index index
	 * @return element
	 */
	@SuppressWarnings("unchecked")
	public <E> E at(int index) {
		return (E)this.source[index];
	}
}

package nts.gul.collection;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import nts.gul.util.value.LazyValue;

public class LazySet<TElement> implements Set<TElement> {
	
	private LazyValue<Set<TElement>> lazySet;
	
	public LazySet(Supplier<Set<TElement>> listLoader) {
		this.lazySet = new LazyValue<>(listLoader);
	}

	public static <TOriginal, TMapped> LazySet<TMapped> withMap(
			Supplier<List<TOriginal>> setLoader,
			Function<TOriginal, TMapped> mapper) {
		
		return new LazySet<>(() -> setLoader.get().stream()
				.map(mapper)
				.collect(Collectors.toSet()));
	}

	@Override
	public boolean add(TElement e) {
		return this.lazySet.get().add(e);
	}

	@Override
	public boolean addAll(Collection<? extends TElement> c) {
		return this.lazySet.get().addAll(c);
	}

	@Override
	public void clear() {
		this.lazySet.get().clear();
	}

	@Override
	public boolean contains(Object o) {
		return this.lazySet.get().contains(o);
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return this.lazySet.get().containsAll(c);
	}

	@Override
	public boolean isEmpty() {
		return this.lazySet.get().isEmpty();
	}

	@Override
	public Iterator<TElement> iterator() {
		return this.lazySet.get().iterator();
	}

	@Override
	public boolean remove(Object o) {
		return this.lazySet.get().remove(o);
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		return this.lazySet.get().removeAll(c);
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		return this.lazySet.get().retainAll(c);
	}

	@Override
	public int size() {
		return this.lazySet.get().size();
	}

	@Override
	public Object[] toArray() {
		return this.lazySet.get().toArray();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		return this.lazySet.get().toArray(a);
	}
}

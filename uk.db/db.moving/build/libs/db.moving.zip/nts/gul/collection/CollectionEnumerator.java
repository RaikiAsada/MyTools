package nts.gul.collection;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import lombok.RequiredArgsConstructor;
import lombok.val;

/**
 * Enumerates elements in collection.
 *
 * @param <E> type of element in collectin
 */
@RequiredArgsConstructor
public class CollectionEnumerator<E> {
	
	private final Object maybeCollection;
	
	private final Class<E> typeOfElement;
	
	public static <E> CollectionEnumerator<E> enumerate(Object maybeCollection, Class<E> typeOfElement) {
		return new CollectionEnumerator<>(maybeCollection, typeOfElement);
	}
	
	@SuppressWarnings("unchecked")
	public CollectionEnumerator<E> ifSet(Consumer<E> processor) {
		
		if (this.maybeCollection instanceof Set<?>) {
			((Set<E>)this.maybeCollection).forEach(element -> {
				if (this.typeOfElement.isAssignableFrom(element.getClass())) {
					processor.accept(element);
				}
			});
		}
		
		return this;
	}
	
	public CollectionEnumerator<E> ifList(BiConsumer<E, Integer> processor) {
		
		if (this.maybeCollection instanceof List<?>) {
			@SuppressWarnings("unchecked")
			val collection = (List<E>)this.maybeCollection;
			for (int i = 0; i < collection.size(); i++) {
				val element = collection.get(i);
				if (this.typeOfElement.isAssignableFrom(element.getClass())) {
					processor.accept(element, i);
				}
			}
		}
		
		return this;
	}
	
	@SuppressWarnings("unchecked")
	public CollectionEnumerator<E> ifMap(Consumer<Map.Entry<?, E>> processor) {
		
		if (this.maybeCollection instanceof Map<?, ?>) {
			((Map<?, E>)this.maybeCollection).entrySet().forEach(entry -> {
				if (this.typeOfElement.isAssignableFrom(entry.getValue().getClass())) {
					processor.accept(entry);
				}
			});
		}
		
		return this;
	}
}

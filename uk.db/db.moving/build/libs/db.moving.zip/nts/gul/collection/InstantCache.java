package nts.gul.collection;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * オブジェクトのキャッシュ機構を簡単に作るための基底クラス
 * 
 * @param <K> class of key
 * @param <V> class of value
 */
public abstract class InstantCache<K, V> {

	private final Map<K, Optional<V>> cache = new ConcurrentHashMap<>();
	
	/**
	 * Load new value anyway.
	 * 
	 * @param key key
	 * @return value optional
	 */
	protected abstract Optional<V> loadNewValue(K key);
	
	protected Optional<V> getValue(K key) {
		
		return this.cache.computeIfAbsent(
				key,
				k -> this.loadNewValue(k));
	}
}

package nts.gul.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;

import lombok.val;

/**
 * Extended HashMap has list as element.
 *
 * @param <K> key
 * @param <E> element
 */
public class ListHashMap<K, E> extends HashMap<K, List<E>> {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;
	
	public static <K, E> ListHashMap<K, E> create(List<E> elements, Function<E, K> keyGetter) {
		val map = new ListHashMap<K, E>();
		elements.forEach(e -> map.addElement(keyGetter.apply(e), e));
		return map;
	}
	
	/**
	 * Add element.
	 * 
	 * @param key key
	 * @param element element
	 */
	public void addElement(K key, E element) {
		if (!this.containsKey(key)) {
			this.put(key, new ArrayList<>());
		}
		
		this.get(key).add(element);
	}
}

package nts.gul.collection;

import java.util.HashMap;

public class KeyObjectHashMap extends HashMap<String, Object> {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

    public void put(String key, int value) {
        super.put(key, Integer.valueOf(value));
    }

    public void put(String key, long value) {
        super.put(key, Long.valueOf(value));
    }

    public void put(String key, float value) {
        super.put(key, Float.valueOf(value));
    }

    public void put(String key, double value) {
        super.put(key, Double.valueOf(value));
    }

    public void put(String key, boolean value) {
        super.put(key, Boolean.valueOf(value));
    }

    public void put(String key, char value) {
        super.put(key, Character.valueOf(value));
    }

    public void put(String key, String value) {
        super.put(key, value);
    }
    
    public int getInt(String key) {
        Object obj = get(key);
    
        try {
            if(obj instanceof Integer)
                return ((Integer) obj).intValue();
            return Integer.parseInt((String)obj);
        } catch (Exception e) {
            throw new ClassCastException("Identified object is not an Integer: " + obj);
        }
    }

    public long getLong(String key) {
        Object obj = get(key);
    
        try {
            if(obj instanceof Long)
                return ((Long) obj).longValue();
            return Long.parseLong((String)obj);
        } catch (Exception e) {
            throw new ClassCastException("Identified object is not a Long: " + obj);
        }
    }

    public float getFloat(String key) {
        Object obj = get(key);
    
        try {
            if(obj instanceof Float)
                return ((Float) obj).floatValue();
            return Float.parseFloat((String)obj);
        } catch (Exception e) {
            throw new ClassCastException("Identified object is not a Float: " + obj);
        }
    }

    public double getDouble(String key) {
        Object obj = get(key);
    
        try {
            if(obj instanceof Double)
                return ((Double) obj).doubleValue();
            return Double.parseDouble((String)obj);
        } catch (Exception e) {
            throw new ClassCastException("Identified object is not a Double: " + obj);
        }
    }

    public boolean getBoolean(String key) {
        Object obj = get(key);
    
        try {
            if(obj instanceof Boolean)
                return ((Boolean) obj).booleanValue();
            return Boolean.parseBoolean((String)obj);
        } catch (Exception e) {
            throw new ClassCastException("Identified object is not a Boolean: " + obj);
        }
    }

    public char getChar(String key) {
        Object obj = get(key);
    
        try {
            if(obj instanceof Character)
                return ((Character) obj).charValue();
            return ((String)obj).charAt(0);
        } catch (Exception e) {
            throw new ClassCastException("Identified object is not a Character: " + obj);
        }
    }

    public String getString(String key) {
        Object obj = get(key);
    
        try {
            return (String) obj;
        } catch (Exception e) {
            throw new ClassCastException("Identified object is not a String.");
        }
    }
}

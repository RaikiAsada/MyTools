package nts.gul.collection;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public final class IteratorUtil {

    public static <T> List<T> toList(Iterable<T> iterable) {
        return StreamSupport.stream(iterable.spliterator(), false)
                .collect(Collectors.toList());
    }

    /**
     * Iterableを作る
     * @param sources
     * @param process
     * @param <S>
     * @param <R>
     * @return
     */
    public static <S, R> Iterable<R> iterable(Iterable<S> sources, Function<S, R> process) {
        return () -> new ProcessIterator<S, R>(sources.iterator(), process);
    }

    /**
     * Iterableを作る（emptyの要素は除外される）
     * @param sources
     * @param processFilter
     * @param <S>
     * @param <R>
     * @return
     */
    public static <S, R> Iterable<R> iterableFilter(Iterable<S> sources, Function<S, Optional<R>> processFilter) {
        return () -> new FilterIterator<>(sources.iterator(), processFilter);
    }

    /**
     * Iterableを作る（平坦化しつつ）
     * @param sources
     * @param process
     * @param <S>
     * @param <R>
     * @return
     */
    public static <S, R> Iterable<R> iterableFlatten(Iterable<S> sources, Function<S, Iterable<R>> process) {
        Iterable<Iterable<R>> nested = () -> new ProcessIterator<S, Iterable<R>>(sources.iterator(), process);
        return flatten(nested);
    }

    @RequiredArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ProcessIterator<S, R> implements Iterator<R> {

        private final Iterator<S> iterator;
        private final Function<S, R> process;

        @Override
        public boolean hasNext() {
            return iterator.hasNext();
        }

        @Override
        public R next() {
            S source = iterator.next();
            return process.apply(source);
        }
    }

    @RequiredArgsConstructor(access = AccessLevel.PRIVATE)
    public static class FilterIterator<S, R> implements Iterator<R> {

        private final Iterator<S> iterator;
        private final Function<S, Optional<R>> process;

        private R current = null;

        @Override
        public boolean hasNext() {

            while (current == null) {
                if (!iterator.hasNext()) {
                    return false;
                }

                Optional<R> nextOpt = process.apply(iterator.next());
                if (nextOpt.isPresent()) {
                    current = nextOpt.get();
                }
            }

            return true;
        }

        @Override
        public R next() {

            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            R next = current;
            current = null;
            return next;
        }
    }

    /**
     * ネストされたIterableを平坦化する
     * @param nestedIterable
     * @param <T>
     * @return
     */
    public static <T> Iterable<T> flatten(Iterable<Iterable<T>> nestedIterable) {
        return () -> new FlattenIterator<T>(nestedIterable);
    }

    public static class FlattenIterator<T> implements Iterator<T> {

        private final Iterator<Iterable<T>> outerIterator;

        private Iterator<T> currentInnerIterator;

        public FlattenIterator(Iterable<Iterable<T>> nestedIterable) {
            this.outerIterator = nestedIterable.iterator();
        }

        @Override
        public boolean hasNext() {

            if (currentInnerIterator == null) {
                if (!outerIterator.hasNext()) {
                    return false;
                }

                currentInnerIterator = outerIterator.next().iterator();
            }

            if (currentInnerIterator.hasNext()) {
                return true;
            }

            currentInnerIterator = null;
            return hasNext();
        }

        @Override
        public T next() {
            return currentInnerIterator.next();
        }
    }


    /**
     * 2つのIterableを連結する
     * @param a
     * @param b
     * @param <T>
     * @return
     */
    public static <T> Iterable<T> merge(Iterable<T> a, Iterable<T> b) {
        List<Iterable<T>> merged = Arrays.asList(a, b);
        return flatten(merged);
    }
    
    /**
     * 条件に該当するものだけに絞り込む
     * @param <T>
     * @param sources
     * @param filter
     * @return 
     */
    public static <T> Iterable<T> filter(Iterable<T> sources, Predicate<T> filter) {
        return iterableFilter(sources, current -> {
            return filter.test(current)? Optional.of(current): Optional.empty();
        });
    }
}

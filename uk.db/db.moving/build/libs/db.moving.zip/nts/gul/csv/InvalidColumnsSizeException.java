package nts.gul.csv;

import java.util.List;

public class InvalidColumnsSizeException extends ParseCSVException {
	
	private static final long serialVersionUID = 1L;

	private final int standardColumns;
	
	private final int actualColumns;
	
	private final int rowNumber;

	public InvalidColumnsSizeException (int standardColumns, int actualColumns) {
		super();
		this.actualColumns = actualColumns;
		this.standardColumns = standardColumns;
		this.rowNumber = -1;
		this.message = "実際項目数が異なる";
	}
	
	public InvalidColumnsSizeException (int standardColumns, int actualColumns, String message) {
		super();
		this.actualColumns = actualColumns;
		this.standardColumns = standardColumns;
		this.message = message;
		this.rowNumber = -1;
	}
	
	public InvalidColumnsSizeException (int standardColumns, int actualColumns, int row) {
		super();
		this.actualColumns = actualColumns;
		this.standardColumns = standardColumns;
		this.rowNumber = row;
		this.message = "実際項目数が異なる";
	}
	
	public InvalidColumnsSizeException (int standardColumns, int row, List<String> rowRawValues) {
		super();
		this.actualColumns = rowRawValues.size();
		this.standardColumns = standardColumns;
		this.rowNumber = row;
		this.message = "実際項目数が異なる";
		this.rowRawValues = rowRawValues;
	}

	public int getStandardColumns() {
		return standardColumns;
	}

	public int getActualColumns() {
		return actualColumns;
	}
	
	public int getErrorRow() {
		return rowNumber;
	}
	
	public String getMessage() {
		return message;
	}
}

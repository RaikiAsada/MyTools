package nts.gul.csv;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.QuoteMode;

public class NtsCsv {

	protected CSVFormat format = CSVFormat.EXCEL
			.withQuoteMode(QuoteMode.ALL);

	protected Charset charset = Charset.forName("MS932");
	
	protected List<String> headers = new ArrayList<>();

	/**
	 * Create NtsCsvReader/ NtsCsvWriter with format.
	 *
	 * @param format the format
	 * @return the nts csv
	 */
	@SuppressWarnings("unchecked")
	public <T extends NtsCsv> T withFormat(CSVFormat format) {
		this.format = format;
		return (T) this;
	}

	/**
	 * Create NtsCsvReader/ NtsCsvWriter with char set.
	 *
	 * @param charSet the char set
	 * @return the nts csv reader
	 */
	@SuppressWarnings("unchecked")
	public <T extends NtsCsv> T withChartSet(String charSet) {
		this.charset = Charset.forName(charSet);
		return (T) this;
	}

	/**
	 * Create NtsCsvReader/ NtsCsvWriter with char set.
	 *
	 * @param charset the charset
	 * @return the nts csv reader
	 */
	@SuppressWarnings("unchecked")
	public <T extends NtsCsv> T withChartSet(Charset charset) {
		this.charset = charset;
		return (T) this;
	}

	/**
	 * Create NtsCsvReader/ NtsCsvWriter with header.
	 *
	 * @param headers the headers
	 * @return the t
	 */
	@SuppressWarnings("unchecked")
	public <T extends NtsCsv> T withHeader(String... headers) {
		for (String header : headers) {
			this.headers.add(header);
		}
		
		this.format = this.format.withHeader(this.headers.toArray(new String[]{}));
		return (T) this; 
	}

	/**
	 * Create NtsCsvReader/ NtsCsvWriter with header.
	 *
	 * @param headers the headers
	 * @return the t
	 */
	public <T extends NtsCsv> T withHeader(List<String> headers) {
		return this.withHeader(headers.toArray(new String[]{}));
	}
	
	/**
	 * Create NtsCsvReader/ NtsCsvWriter with delimiter character.
	 *
	 * @param delimiter the char for specified delimiter.
	 * @return the t
	 */
	@SuppressWarnings("unchecked")
	public <T extends NtsCsv> T withCharDelimiter(char delimiter) {
		this.format = this.format.withDelimiter(delimiter);
		return (T) this; 
	}
	
	/**
	 * Create NtsCsvReader/ NtsCsvWriter with quote character.
	 *
	 * @param quote the quote
	 * @return the t
	 */
	@SuppressWarnings("unchecked")
	public <T extends NtsCsv> T withQuote(QuoteMode quote) {
		this.format = this.format.withQuoteMode(quote);
		return (T) this;
	}
}

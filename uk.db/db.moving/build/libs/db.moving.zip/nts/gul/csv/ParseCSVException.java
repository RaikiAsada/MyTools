package nts.gul.csv;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ParseCSVException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	protected String message;
	
	protected List<String> rowRawValues;
	
	public ParseCSVException(){
		this.message = "ParseCSVException";
		this.rowRawValues = new ArrayList<>();
	}
	
	public ParseCSVException(String message, List<String> rowData){
		this.message = message;
		this.rowRawValues = new ArrayList<>(rowData);
	}
	
	public List<String> getRowRawValues(){
		return new ArrayList<>(this.rowRawValues);
	}
	
	public void addRowRawValues(List<String> rowData){
		this.rowRawValues = new ArrayList<>(rowData);
	}
	
	public void addRowRawValues(String[] rowData){
		this.rowRawValues = new ArrayList<>(Arrays.asList(rowData));
	}
}

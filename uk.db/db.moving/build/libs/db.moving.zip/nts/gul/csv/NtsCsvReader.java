package nts.gul.csv;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import nts.gul.text.charset.NtsCharset;

public class NtsCsvReader extends NtsCsv {
	
	private boolean columnDiffByRow;
	
	private boolean noHeader;
	
	private boolean utfWithBom;
	
	private Integer columnConstraints;
	
	private boolean skipEmptyRow;

	/**
	 * Instantiates a new nts csv reader.
	 */
	private NtsCsvReader() {
		this.noHeader = false;
		this.utfWithBom = false;
	};

	/**
	 * New reader.
	 *
	 * @return the nts csv reader
	 */
	public static NtsCsvReader newReader() {
		NtsCsvReader reader = new NtsCsvReader();
		reader.format = CSVFormat.EXCEL.withHeader();
		return reader;
	}
	
	public NtsCsvReader withChartSet(NtsCharset charSet) {
		this.charset = Charset.forName(charSet.name);
		if (charsetWithBom(charSet)) {
			this.utfWithBom = true;
		}
		return this;
	}
	
	public NtsCsvReader withCheckColumnsSize(int columnConstraints){
		if (columnConstraints <= 0) {
			throw new IllegalArgumentException("Columns constraint: " + columnConstraints);
		}
		this.columnConstraints = columnConstraints;
		return this;
	}

	public NtsCsvReader withNoHeader() {
		this.format = this.format.withSkipHeaderRecord(true);
		this.noHeader = true;
		return this;
	}
	
	public NtsCsvReader withColumnSizeDiffByRow() {
		this.columnDiffByRow = true;
		return this;
	}
	
	/**
	 * Create NtsCsvReader with header.
	 *
	 * @param skipEmptyLine skip Empty Line option
	 * @return NtsCsvReader
	 */
	public NtsCsvReader skipEmptyLines(boolean skipEmptyLine) {
		this.skipEmptyRow = skipEmptyLine;
		this.format = this.format.withIgnoreEmptyLines(skipEmptyLine);
		return this; 
	}
	
	public CustomCsvReader createCustomCsvReader(InputStream is) {
		return createCustomCsvReaderWithCheckColumnEachRow(is, 0);
	}
	
	public CustomCsvReader createCustomCsvReaderWithCheckColumnEachRow(InputStream is, int columnEachRow) {
		return CustomCsvReader.builder(is)
								.charset(charset)
								.columnDiffByRow(columnDiffByRow)
								.delimiter(format.getDelimiter())
								.noHeader(noHeader)
								.quoteChar(format.getQuoteCharacter())
								.skipEmptyRow(skipEmptyRow)
								.utfWithBom(utfWithBom)
								.headers(headers)
								.columnEachRow(columnEachRow)
								.columnConstraints(columnConstraints);
	}
	
	/**
	 * Parses the.
	 *
	 * @param is the is
	 * @return the iterable
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public CSVParsedResult parse(InputStream is) throws IOException {
		
		return getRecords(this.getParser(is, this.utfWithBom));
	}
	
	/**
	 * Parses With Check Column Each Row.
	 *
	 * @param is the is
	 * @param columnEachRows the column size for each row
	 * @return the iterable
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public CSVParsedResult parseWithCheckColumnEachRow(InputStream is, int columnEachRows) throws IOException {
		
		return getRecordsWithCheckColumnEachRow(this.getParser(is, this.utfWithBom), columnEachRows);
	}
	
	/**
	 * Parses With Check Column Each Row.
	 *
	 * @param is the is
	 * @param isUff8WithBOM is Utf8 with BOM
	 * @param columnEachRows the column size for each row
	 * @return the iterable
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public CSVParsedResult parseWithCheckColumnEachRow(InputStream is, boolean isUff8WithBOM, int columnEachRows) throws IOException {
		
		return getRecordsWithCheckColumnEachRow(this.getParser(is, isUff8WithBOM), columnEachRows);
	}

	/**
	 * Parses the.
	 *
	 * @param is the input stream
	 * @param isUff8WithBOM is UTF8 with BOM
	 * @return the iterable
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public CSVParsedResult parse(InputStream is, boolean isUff8WithBOM) throws IOException {
		return getRecords(this.getParser(is, isUff8WithBOM));
	}
	
	/**
	 * Gets the parser.
	 *
	 * @param is the input stream
	 * @param isUff8WithBOM is UTF8 with BOM
	 * @return the parser
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public CSVParser getParser(InputStream is, boolean isUff8WithBOM) throws IOException {
		Reader reader = null;
		if (isUff8WithBOM && this.charset.equals(Charset.forName("UTF-8"))){
			reader = new InputStreamReader(new BOMInputStream(is, false, ByteOrderMark.UTF_8), this.charset);
		} else {
			reader = new InputStreamReader(is, this.charset);
		}
		return this.format.parse(reader);
	}
	
	private CSVParsedResult getRecords(CSVParser csvRecords) throws IOException {
		return toRecords(csvRecords, 0);
	}
	
	private CSVParsedResult getRecordsWithCheckColumnEachRow(CSVParser csvRecords, int columnEachRows) throws IOException {
		return toRecords(csvRecords, columnEachRows);
	}
	
	private CSVParsedResult toRecords(CSVParser csvRecords, int columnEachRows) throws IOException {
		List<CSVRecord> records = csvRecords.getRecords();
		if (!records.isEmpty()) {
			if(this.noHeader){
				return getRecordsWithNoHeader(records, columnEachRows, csvRecords.getHeaderMap(), false);
			} else {
				return getRecordsWithHeader(records, columnEachRows, csvRecords.getHeaderMap(), false);
			}
		}
		
		return new CSVParsedResult();
	}

	private CSVParsedResult getRecordsWithNoHeader(List<CSVRecord> records, int columnEachRows, Map<String, Integer> headerMaps, boolean headerColumnConstraints) throws IOException{
		
		List<String> headers = new ArrayList<>();
		Map<Integer, String> headerMap = new HashMap<>();
		
		createHeaderMap(records, headers, headerMap);
		
		if (headerColumnConstraints) {
			validateColumnConstraints(headers);
		}
		
		int lineOver = 1;
		CSVParsedResult result = new CSVParsedResult();
		
		lineOver += getFirstRecordInNoHeaderFile(headerMap, headerMaps, result, columnEachRows);
		
		createNoHeaderResult(records, columnEachRows, headerMap, result, lineOver, headers);
		
		return result;
	}
	
	private CSVParsedResult getRecordsWithHeader(List<CSVRecord> records, int columnEachRows, Map<String, Integer> csvHeaderMap, boolean headerColumnConstraints) 
			throws IOException{
		
		List<String> headers = new ArrayList<>();
		Map<Integer, String> headerMap = new HashMap<>();
		
		int skip = createHeaders(csvHeaderMap, headers, headerMap), lineOver = 2;
		
		if (headerColumnConstraints) {
			validateColumnConstraints(headers);
		}
		
		lineOver += countLineIfQuote(headers);
		
		CSVParsedResult result = new CSVParsedResult();

		createWithHeaderResult(records, columnEachRows, headerMap, result, lineOver, headers, skip);
		
		return result;
	}

	private void createHeaderMap(List<CSVRecord> records, List<String> headers, Map<Integer, String> headerMap) {
		int firstRowSize = records.get(0).size();
		if(this.columnDiffByRow){
			firstRowSize = records.stream().mapToInt(r -> r.size()).max().getAsInt();
		}
		while (headers.size() < firstRowSize){
			headerMap.put(headers.size(), "Header" + headers.size());
			headers.add("Header" + headers.size());
		}
	}
	
	private void createWithHeaderResult(List<CSVRecord> records, int columnEachRows, Map<Integer, String> headerMap, CSVParsedResult result, int lineOver, List<String> headers, int skip){
		for (int i = skip; i < records.size(); i++) {
			CSVRecord dRow = records.get(i);
			
			processWithHeaderRow(dRow, columnEachRows, headerMap, result, i+ lineOver, headers);
			
			lineOver += countLineIfQuote(dRow);
		}
	}
	
	private void processWithHeaderRow(CSVRecord dRow, int columnEachRows, Map<Integer, String> headerMap, CSVParsedResult result, int rowNumber, List<String> headers){
		if(!(this.skipEmptyRow && this.isEmptyRow(dRow))){
			if(columnEachRows > 0 && columnEachRows != dRow.size()){
				InvalidColumnsSizeException error = new InvalidColumnsSizeException(columnEachRows, dRow.size(), rowNumber);
				error.addRowRawValues(getRowRawValues(dRow));
				result.addError(error);
			} else {
				NtsCsvRecord record = new NtsCsvRecord(headerMap, rowNumber);
				
				for (int i = 0; i < headers.size(); i++){
					String headerName = headers.get(i);
					record.putColumn(headerName, i < dRow.size() ? dRow.get(headerName) : null);
				}

				result.addRecord(record);
			}	
		}
	}
	
	private void createNoHeaderResult(List<CSVRecord> records, int columnEachRows, Map<Integer, String> headerMap, CSVParsedResult result, int lineOver, List<String> headers){
		for (int i = 0; i < records.size(); i++) {
			CSVRecord dRow = records.get(i);
			
			processNoHeaderRow(dRow, columnEachRows, headerMap, result, i+ lineOver, headers);
			
			lineOver += countLineIfQuote(dRow);
		}
	}
	
	private void processNoHeaderRow(CSVRecord dRow, int columnEachRows, Map<Integer, String> headerMap, CSVParsedResult result, int rowNumber, List<String> headers){
		if(!(this.skipEmptyRow && this.isEmptyRow(dRow))){
			if(columnEachRows > 0 && columnEachRows != dRow.size()){
				InvalidColumnsSizeException error = new InvalidColumnsSizeException(columnEachRows, dRow.size(), rowNumber);
				error.addRowRawValues(getRowRawValues(dRow));
				result.addError(error);
			} else {
				NtsCsvRecord record = new NtsCsvRecord(headerMap, rowNumber);
				
				for (int j = 0; j < headers.size(); j++){
					record.putColumn(headers.get(j), j < dRow.size() ? dRow.get(j) : null);
				}
				result.addRecord(record);
			}	
		}
	}
	
	private int getFirstRecordInNoHeaderFile (Map<Integer, String> headerMap, Map<String, Integer> firstRowMap, CSVParsedResult result, int columnEachRows) {
		if(firstRowMap == null){
			return 0;
		}
		
		int line = 1;
		if(columnEachRows > 0 && columnEachRows != firstRowMap.size()){
			InvalidColumnsSizeException error = new InvalidColumnsSizeException(columnEachRows, firstRowMap.size(), 1);
			error.addRowRawValues(firstRowMap.entrySet().stream()
						.sorted((c1, c2) -> { return c1.getValue().compareTo(c2.getValue()); })
						.map(c -> c.getKey())
						.collect(Collectors.toList()));
			result.addError(error);
		} else {
			NtsCsvRecord record = new NtsCsvRecord(headerMap, 1);
			for (Entry<String, Integer> cell : firstRowMap.entrySet()) {
				record.putColumn(headerMap.get(cell.getValue()), cell.getKey());
				int newLine = cell.getKey().split(this.format.getRecordSeparator()).length;
				if(newLine > line){
					line = newLine;
				}
			}
		
			result.addRecord(record);
		}
			
		return line;
	}
	
	private int countLineIfQuote(List<String> headers){
		int line = 1;
		
		for (String cell : headers) {
			if(!cell.isEmpty()){
				int newLine = cell.split(this.format.getRecordSeparator()).length;
				if(newLine > line){
					line = newLine;
				}
			}
		}
		
		return line - 1;
	}
	
	private int countLineIfQuote(CSVRecord dRow){
		int line = 1;
		Iterator<String> iterator = dRow.iterator();
		while (iterator.hasNext()) {
			String cell = iterator.next();
			if(!cell.isEmpty()){
				int newLine = cell.split(this.format.getRecordSeparator()).length;
				if(newLine > line){
					line = newLine;
				}
			}
		}
		
		return line - 1;
	}
	
	private List<String> getRowRawValues(CSVRecord dRow){
		List<String> data = new ArrayList<>();
		
		dRow.forEach(r -> {
			data.add(r);
		});
		
		return data;
	}

	private int createHeaders(Map<String, Integer> csvHeaderMap, List<String> headers, Map<Integer, String> headerMap) {
		int skip = 0;
		String[] cHeaders = this.format.getHeader();
		
		if (cHeaders != null && cHeaders.length > 0){
			headers.addAll(Arrays.asList(cHeaders));
			skip = 1;
		} else {
			csvHeaderMap.keySet().stream().forEach(ch -> {
				headers.add(ch);
			});
		}
		
		for(int i = 0; i < headers.size(); i++){
			headerMap.put(i, headers.get(i));
		}
		return skip;
	}

	private void validateColumnConstraints(List<String> headers) {
		if(this.columnConstraints != null && headers.size() != this.columnConstraints){
			throw new InvalidColumnsSizeException(this.columnConstraints, headers.size());
		}
	}
	
	private boolean charsetWithBom(NtsCharset charSet) {
		return charSet == NtsCharset.UTF8_WITH_BOM;
	}
	
	private boolean isEmptyRow(CSVRecord dRow){
		Iterator<String> iterator = dRow.iterator();
		while (iterator.hasNext()) {
			String cell = iterator.next();
			if(!cell.isEmpty()){
				return false;
			}
		}
		
		return true;
	}
}

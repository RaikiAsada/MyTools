package nts.gul.csv;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NtsCsvRecord {

	private final Map<String, Object> record;
	private final Map<Integer, String> headers;
	private int rowNumber;
	
	public NtsCsvRecord (Map<Integer, String> headers){
		this(headers, -1);
	}
	
	public NtsCsvRecord (Map<String, Object> record, Map<Integer, String> headers){
		this(record, headers, -1);
	}
	
	public NtsCsvRecord (Map<Integer, String> headers, int rowNumber){
		this(new HashMap<>(), headers, rowNumber);
	}
	
	public NtsCsvRecord (Map<String, Object> record, Map<Integer, String> headers, int rowNumber){
		this.record = record;
		this.headers = headers;
		this.rowNumber = rowNumber;
	}
	
	public List<String> getColumns() {
		return new ArrayList<>(headers.values());
	}
	
	public void putColumn(String name, Object value) {
		this.record.put(name, value);
	}
	
	public Object getColumn(String name) {
		return this.record.get(name);
	}
	
	public Object getColumn(int index) {
		return this.record.get(this.headers.get(index));
	}
	
	public String getColumnAsString(String name) {
		return this.record.get(name).toString();
	}
	
	public Integer getColumnAsInteger(String name) {
		return Integer.parseInt(this.record.get(name).toString());
	}
	
	public Integer getRowNumber() {
		return this.rowNumber;
	}
	
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
	
	public int columnLength(){
		return this.record.size();
	}
	
	protected void merge(NtsCsvRecord record){
		this.record.putAll(record.record);
		this.headers.putAll(record.headers);
	}
}

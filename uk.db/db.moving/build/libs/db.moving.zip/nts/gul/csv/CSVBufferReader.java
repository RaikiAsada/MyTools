package nts.gul.csv;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class CSVBufferReader implements AutoCloseable {

	private static final int SEGMENT = 30000000;
	private RandomAccessFile randomAccess;
	private FileChannel channel;
	private MappedByteBuffer byteBuffer;
	private ByteArrayOutputStream bs = new ByteArrayOutputStream();
	private long from = 0;
	private long to = 0;
	private long bufSize = 0;
	
	private Map<String, List<Line>> filter;
	private long size;
	private byte readByte;
	private boolean openQuote = false;
	private CSVParsedResult result = new CSVParsedResult();
	private Map<String, Object> recordData = new HashMap<>();
	private Map<Integer, String> headerMap = new HashMap<>();
	private int rowNumber = 0;
	private int headerIndex = 0;
	private NtsCsvRecord record = new NtsCsvRecord(recordData, headerMap, rowNumber);
	
	private char delimiter = ',';
	private char quote = '"';
	private String charset = "UTF-8";
	
	public void setDelimiter(char delimiter) {
		this.delimiter = delimiter;
	}
	
	public void setQuote(char quote) {
		this.quote = quote;
	}
	
	public void setCharset(String charset) {
		this.charset = charset;
	}
	
	public CSVBufferReader(File file) {
		this(file, true);
	}
	
	public CSVBufferReader(File file, boolean mapAll) {
		try {
			randomAccess = new RandomAccessFile(file, "r");
			channel = randomAccess.getChannel();
			size = channel.size();
			if (!mapAll && size > SEGMENT) {
				bufSize = SEGMENT;
			} else {
				bufSize = size;
			}
			
			to += bufSize;
			byteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, bufSize);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Read.
	 * @param step
	 * @param total
	 * @param resultConsumer
	 */
	public void read(int step, int total, Consumer<CSVParsedResult> resultConsumer) {
		read(step, total, resultConsumer, null, null);
	}
	
	/**
	 * Read.
	 * @param step
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void read(int step, Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		read(step, -1, resultConsumer, filterColumn, filterValue);
	}
	
	/**
	 * Read.
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void read(Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		read(1000, resultConsumer, filterColumn, filterValue);
	}
	
	/**
	 * Read.
	 * @param step
	 * @param total
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void read(int step, int total, Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		boolean skipHeader, filtered = false, discard = skipHeader = !headerMap.isEmpty();
		int limit = byteBuffer.limit();
		byteBuffer.position(0);
		rowNumber = 0;
		if (filterColumn == null) filtered = true;
		
		for (int i = 0; i < limit; i++) {
			readByte = byteBuffer.get();
			if (readByte == quote) {
				openQuote = !openQuote;
				continue;
			}
			
			if (openQuote) {
				bs.write(readByte);
				continue;
			}
			
			if (readByte == delimiter) {
				if (rowNumber == 0) {
					if (!skipHeader) headerMap.put(headerIndex, getString());
				} else {
					String headerName = headerMap.get(headerIndex);
					String value = null;
					if (!discard) {
						value = getString();
					}
					
					if (filterColumn != null && headerName != null && ((filterColumn instanceof String && headerName.equals(filterColumn)) 
						|| (filterColumn instanceof Integer && headerIndex == (int)filterColumn))) {
						if (value != null && value.equals(filterValue)) {
							filtered = true;
						} else if (value != null && !value.equals(filterValue)) {
							discard = true;
						}
					}
					
					if (value != null) {
						recordData.put(headerName, value);
					}
				}
				
				headerIndex++;
			} else if (readByte == '\r') {
				i++;
				readByte = byteBuffer.get();
				if (readByte == '\n') {
					if (rowNumber == 0) {
						if (!skipHeader) headerMap.put(headerIndex, getString());
					} else {
						String headerName = headerMap.get(headerIndex);
						recordData.put(headerName, getString());
					}
					
					if (filtered) {
						if (record.getRowNumber() != rowNumber) {
							record.setRowNumber(rowNumber);
						}
						
						result.addRecord(record);
					}
					
					rowNumber++;
					if (total != -1 && rowNumber > total) break;
					if (rowNumber % step == 0 && (!result.getRecords().isEmpty() || !result.getErrors().isEmpty())) {
						resultConsumer.accept(result);
						result = new CSVParsedResult();
					}
					
					headerIndex = 0;
					discard = false;
					if (filtered) {
						recordData = new HashMap<>();
						record = new NtsCsvRecord(recordData, headerMap, rowNumber);
						if (filterColumn != null) filtered = false;
					}
				}
			} else if (readByte == '\n') {
				if (rowNumber == 0) {
					if (!skipHeader) headerMap.put(headerIndex, getString());
				} else {
					String headerName = headerMap.get(headerIndex);
					recordData.put(headerName, getString());
				}
				
				if (filtered) {
					if (record.getRowNumber() != rowNumber) {
						record.setRowNumber(rowNumber);
					}
					
					result.addRecord(record);
				}
				
				rowNumber++;
				if (total != -1 && rowNumber > total) break;
				if (rowNumber % step == 0 && (!result.getRecords().isEmpty() || !result.getErrors().isEmpty())) {
					resultConsumer.accept(result);
					result = new CSVParsedResult();
				}
				
				headerIndex = 0;
				discard = false;
				if (filtered) {
					recordData = new HashMap<>();
					record = new NtsCsvRecord(recordData, headerMap, rowNumber);
					if (filterColumn != null) filtered = false;
				}
			} else if (!discard) {
				bs.write(readByte);
			}
		}
		
		if (to < size) {
			from = bufSize;
			bufSize = Math.min(SEGMENT, size - from);
			to += bufSize;
			try {
				byteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, from, bufSize);
				read(step, total, resultConsumer, filterColumn, filterValue);
				return;
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
				
		if (!result.getRecords().isEmpty() || !result.getErrors().isEmpty()) {
			resultConsumer.accept(result);
			result = new CSVParsedResult();
		}
	} 
	
	/**
	 * Read chunk.
	 * @param step
	 * @param total
	 * @param resultConsumer
	 */
	public void readChunk(int step, int total, Consumer<CSVParsedResult> resultConsumer) {
		readChunk(step, total, resultConsumer, null, null);
	}
	
	/**
	 * Read chunk.
	 * @param step
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void readChunk(int step, Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		readChunk(step, -1, resultConsumer, filterColumn, filterValue);
	}
	
	/**
	 * Read chunk.
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void readChunk(Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		readChunk(1000, resultConsumer, filterColumn, filterValue);
	}
	
	/**
	 * Read chunk.
	 * @param step
	 * @param total
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void readChunk(int step, int total, Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		byte[] readBytes = new byte[3000];
		byte markByte;
		int i = 0, bufferSize = byteBuffer.limit(), rowNumber = 0, headerIndex = 0;
		boolean openQuote = false, filtered = false, discard = false;
		if (filterColumn == null) filtered = true;
		byteBuffer.position(0);
		
		while (i < bufferSize) {
			if (byteBuffer.remaining() < 3000) {
				readBytes = new byte[byteBuffer.remaining()];
			}

			byteBuffer.get(readBytes);
			i += readBytes.length;
			
			for (int j = 0; j < readBytes.length; j++) {
				markByte = readBytes[j];
				if (markByte == quote) {
					openQuote = !openQuote;
					continue;
				}
				
				if (openQuote) {
					bs.write(markByte);
					continue;
				}
				
				if (markByte == delimiter) {
					if (rowNumber == 0) {
						headerMap.put(headerIndex, getString());
					} else {
						String headerName = headerMap.get(headerIndex);
						String value = null;
						if (!discard) {
							value = getString();
						}
						
						if (filterColumn != null && headerName != null && ((filterColumn instanceof String && headerName.equals(filterColumn)) 
							|| (filterColumn instanceof Integer && headerIndex == (int)filterColumn))) {
							if (value != null && value.equals(filterValue)) {
								filtered = true;
							} else if (value != null && !value.equals(filterValue)) {
								discard = true;
							}
						}
						
						if (value != null) {
							recordData.put(headerName, value);
						}
					}
					
					headerIndex++;
				} else if (markByte == '\r') {
					j++;
					if (j >= readBytes.length) break;
					markByte = readBytes[j];
					if (markByte == '\n') {
						if (rowNumber == 0) {
							headerMap.put(headerIndex, getString());
						} else {
							String headerName = headerMap.get(headerIndex);
							recordData.put(headerName, getString());
						}
						
						if (filtered) {
							if (record.getRowNumber() != rowNumber) {
								record.setRowNumber(rowNumber);
							}
							
							result.addRecord(record);
						}
						
						rowNumber++;
						if (total != -1 && rowNumber > total) break;
						if (rowNumber % step == 0 && (!result.getRecords().isEmpty() || !result.getErrors().isEmpty())) {
							resultConsumer.accept(result);
							result = new CSVParsedResult();
						}
						
						headerIndex = 0;
						discard = false;
						if (filtered) {
							recordData = new HashMap<>();
							record = new NtsCsvRecord(recordData, headerMap, rowNumber);
							if (filterColumn != null) filtered = false;
						}
					}
				} else if (markByte == '\n') {
					if (rowNumber == 0) {
						headerMap.put(headerIndex, getString());
					} else {
						String headerName = headerMap.get(headerIndex);
						recordData.put(headerName, getString());
					}
					
					if (filtered) {
						if (record.getRowNumber() != rowNumber) {
							record.setRowNumber(rowNumber);
						}
						
						result.addRecord(record);
					}
					
					rowNumber++;
					if (total != -1 && rowNumber > total) break;
					if (rowNumber % step == 0 && (!result.getRecords().isEmpty() || !result.getErrors().isEmpty())) {
						resultConsumer.accept(result);
						result = new CSVParsedResult();
					}
					
					headerIndex = 0;
					discard = false;
					if (filtered) {
						recordData = new HashMap<>();
						record = new NtsCsvRecord(recordData, headerMap, rowNumber);
						if (filterColumn != null) filtered = false;
					}
				} else if (!discard) {
					bs.write(markByte);
				}
			}
		}
		
		if (!result.getRecords().isEmpty() || !result.getErrors().isEmpty()) {
			resultConsumer.accept(result);
			result = new CSVParsedResult();
		}
	}
	
	/**
	 * Reset.
	 */
	public void reset() {
		filter.clear();
		recordData.clear();
		headerMap.clear();
		rowNumber = 0;
		headerIndex = 0;
		record = new NtsCsvRecord(recordData, headerMap, rowNumber);
	}
	
	/**
	 * Get string.
	 * @return string
	 */
	private String getString() {
		if (bs.size() == 0) return "";
		byte[] byteArr = bs.toByteArray();
		bs.reset();
		return new String(byteArr, Charset.forName(charset));
	}
	
	@Override
	public void close() throws Exception {
		if (randomAccess != null) {
			randomAccess.close();
		}
	}
	
	/**
	 * Read filter.
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void readFilter(Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		readFilter(1000, resultConsumer, filterColumn, filterValue);
	}
	
	/**
	 * Read filter.
	 * @param step
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void readFilter(int step, Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		readFilter(step, -1, resultConsumer, filterColumn, filterValue);
	}
	
	/**
	 * Read filter.
	 * @param step
	 * @param total
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 */
	public void readFilter(int step, int total, Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue) {
		readFilter(step, total, resultConsumer, filterColumn, filterValue, CSV_READ.LOOP, 0, 0);
	}
	
	/**
	 * Read filter.
	 * @param step
	 * @param total
	 * @param resultConsumer
	 * @param filterColumn
	 * @param filterValue
	 * @param csvRead
	 * @param position
	 * @param number
	 */
	public void readFilter(int step, int total, Consumer<CSVParsedResult> resultConsumer, Object filterColumn, String filterValue, CSV_READ csvRead, int position, int number) {
		List<Line> lines;
		if (csvRead == CSV_READ.LOOP) {
			if (filter != null) {
				lines = filter.get(filterValue);
				if (lines != null) {
					lines.stream().forEach(l -> {
						readFilter(step, total, resultConsumer, filterColumn, filterValue, CSV_READ.ROW, l.position, l.number);
					});
					
					if (!result.getRecords().isEmpty() || !result.getErrors().isEmpty()) {
						resultConsumer.accept(result);
						result = new CSVParsedResult();
					}
				}
				
				return;
			}
			
			filter = new HashMap<>();
		}
		
		boolean skipHeader, filtered = false, discard = skipHeader = !headerMap.isEmpty();
		int limit = byteBuffer.limit();
		Line li = new Line(0, 0);
		byteBuffer.position(position);
		if (csvRead == CSV_READ.LOOP) {
			rowNumber = number;
		} else if (csvRead == CSV_READ.ROW) {
			rowNumber = number;
			filtered = true;
			discard = false;
		}
		
		if (filterColumn == null) {
			throw new RuntimeException("Filter column not set.");
		}
		
		for (int i = 0; i < limit; i++) {
			readByte = byteBuffer.get();
			if (readByte == quote) {
				openQuote = !openQuote;
				continue;
			}
			
			if (openQuote) {
				bs.write(readByte);
				continue;
			}
			
			if (readByte == delimiter) {
				if (rowNumber == 0) {
					if (!skipHeader) headerMap.put(headerIndex, getString());
				} else {
					String headerName = headerMap.get(headerIndex);
					String value = null;
					if (!discard) {
						value = getString();
					}
					
					if (csvRead != CSV_READ.ROW && headerName != null && ((filterColumn instanceof String && headerName.equals(filterColumn)) 
						|| (filterColumn instanceof Integer && headerIndex == (int)filterColumn))) {
						if (value != null) {
							lines = filter.get(value);
							if (lines == null) {
								lines = new ArrayList<>();
								filter.put(value, lines);
							}
							
							lines.add(li);
							if (value.equals(filterValue)) {
								filtered = true;
							} else {
								discard = true;
							}
						}
					}
					
					if (value != null) {
						recordData.put(headerName, value);
					}
				}
				
				headerIndex++;
			} else if (readByte == '\r') {
				i++;
				readByte = byteBuffer.get();
				if (readByte == '\n') {
					if (csvRead != CSV_READ.ROW) li = new Line(byteBuffer.position(), rowNumber + 1);
					if (rowNumber == 0) {
						if (!skipHeader) headerMap.put(headerIndex, getString());
					} else {
						String headerName = headerMap.get(headerIndex);
						recordData.put(headerName, getString());
					}
					
					if (filtered) {
						if (record.getRowNumber() != rowNumber) {
							record.setRowNumber(rowNumber);
						}
						
						result.addRecord(record);
					}
					
					rowNumber++;
					if (total != -1 && rowNumber > total) break;
					if (rowNumber % step == 0 && (!result.getRecords().isEmpty() || !result.getErrors().isEmpty())) {
						resultConsumer.accept(result);
						result = new CSVParsedResult();
					}
					
					headerIndex = 0;
					discard = false;
					if (filtered) {
						recordData = new HashMap<>();
						record = new NtsCsvRecord(recordData, headerMap, rowNumber);
						if (filterColumn != null) filtered = false;
					}
					
					if (csvRead == CSV_READ.ROW) return;
				}
			} else if (readByte == '\n') {
				if (csvRead != CSV_READ.ROW) li = new Line(byteBuffer.position(), rowNumber + 1);
				if (rowNumber == 0) {
					if (!skipHeader) headerMap.put(headerIndex, getString());
				} else {
					String headerName = headerMap.get(headerIndex);
					recordData.put(headerName, getString());
				}
				
				if (filtered) {
					if (record.getRowNumber() != rowNumber) {
						record.setRowNumber(rowNumber);
					}
					
					result.addRecord(record);
				}
				
				rowNumber++;
				if (total != -1 && rowNumber > total) break;
				if (rowNumber % step == 0 && (!result.getRecords().isEmpty() || !result.getErrors().isEmpty())) {
					resultConsumer.accept(result);
					result = new CSVParsedResult();
				}
				
				headerIndex = 0;
				discard = false;
				if (filtered) {
					recordData = new HashMap<>();
					record = new NtsCsvRecord(recordData, headerMap, rowNumber);
					if (filterColumn != null) filtered = false;
				}
				
				if (csvRead == CSV_READ.ROW) return;
			} else if (!discard) {
				bs.write(readByte);
			}
		}
		
		if (to < size) {
			from = bufSize;
			bufSize = Math.min(SEGMENT, size - from);
			to += bufSize;
			try {
				byteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, from, bufSize);
				readFilter(step, total, resultConsumer, filterColumn, filterValue, CSV_READ.CONT, 0, 0);
				return;
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
				
		if (!result.getRecords().isEmpty() || !result.getErrors().isEmpty()) {
			resultConsumer.accept(result);
			result = new CSVParsedResult();
		}
	} 
	
	public enum CSV_READ {
		LOOP,
		CONT,
		ROW
	}
	
	private class Line {
		private int position;
		private int number;
		
		public Line(int position, int number) {
			this.position = position;
			this.number = number;
		}
	}

}

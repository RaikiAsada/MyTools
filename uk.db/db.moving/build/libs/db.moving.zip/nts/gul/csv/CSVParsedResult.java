package nts.gul.csv;

import java.util.ArrayList;
import java.util.List;

public class CSVParsedResult {

	private final List<NtsCsvRecord> records;
	private final List<ParseCSVException> errors;

	public CSVParsedResult() {
		this.errors = new ArrayList<>();
		this.records = new ArrayList<>();
	}

	public CSVParsedResult(List<NtsCsvRecord> records) {
		this.errors = new ArrayList<>();
		this.records = new ArrayList<>(records);
	}

	public CSVParsedResult(List<NtsCsvRecord> records, List<ParseCSVException> errors) {
		this.errors = new ArrayList<>(errors);
		this.records = new ArrayList<>(records);
	}

	public void addRecord(NtsCsvRecord record) {
		this.records.add(record);
	}

	public void addRecords(List<NtsCsvRecord> record) {
		this.records.addAll(record);
	}

	public List<NtsCsvRecord> getRecords() {
		return new ArrayList<>(this.records);
	}

	public Object addError(ParseCSVException error) {
		return this.errors.add(error);
	}

	public Object addErrors(List<ParseCSVException> error) {
		return this.errors.addAll(error);
	}

	public List<ParseCSVException> getErrors() {
		return new ArrayList<>(this.errors);
	}

	public int getTotalRow() {
		return this.records.size() + this.errors.size();
	}
}

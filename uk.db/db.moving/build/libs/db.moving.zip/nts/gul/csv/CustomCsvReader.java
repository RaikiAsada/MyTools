package nts.gul.csv;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;
import org.apache.commons.lang3.StringUtils;

import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import nts.gul.util.value.MutableValue;

@Getter
@Setter
public class CustomCsvReader implements Cloneable, AutoCloseable {

	private static final char DEFAULT_STRING_SYMBOL = '"';

	private final InputStream is;

	private BufferedReader reader;

	private boolean columnDiffByRow;

	private Boolean noHeader;

	private boolean utfWithBom;

	private Integer columnConstraints;

	private boolean skipEmptyRow;

	private char delimiter;

	private Character quoteChar;

	private List<String> headers;

	private Charset charset;

	private int columnEachRow;

	private CustomCsvReader(InputStream is) {
		this.is = is;
	}

	protected static CustomCsvReader builder(InputStream is) {
		return new CustomCsvReader(is);
	}

	protected CustomCsvReader charset(Charset charset) {
		this.charset = charset;
		return this;
	}

	protected CustomCsvReader columnEachRow(int columnEachRow) {
		this.columnEachRow = columnEachRow;
		return this;
	}

	protected CustomCsvReader columnDiffByRow(boolean columnDiffByRow) {
		this.columnDiffByRow = columnDiffByRow;
		return this;
	}

	protected CustomCsvReader delimiter(char delimiter) {
		this.delimiter = delimiter;
		return this;
	}

	protected CustomCsvReader noHeader(boolean noHeader) {
		this.noHeader = noHeader;
		return this;
	}

	protected CustomCsvReader quoteChar(char quoteChar) {
		this.quoteChar = quoteChar;
		return this;
	}

	protected CustomCsvReader skipEmptyRow(boolean skipEmptyRow) {
		this.skipEmptyRow = skipEmptyRow;
		return this;
	}

	protected CustomCsvReader headers(List<String> headers) {
		this.headers = headers;
		return this;
	}

	protected CustomCsvReader utfWithBom(boolean utfWithBom) {
		this.utfWithBom = utfWithBom;
		return this;
	}

	protected CustomCsvReader columnConstraints(Integer columnConstraints) {
		this.columnConstraints = columnConstraints;
		return this;
	}

	@SneakyThrows
	public void readByStep(int step, Consumer<CSVParsedResult> actionOnEachStep) {
		readByStep(step, -1, actionOnEachStep, row -> true);
	}
	
	@SneakyThrows
	public void readByStep(int step, Consumer<CSVParsedResult> actionOnEachStep, Function<NtsCsvRecord, Boolean> customCheckRow) {
		readByStep(step, -1, actionOnEachStep, customCheckRow);
	}
	
	@SneakyThrows
	public void readByStep(int step, int totalRowForRead, Consumer<CSVParsedResult> actionOnEachStep) {
		readByStep(step, totalRowForRead, actionOnEachStep, row -> true);
	}

	@SneakyThrows
	public void readByStep(int step, int totalRowForRead, Consumer<CSVParsedResult> actionOnEachStep, 
			Function<NtsCsvRecord, Boolean> customCheckRow) {
		reader = new BufferedReader(createReader());
		Map<Integer, String> headerMap = new HashMap<>();
		List<String> headersInFile = new ArrayList<>();

		char quoteChar = getQuoteCharOrDefault();
		boolean isQuoteSameWithStringSymbol = quoteChar != DEFAULT_STRING_SYMBOL;
		String cellSeperator = String.valueOf(getDelimiter());
		
		if (!getNoHeaderOrDefault() && !this.headers.isEmpty()) {
			for (int i = 0; i < this.headers.size(); i++) {
				headerMap.put(i, this.headers.get(i));
			}

			validateHeaders(headerMap);

			headersInFile = readALine(new ArrayList<>(), new StringBuilder(), reader.readLine(), 
					quoteChar, isQuoteSameWithStringSymbol, cellSeperator);
			
			if (!headersInFile.stream().filter(h -> headers.contains(h)).findFirst().isPresent()) {
				return;
			}
		} else if (!getNoHeaderOrDefault() && this.headers.isEmpty()) {
			return;
		}

		MutableValue<Boolean> onFirstTimes = new MutableValue<Boolean>(true);
		MutableValue<Integer> rowCounter = new MutableValue<Integer>(0);
		boolean isNoHeader = getNoHeaderOrDefault();

		while (true) {
			boolean shouldReadContinue = readWithStep(step, actionOnEachStep, headerMap, rowCounter, onFirstTimes,
					headersInFile, totalRowForRead, isNoHeader, customCheckRow, quoteChar, 
					isQuoteSameWithStringSymbol, cellSeperator);
			
			if (!shouldReadContinue) {
				break;
			}
		}
	}

	@SneakyThrows
	private boolean readWithStep(int step, Consumer<CSVParsedResult> actionOnEachStep, Map<Integer, String> headerMap,
			MutableValue<Integer> rowNumber, MutableValue<Boolean> onFirstTimes, List<String> headersInFile, 
			int totalRowForRead, boolean noHeader, Function<NtsCsvRecord, Boolean> customCheckRow, char quoteChar, 
			boolean isQuoteSameWithStringSymbol, String cellSeperator) {

		CSVParsedResult resultOnStep = new CSVParsedResult();

		for (int i = 0; i < step; i++) {
			int rowBeforeProcess = resultOnStep.getTotalRow();
			if (!processARow(noHeader, onFirstTimes, headerMap, rowNumber, headersInFile, resultOnStep, 
					customCheckRow, quoteChar, isQuoteSameWithStringSymbol, cellSeperator)) {
				break;
			}

			if (totalRowForRead == rowNumber.get()) {
				break;
			}
			if(rowBeforeProcess == resultOnStep.getTotalRow()){
				i--;
			}
		}

		if (resultOnStep.getTotalRow() > 0) {
			actionOnEachStep.accept(resultOnStep);
		} else {
			return false;
		}

		if (totalRowForRead == rowNumber.get()) {
			return false;
		}

		return true;
	}

	@SneakyThrows
	private boolean processARow(boolean isNoHeader, MutableValue<Boolean> onFirstTimes, Map<Integer, String> headerMap,
			MutableValue<Integer> rowNumber, List<String> headersInFile, CSVParsedResult resultOnStep, 
			Function<NtsCsvRecord, Boolean> customCheckRow, char quoteChar, 
			boolean isQuoteSameWithStringSymbol, String cellSeperator) {
		String lineInFile = reader.readLine();
		if (lineInFile != null) {
			List<String> row = readALine(new ArrayList<>(), new StringBuilder(), lineInFile, quoteChar, 
					isQuoteSameWithStringSymbol, cellSeperator);
			
			if (row.stream().allMatch(r -> r.trim().isEmpty())) {
				if (skipEmptyRow) {
					return true;
				}
			}
			if (isNoHeader) {
				if (onFirstTimes.get() || columnDiffByRow) {
					if (row.size() > headerMap.size()) {
						for (int i = headerMap.size(); i < row.size(); i++) {
							headerMap.put(i, "Header" + i);
						}
					}
					validateHeaders(headerMap);
					onFirstTimes.set(false);
				}
			}
			processParsedRow(resultOnStep, headerMap, rowNumber, headersInFile, row, noHeader, customCheckRow);
			return true;
		}

		return false;
	}

	private void processParsedRow(CSVParsedResult resultOnStep, Map<Integer, String> headerMap, MutableValue<Integer> rowNumber,
			List<String> headersInFile, List<String> row, boolean noHeader, Function<NtsCsvRecord, Boolean> customCheckRow) {
		if (columnEachRow > 0 && columnEachRow != row.size()) {
			rowNumber.set(rowNumber.get() + 1);
			resultOnStep.addError(new InvalidColumnsSizeException(columnEachRow, rowNumber.get(), row));
		} else {
			Map<String, Object> record = new HashMap<>();
			headerMap.entrySet().stream().forEach(hm -> {
				int idxForCell = hm.getKey();
				if (!noHeader && !headersInFile.isEmpty()) {
					idxForCell = headersInFile.indexOf(hm.getValue());
				}
				if (idxForCell >= 0 && idxForCell < row.size()) {
					record.put(hm.getValue(), row.get(idxForCell));
				} else {
					record.put(hm.getValue(), "");
				}
			});
			if(customCheckRow.apply(new NtsCsvRecord(record, headerMap, rowNumber.get() + 1))){
				rowNumber.set(rowNumber.get() + 1);

				resultOnStep.addRecord(new NtsCsvRecord(record, headerMap, rowNumber.get()));
			} 
		}
	}

	@SneakyThrows
	private List<String> readALine(List<String> row, StringBuilder cell, String lineInFile, 
			char quoteChar, boolean isQuoteSameWithStringSymbol, String cellSeperator) {
		if (lineInFile == null) {
			return null;
		}
		if (!lineInFile.isEmpty()) {
			String[] tempCells = lineInFile.split(cellSeperator);
			for (int idx = 0; idx < tempCells.length; idx++) {
				cell.append(tempCells[idx]);
				String tempCell = cell.toString();
				if (shoudEndCell(tempCell.trim(), quoteChar, isQuoteSameWithStringSymbol)) {
					addNewCell(row, tempCell);
					cell = new StringBuilder();
					continue;
				}
			}
		}

		if (cell.length() > 0) {
			cell.append(System.lineSeparator());
			readALine(row, cell, reader.readLine(), 
					quoteChar, isQuoteSameWithStringSymbol, cellSeperator);
		} 

		return row;
	}

	private void addNewCell(List<String> row, String cell) {
		if (haveStrSymAtStart(cell) && haveStrSymAtEnd(cell)) {
			cell = cell.substring(1, cell.length() - 1);
		}
		row.add(cell);
	}

	private boolean shoudEndCell(String cell, char quoteChar, boolean isQuoteSameWithStringSymbol) {
		String trimedCell = cell.trim();
		if (trimedCell.isEmpty()) {
			return true;
		}

		boolean isEvenQuoted = isEvenQuoted(trimedCell, quoteChar);

		if ((isEvenQuoted && isQuoteSameWithStringSymbol)
				|| (isEvenQuoted && !isQuoteSameWithStringSymbol && isStrSymIsFit(trimedCell))) {
			return true;
		}
		return false;
	}

	private boolean isStrSymIsFit(String trimedCell) {
		boolean haveStrSymAtStart = haveStrSymAtStart(trimedCell);
		boolean haveStrSymAtEnd = haveStrSymAtEnd(trimedCell);
		return (haveStrSymAtStart && haveStrSymAtEnd) || (!haveStrSymAtStart && !haveStrSymAtEnd);
	}

	private boolean isEvenQuoted(String trimedCell, char quoteChar) {
		return StringUtils.countMatches(trimedCell, quoteChar) % 2 == 0;
	}

	private boolean haveStrSymAtEnd(String trimedCell) {
		return trimedCell.isEmpty() ? false : trimedCell.charAt(trimedCell.length() - 1) == '"';
	}

	private boolean haveStrSymAtStart(String trimedCell) {
		return trimedCell.isEmpty() ? false : trimedCell.charAt(0) == '"';
	}

	private void validateHeaders(Map<Integer, String> headerMap) {
		if (this.columnConstraints != null) {
			if ((!getNoHeaderOrDefault() && headers.size() != this.columnConstraints)
					|| (getNoHeaderOrDefault() && headerMap.size() != this.columnConstraints)) {
				throw new InvalidColumnsSizeException(this.columnConstraints, headers.size());
			}
		}
	}

	private Reader createReader() {
		Charset charset = getCharsetOrDefault();
		if (utfWithBom && charset.equals(StandardCharsets.UTF_8)) {
			return new InputStreamReader(new BOMInputStream(is, false, ByteOrderMark.UTF_8), charset);
		} else {
			return new InputStreamReader(is, charset);
		}
	}

	private boolean getNoHeaderOrDefault() {
		return noHeader == null ? headers.isEmpty() : noHeader;
	}

	private Charset getCharsetOrDefault() {
		return charset == null ? StandardCharsets.UTF_8 : charset;
	}

	private char getQuoteCharOrDefault() {
		return quoteChar == null ? '"' : quoteChar;
	}

	@Override
	public void close() throws Exception {
		if (reader != null) {
			reader.close();
		}

		if (is != null) {
			is.close();
		}
	}

}

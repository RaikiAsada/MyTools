package nts.gul.error;

import org.apache.log4j.Logger;

/**
 * FATALレベルのログ（サービス提供に致命的な障害、またはその予兆があり、至急対応を要する）を出力する
 * SLF4Jにそのメソッドが無いので、特別に実装
 */
public class FatalLog {

    public static void write(Class<?> targetClass, String message) {
        Logger logger = Logger.getLogger(targetClass);
        logger.fatal(message);
    }

    public static void write(Object targetObject, String message) {
        write(targetObject.getClass(), message);
    }

    public static RuntimeException writeThenException(Class<?> targetClass, String message) {
        write(targetClass, message);
        return new RuntimeException(message);
    }

    public static RuntimeException writeThenException(Object targetObject, String message) {
        return writeThenException(targetObject.getClass(), message);
    }
}

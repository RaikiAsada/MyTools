package nts.gul.error;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import lombok.Getter;

public class ThrowableAnalyzer {

	private final Throwable head;
	
	@Getter
	private final List<Throwable> hierarchy;
	
	public ThrowableAnalyzer(Throwable throwable) {
		
		this.head = throwable;
		this.hierarchy = new ArrayList<>();
		peelThrowable(this.head, this.hierarchy);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public <T extends Throwable> Optional<T> findByClass(Class... targetClass) {
		List<Class<T>> classes = Arrays.asList(targetClass);
		return (Optional<T>) this.hierarchy.stream()
				.filter(t -> equalsOrExtends(t, classes))
				.findFirst();
	}
	
	public Throwable root() {
		return this.hierarchy.get(this.hierarchy.size() - 1);
	}
	
	public String getStackTrace() {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		this.head.printStackTrace(pw);
		return sw.toString();
	}
	
	private static void peelThrowable(Throwable throwable, List<Throwable> hierarchy) {
		
		hierarchy.add(throwable);
		
		Throwable cause = throwable.getCause();
		if (cause == null) {
			return;
		}
		
		peelThrowable(cause, hierarchy);
	}
	
	private static <T> boolean equalsOrExtends(Object target, List<Class<T>> baseClasses) {
		return baseClasses.stream()
				.anyMatch(bc -> bc.isInstance(target));
	}
}
package nts.gul.security.hash.password;

import java.util.HashMap;
import java.util.Map;

import lombok.RequiredArgsConstructor;
import lombok.val;

public final class PasswordHash {
	
	private static final String VERSION_OF_CURRENT_GENERATOR = "1";
	
	private static final String VERSION_SEPARATER = "$";
	
	private static final Map<String, PasswordHashGenerator> GENERATORS;
	static {
		GENERATORS = new HashMap<>();
		
		// version 1
		GENERATORS.put("1", new Gen1PasswordHashGenerator());
	}

	/**
	 * Create a hashed password as string that has length 66 characters.
	 * 
	 * @param passwordPlainText plain text
	 * @param salt salt
	 * @return hashed password
	 */
	public static String generate(String passwordPlainText, String salt) {
		val hash = GENERATORS.get(VERSION_OF_CURRENT_GENERATOR).generate(passwordPlainText, salt);
		return VERSION_OF_CURRENT_GENERATOR + VERSION_SEPARATER + hash;
	}
	
	/**
	 * Verify password.
	 * When verify password, you must use this.
	 * Because password hash contains generator version so it can be matched old version hash.
	 * 
	 * @param passwordPlainTextToBeVerified password plain text to be verified
	 * @param saltToBeVerified salt to be verified
	 * @return verifier
	 */
	public static Verifier verifyThat(String passwordPlainTextToBeVerified, String saltToBeVerified) {
		return new Verifier(passwordPlainTextToBeVerified, saltToBeVerified);
	}
	
	/**
	 * Verifier
	 */
	@RequiredArgsConstructor
	public static class Verifier {
		private final String challengePasswordPlainText;
		private final String challengeSalt;
		
		/**
		 * Returns true if verified password is equal to correctPasswordHash.
		 * 
		 * @param correctPasswordHash correct password hash
		 * @return true if verified password is equal to correctPasswordHash
		 */
		public boolean isEqualTo(String correctPasswordHash) {
			return PasswordHash.generate(this.challengePasswordPlainText, this.challengeSalt)
					.equals(correctPasswordHash);
		}
	}
}

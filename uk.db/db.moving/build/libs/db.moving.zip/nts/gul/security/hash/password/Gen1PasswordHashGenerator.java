package nts.gul.security.hash.password;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import lombok.val;
import nts.gul.text.StringUtil;

class Gen1PasswordHashGenerator implements PasswordHashGenerator {
    
    /** DEFAULT_NUMBER_OF_STRETCHING */
    private static final int DEFAULT_NUMBER_OF_STRETCHING = 20000;
    
    /** DEFAULT_ALGOLITHM */
    private static final String DEFAULT_ALGOLITHM = "PBKDF2WithHmacSHA256";
    
    /** DEFAULT_LENGTH_OF_HASH */
    private static final int DEFAULT_LENGTH_OF_HASH = 256;

	@Override
	public String generate(String passwordPlainText, String salt) {
        return this.generate(
        		passwordPlainText,
        		salt,
        		DEFAULT_NUMBER_OF_STRETCHING,
        		DEFAULT_LENGTH_OF_HASH);
	}
	
    /**
     * Generate hash.
     * 
     * @param source source
     * @param salt salt (for example, use user ID as salt if generate hash of password)
     * @param numberOfStretching number of times to stretch
     * @param bitLengthOfHash length of hash [bits]
     * @return hash
     */
    public String generate(
            String source, String salt, int numberOfStretching, int bitLengthOfHash) {
        
        val factory = getSecretKeyFactory();
        val keySpec = new PBEKeySpec(
                source.toCharArray(),
                salt.getBytes(),
                numberOfStretching,
                bitLengthOfHash);
        
        SecretKey secretKey;
        try {
            secretKey = factory.generateSecret(keySpec);
        } catch (InvalidKeySpecException ex) {
            throw new RuntimeException(ex);
        }
        
        return StringUtil.asHex(secretKey.getEncoded());
    }

    /**
     * Create instance of SecretKeyFactory.
     * 
     * @return instance of SecretKeyFactory
     * @throws RuntimeException NoSuchAlgorithmException
     */
    private static SecretKeyFactory getSecretKeyFactory() throws RuntimeException {
        try {
            return SecretKeyFactory.getInstance(DEFAULT_ALGOLITHM);
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        }
    }
}

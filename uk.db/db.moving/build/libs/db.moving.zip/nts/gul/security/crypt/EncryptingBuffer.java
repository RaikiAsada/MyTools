package nts.gul.security.crypt;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Base64;


public class EncryptingBuffer {

	private final ByteArrayOutputStream cipherBuffer;
	
	public EncryptingBuffer(int sizeOfBuffer) {
		this.cipherBuffer = new ByteArrayOutputStream(sizeOfBuffer);
	}
	
	public void append(byte[] cipherData) {
		if (cipherData.length == 0) {
			return;
		}
		
		this.cipherBuffer.write(cipherData, 0, cipherData.length);
	}
	
	public String toBase64Encoded() {
        return Base64.getEncoder().encodeToString(this.toByteArray());
	}
	
	public InputStream toInputStream() {
		return new ByteArrayInputStream(this.toByteArray());
	}
	
	public byte[] toByteArray() {
		return this.cipherBuffer.toByteArray();
	}
}

package nts.gul.security.hash.password;

/**
 * Hash generator for password
 */
interface PasswordHashGenerator {

    /**
     * Generate password hash.
     * 
     * @param passwordPlainText plain text of password
     * @param salt salt (for example, use user ID as salt)
     * @return hash
     */
    String generate(String passwordPlainText, String salt);
}

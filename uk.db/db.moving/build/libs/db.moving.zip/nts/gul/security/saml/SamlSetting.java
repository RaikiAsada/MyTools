package nts.gul.security.saml;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.onelogin.saml2.settings.Saml2Settings;

import lombok.val;

// SAMLに必要な項目は現状は以下の項目
// setSpEntityId
// setIdpEntityId
// setSignatureAlgorithm
public class SamlSetting extends Saml2Settings {
	
	public final void setSPEntityId(String entityId) {
		//レルムのクライアントID
		this.setSpEntityId(entityId);
	}
	
	public final void setIDPEntityId(String entityId) {
		//レルムの認証用URL
		this.setIdpEntityId(entityId);
	}
	
	public final void setIdpx509Certificate(String strCertificate) throws UnsupportedEncodingException, IOException, CertificateException {
		
		val strCertificates = new ArrayList<String>();
		strCertificates.add("-----BEGIN CERTIFICATE-----");
		strCertificates.addAll(split(strCertificate));
		strCertificates.add("-----END CERTIFICATE-----");
		String certificate = strCertificates.stream()
				.collect(Collectors.joining(System.lineSeparator()));
				
		try(InputStream inStream = new ByteArrayInputStream(certificate.getBytes("utf-8"))){
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
		    X509Certificate cert = (X509Certificate)cf.generateCertificate(inStream);
		    List<X509Certificate> certificates = new ArrayList<X509Certificate>();
			certificates.add(cert);
			this.setIdpx509certMulti(certificates);
		}
	}
	
	private static List<String> split(String strCertificate){
		List<String> strCertificates = new ArrayList<String>();
		int index = 0;
		while (index < strCertificate.length()) {
			strCertificates.add(strCertificate.substring(index, Math.min(index + 64,strCertificate.length())));
		    index += 64;
		}
		return strCertificates;
	}
}

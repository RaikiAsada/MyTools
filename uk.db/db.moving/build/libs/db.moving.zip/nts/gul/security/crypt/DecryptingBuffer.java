package nts.gul.security.crypt;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;

import nts.gul.serialize.ObjectSerializer;

public class DecryptingBuffer {

	private final InputStream decryptedData;
	
	public DecryptingBuffer(byte[] decryptedBytes) {
		this(new ByteArrayInputStream(decryptedBytes));
	}
	
	public DecryptingBuffer(InputStream decryptedData) {
		this.decryptedData = decryptedData;
	}
	
	public InputStream toInputStream() {
		return this.decryptedData;
	}
	
	public byte[] toByteArray() {
		try {
			return IOUtils.toByteArray(this.decryptedData);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public String toPlainText() {
		return new String(this.toByteArray(), StandardCharsets.UTF_8);
	}
	
	public <T> T toObject() {
		return ObjectSerializer.<T>restore(this.toByteArray());
	}
}

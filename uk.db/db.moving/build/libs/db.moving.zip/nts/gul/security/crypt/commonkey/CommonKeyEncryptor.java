package nts.gul.security.crypt.commonkey;

import java.io.InputStream;

import nts.gul.security.crypt.DecryptingBuffer;
import nts.gul.security.crypt.EncryptingBuffer;

interface CommonKeyEncryptor {
	
	EncryptingBuffer encrypt(InputStream plainData, long byteSizeOfPlainData);

	DecryptingBuffer decrypt(String encryptedString);
	
	DecryptingBuffer decrypt(InputStream inStream, long byteSizeOfPlainData);
}

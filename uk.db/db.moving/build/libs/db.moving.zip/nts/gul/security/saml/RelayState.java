package nts.gul.security.saml;

import lombok.SneakyThrows;
import nts.gul.security.crypt.commonkey.CommonKeyCrypt;
import org.apache.commons.codec.net.URLCodec;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class RelayState {
	
	private Map<String, String> entries = new HashMap<>();
	
	public static final String URL_QUERY_KEY = "RelayState";
	private static final String PARAMS_DELIMITER = ",";
	private static final String KV_DELIMITER = ":";
	private static final URLCodec codec = new URLCodec("UTF-8");
	
	public void add(String key, String value) {
		this.entries.put(key, value);
	}

	public String get(String key) {
		return this.entries.get(key);
	}

	public String serialize() {
		String text = entries.entrySet().stream()
				.map(e -> e.getKey() + KV_DELIMITER + e.getValue())
				.collect(Collectors.joining(PARAMS_DELIMITER));
		return encodeBase64UrlSafe(CommonKeyCrypt.encrypt(text));
	}

	@SneakyThrows
	public static RelayState deserialize(HttpServletRequest request) {
		String encrypted = codec.decode(request.getParameter(URL_QUERY_KEY));
		return deserialize(encrypted);
	}
	
	public static RelayState deserialize(String encryptedRelayState) {

		String serializedRelayState = CommonKeyCrypt.decrypt(decodeBase64UrlSafe(encryptedRelayState));
	    String[] splitRelayState = serializedRelayState.split(PARAMS_DELIMITER);

		RelayState deserializedRelayState = new RelayState();
		for(int i=0; i<splitRelayState.length; i++) {
			String[] relayStateParts = splitRelayState[i].split(KV_DELIMITER);
			deserializedRelayState.add(relayStateParts[0], relayStateParts[1]);
		}
		return deserializedRelayState;
	}

	/**
	 * Base64の記号をURLセーフな記号に置換する
	 * @param originalBase64
	 * @return
	 */
	private static String encodeBase64UrlSafe(String originalBase64) {
		// + は半角スペースとのエスケープと解釈されてしまうので置換が必要
		return originalBase64
				.replaceAll("\\+", "-");
	}

	private static String decodeBase64UrlSafe(String originalBase64) {
		// + は半角スペースとのエスケープと解釈されてしまうので置換が必要
		return originalBase64
				.replaceAll("-", "\\+");
	}
}
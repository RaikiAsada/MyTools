package nts.gul.security.saml;

import javax.servlet.http.HttpServletRequest;

import com.onelogin.saml2.authn.SamlResponse;
import com.onelogin.saml2.http.HttpRequest;

import lombok.SneakyThrows;


public class SamlResponseValidator {
	
	/**
	 * SAMLによる認証結果の検証.
	 *
	 * @param request idpからのRequest
	 * @param samlSetting SAML認証の設定
	 *
	 * @return ValidSamlResponse 認証結果
	 * @exception ValidateException 不正なSamlResponseである場合にスローされる
	 * 
	 * 
	 * 
	 * ブラウザが直接Wildflyにアクセスできない環境（リバースプロキシとか）の場合、リバースプロキシに以下の設定が必要。
	 * １．Hostヘッダは書き換えない（クライアントからの値をそのまま送ること）
	 * ２．X-Forwarded-Protoを使用する（クライアントからのアクセスがhttpsかhttpか分かるようにする）
	 */
	@SneakyThrows
	public static ValidSamlResponse validate(HttpServletRequest request, SamlSetting samlSetting) throws ValidateException {
		
		// httpかhttpsなのかを判断
		String scheme = request.getHeader("X-Forwarded-Proto");
		if(scheme == null || scheme.isEmpty()) {
			scheme = "http";
		}
		// host部分を取得
		String host = request.getHeader("Host");
		// 相対パス部分を取得
		String path = request.getRequestURI();
		// 合体
		String requestURL = scheme + "://" + host + path;
		
		//こいつはどうやら使っていないようだ
		String queryString = "";
		
		HttpRequest httpRequest = new HttpRequest(requestURL, queryString).addParameter("SAMLResponse", request.getParameter("SAMLResponse"));
				
		SamlResponse samlResponse = new SamlResponse(samlSetting, httpRequest);
		
		// 検証処理
		if(!samlResponse.isValid()) {
			throw new ValidateException();
		}
		
		return new ValidSamlResponse(samlResponse);
	}
	
	/**
	 * SamlResponse.isValidはエラー原因を教えてくれない（ログに出力されるのみ）
	 * 個別のチェックメソッドはあるので、将来的にエラー原因情報が必要になったら、
	 * このValidateExceptionに情報を持たせることを想定。
	 * 今は空っぽ。
	 */
	public static class ValidateException extends Exception {

		/** serialVersionUID */
		private static final long serialVersionUID = 1L;
		
	}
}

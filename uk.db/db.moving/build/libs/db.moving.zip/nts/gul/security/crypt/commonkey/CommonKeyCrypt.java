package nts.gul.security.crypt.commonkey;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;

import nts.gul.security.crypt.DecryptingBuffer;
import nts.gul.security.crypt.EncryptingBuffer;
import nts.gul.serialize.ObjectSerializer;

public class CommonKeyCrypt {
	
	private static final CommonKeyEncryptor ENCRYPTOR = new Aes256Encryptor();
	
	public static String encrypt(String plainText) {
		return Buf.encrypt(plainText.getBytes(StandardCharsets.UTF_8)).toBase64Encoded();
	}
	
	public static String decrypt(String encryptedString) {
		return Buf.decrypt(encryptedString).toPlainText();
	}
	
	public static InputStream encrypt(InputStream streamToEncrypt, long byteSizeOfPlainData) {
		return ENCRYPTOR.encrypt(streamToEncrypt, byteSizeOfPlainData).toInputStream();
	}
	
	public static InputStream decrypt(InputStream streamToDecrypt, long byteSizeOfPlainData) {
		return Buf.decrypt(streamToDecrypt, byteSizeOfPlainData).toInputStream();
	}
	
	public static class Buf {

		public static EncryptingBuffer encrypt(byte[] bytes) {
			return ENCRYPTOR.encrypt(new ByteArrayInputStream(bytes), bytes.length);
		}
		
		public static EncryptingBuffer encrypt(Serializable obj) {
			return encrypt(ObjectSerializer.toBytes(obj));
		}

		public static DecryptingBuffer decrypt(String encryptedString) {
			return ENCRYPTOR.decrypt(encryptedString);
		}
		
		public static DecryptingBuffer decrypt(InputStream streamToDecrypt, long byteSizeOfPlainData) {
			return ENCRYPTOR.decrypt(streamToDecrypt, byteSizeOfPlainData);
		}
	}
}

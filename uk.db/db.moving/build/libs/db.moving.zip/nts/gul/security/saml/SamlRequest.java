package nts.gul.security.saml;

import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.time.OffsetDateTime;
import java.util.Base64;
import java.util.UUID;
import java.util.zip.Deflater;

import lombok.SneakyThrows;

public class SamlRequest {
	
	final String id;
	
	final String issueInstant;
	
	final String issuer;
	
	
	public SamlRequest(String issuer) {
		
		this.id = UUID.randomUUID().toString();
		this.issueInstant = OffsetDateTime.now().toString();
		this.issuer = issuer;
		
	}
	
	public String toAuthenticateUrl(String hostName, String realmName, String clientName){
		// 認証用URLの組立
		String authenticateUrl = "http://" + hostName + "/auth/realms/" + realmName + "/protocol/saml/clients/" + clientName;
        // SAMLRequestの添付
		authenticateUrl = authenticateUrl + "?" +"SAMLRequest=" + this.toUriUnescape();

		return authenticateUrl;
	}

	public String toAuthenticateUrlWithRequestUrl(String hostName, String realmName, String clientName, String requestUrl){
		// 認証用URLの組立
		String authenticateUrl = "http://" + hostName + "/auth/realms/" + realmName + "/protocol/saml/clients/" + clientName;
        // SAMLRequestの添付
		authenticateUrl = authenticateUrl + "?" +"SAMLRequest=" + this.toUriUnescape();
        // RelayStateの添付
		authenticateUrl = authenticateUrl + "&" +"RelayState=" + requestUrl;

		return authenticateUrl;
	}

	public String toXml() {
		return "<samlp:AuthnRequest"
				+ " xmlns:samlp=\"urn:oasis:names:tc:SAML:2.0:protocol"
				+ " xmlns:saml=\"urn:oasis:names:tc:SAML:2.0:assertion"
				+ " ID=" + this.id
				+ " Version=\"2.0\""
				+ " IssueInstant=" + this.issueInstant
			+ ">"
			+ "<saml:Issuer>"
				+ this.issuer
			+ "</saml:Issuer>";
	}
	
	@SneakyThrows
	public byte[] toDeflate() {
		
		byte[] dataByte = this.toXml().getBytes();
		Deflater def = new Deflater();
		def.setLevel(Deflater.BEST_COMPRESSION);
		def.setInput(dataByte);
		def.finish();
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(dataByte.length);
		byte[]buf = new byte[1024];
		while(!def.finished()) {
			int compByte = def.deflate(buf);
			byteArrayOutputStream.write(buf, 0, compByte);
		}
		byteArrayOutputStream.close();

        byte[] compData = byteArrayOutputStream.toByteArray();
		return compData;
	}
	
	public String toBase64() {
		return Base64.getEncoder().encodeToString(this.toDeflate());
	}
	
	@SneakyThrows
	public String toUriUnescape() {
		String result = URLEncoder.encode(this.toBase64(), "UTF-8");
		return result;
	}
}

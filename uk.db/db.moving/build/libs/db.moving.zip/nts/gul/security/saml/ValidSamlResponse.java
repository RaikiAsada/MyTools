package nts.gul.security.saml;

import com.onelogin.saml2.authn.SamlResponse;

import lombok.SneakyThrows;

public class ValidSamlResponse {
	
	final SamlResponse samlResponse;
	
	public ValidSamlResponse(SamlResponse samlResponse) {
		
		this.samlResponse = samlResponse;
	}
	
	public boolean isValid() {
		return this.samlResponse.isValid();
	}
	
	@SneakyThrows
	public String getIdpUser() {
		return this.samlResponse.getNameId();
	}

	
	
}

package nts.gul.security.saml;

import lombok.Data;
import lombok.SneakyThrows;
import nts.gul.text.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
public class IdpEntryUrl {

	private String url;
	
	private String relayState;
	
	private static final String PARAMS_DELIMITER = "&";
	
	private static final String NV_DELIMITER = "=";
	
	public IdpEntryUrl(String url, String relayState) {
		this.url = url;
		this.relayState = relayState;
	}
	
	@SneakyThrows
	public String createParamUrl() {
		List<String> params = new ArrayList<String>();
		if(!StringUtil.isNullOrEmpty(this.relayState, true)) {
			params.add(RelayState.URL_QUERY_KEY + NV_DELIMITER + this.relayState);
		}
		
		if(!params.isEmpty()) {
			return this.url + "?" + params.stream().collect(Collectors.joining(PARAMS_DELIMITER));
		}
		return this.url;
	}
}

package nts.gul.security.crypt.commonkey;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.IvParameterSpec;

import org.apache.commons.io.IOUtils;

/**
 * Aes256DecryptingInputStream
 * 
 * 現在の実装では、全データを一度にメモリに載せてしまっている。
 * これだと大きなファイルを扱えないので、直す必要がありそう。
 *
 */
public class Aes256DecryptingInputStream extends InputStream {

	private final InputStream encryptedSource;
	private final InputStream decryptedInputStream;
	
	public Aes256DecryptingInputStream(InputStream encryptedSource, long byteSizeOfPlainData) {
		this.encryptedSource = encryptedSource;
		this.decryptedInputStream = decrypt(encryptedSource, byteSizeOfPlainData);
	}
	
	@Override
	public int read() throws IOException {
		return this.decryptedInputStream.read();
	}
	
	@Override
	public void close() throws IOException {
		this.encryptedSource.close();
		this.decryptedInputStream.close();
	}

	private static InputStream decrypt(InputStream encryptedStream, long byteSizeOfPlainData) {
		try {
			byte[] encryptedBytes = IOUtils.toByteArray(encryptedStream); 
			// Get IV from encrypted stream
			byte[] iv = Arrays.copyOfRange(encryptedBytes, 0, Aes256Encryptor.IV_SIZE_BYTES);
			byte[] rawData = Arrays.copyOfRange(encryptedBytes, Aes256Encryptor.IV_SIZE_BYTES, encryptedBytes.length);
	
			// Decrypt file
			Cipher cipher = Aes256Encryptor.getCipher();
			cipher.init(Cipher.DECRYPT_MODE, Aes256Encryptor.createSecretKey(), new IvParameterSpec(iv));
			InputStream encryptedData = new ByteArrayInputStream(rawData);
			byte[] decryptedBytes = new byte[(int) byteSizeOfPlainData];
			int posDecryptedBytes = 0;
			
			byte[] in = new byte[64];
			int read;
			while ((read = encryptedData.read(in)) != -1) {
				byte[] output = cipher.update(in, 0, read);
				if (output != null) {
					System.arraycopy(output, 0, decryptedBytes, posDecryptedBytes, output.length);
					posDecryptedBytes += output.length;
				}
			}
	
			byte[] output = cipher.doFinal();
			if (output != null) {
				System.arraycopy(output, 0, decryptedBytes, posDecryptedBytes, output.length);
				posDecryptedBytes += output.length;
			}
			return new ByteArrayInputStream(decryptedBytes);
		} catch (InvalidAlgorithmParameterException | InvalidKeyException | IOException 
				 | BadPaddingException | IllegalBlockSizeException ex) {
			throw new RuntimeException(ex);
		}
	}
}

package nts.gul.security.crypt.commonkey;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import lombok.val;
import nts.gul.security.crypt.DecryptingBuffer;
import nts.gul.security.crypt.EncryptingBuffer;

class Aes256Encryptor implements CommonKeyEncryptor {

    static final String SECRET_KEY_STRING = "6c8d44cf32580e4c3ed359b0ac1f27df";

    static final int IV_SIZE_BYTES = 16;

	@Override
    public EncryptingBuffer encrypt(InputStream plainData, long byteSizeOfPlainData) {

		try {
			// IV generate
			byte[] iv = new byte[IV_SIZE_BYTES];
			SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
			secureRandom.nextBytes(iv);
            
            int sizeOfBuffer = ((int) (byteSizeOfPlainData / 16)) * 16 + 16 + iv.length;
            val buffer = new EncryptingBuffer(sizeOfBuffer);
	
			// Init cipher
            Cipher cipher = getCipherToEncrypt(iv);
            
            buffer.append(iv);
	
			// File encryption
			byte[] input = new byte[64];
			int bytesRead;
	
			while ((bytesRead = plainData.read(input)) != -1) {
				byte[] output = cipher.update(input, 0, bytesRead);
				
				if (output != null) {
					buffer.append(output);
				}
			}
	
			byte[] output = cipher.doFinal();
			if (output != null) {
				buffer.append(output);
			}
			
			return buffer;
			
		} catch (NoSuchAlgorithmException | IOException | IllegalBlockSizeException | BadPaddingException e) {
			throw new RuntimeException(e);
		}
    }

	@Override
	public DecryptingBuffer decrypt(String encryptedString) {
        try {
            // Base64 decode
            Base64.Decoder decoder = Base64.getDecoder();
            byte[] encryptedBytes = decoder.decode(encryptedString);

            // get IV bytes from the encrypted data
            byte[] iv = Arrays.copyOfRange(encryptedBytes, 0, IV_SIZE_BYTES);
            
            // remove IV bytes
            byte[] IVremoved = Arrays.copyOfRange(encryptedBytes, IV_SIZE_BYTES, encryptedBytes.length);

            // init cipher
            Cipher cipher = getCipherToDecrypt(iv);

            // decode
            byte[] decryptedBytes = cipher.doFinal(IVremoved);
            return new DecryptingBuffer(decryptedBytes);

        } catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new RuntimeException(e);
        }
	}
	
	
	@Override
	public DecryptingBuffer decrypt(InputStream encryptedStream, long byteSizeOfPlainData) {
		return new DecryptingBuffer(new Aes256DecryptingInputStream(encryptedStream, byteSizeOfPlainData));
	}
    
    /**
     * Create AES secret key, 256 bit
     * @return SecretKeySpec
     */
    static SecretKeySpec createSecretKey() {
        return new SecretKeySpec(SECRET_KEY_STRING.getBytes(), "AES");
    }
    
    /**
     * Returns Cipher instance to encrypt.
     * @param iv iv
     * @return Cipher
     */
    static Cipher getCipherToEncrypt(byte[] iv) {
        val cipher = getCipher();
        try {
			cipher.init(Cipher.ENCRYPT_MODE, createSecretKey(), new IvParameterSpec(iv));
		} catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
			throw new RuntimeException(e);
		}
        return cipher;
    }
    
    /**
     * Returns Cipher instance to decrypt.
     * @param iv iv
     * @return Cipher
     */
    static Cipher getCipherToDecrypt(byte[] iv) {
        val cipher = getCipher();
        try {
            cipher.init(Cipher.DECRYPT_MODE, createSecretKey(), new IvParameterSpec(iv));
		} catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
			throw new RuntimeException(e);
		}
        return cipher;
    }
    
    /**
     * Cipher AES, CBC, 128 bit Block
     * @return Cipher
     */
    static Cipher getCipher() {
        Cipher cipher;
        try {
            cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException ex) {
            throw new RuntimeException(ex);
        }
        
        return cipher;
    }
}

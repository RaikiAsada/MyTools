package nts.gul.time.secondsbased;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import lombok.Getter;
import nts.gul.text.StringUtil;

public class SecondsBasedTimeParser {
	
	public static Result parse(String source) {

		if (source.contains(":")) {
			String[] parts = source.split(":");

			// not format "h:m"
			if (parts.length != 3) {
				return Result.failed();
			}

			// minute part and second part must be 2-digit
			if (parts[1].length() != 2 && parts[2].length() != 2) {
				return Result.failed();
			}

			// pattern "h+mm+ss"
			return parse(parts[0] + parts[1] + parts[2]);
		}

		boolean isNegative = source.indexOf('-') == 0;
		String sourceDigitsOnly = isNegative ? source.substring(1) : source;

		if (!NumberUtils.isDigits(sourceDigitsOnly)) {
			return Result.failed();
		}

		return parse(Integer.parseInt(sourceDigitsOnly));
	}

	/** format HHmmss*/
	public static Result parse(int source) {
		boolean isNegative = source < 0;

		int regularized = Math.abs(source);
		int secondPart = regularized % 100;
		int hourPart = regularized / 10000;
		int minutePart = regularized % 10000;

		if (minutePart >= 60) {
			return Result.failed();
		}

		return Result.succeeded(isNegative, hourPart, minutePart, secondPart);
	}
	
	/** parse from seconds value base 60  (HH*60*60 + mm*60 + ss)*/
	public static Result fromSeconds(int source) {
		boolean isNegative = source < 0;

		int regularized = Math.abs(source);
		int secondPart = regularized % 60;
		int minuteBase = regularized / 60;
		int hourPart = minuteBase / 60;
		int minutePart = minuteBase % 60;

		return Result.succeeded(isNegative, hourPart, minutePart, secondPart);
	}

	public static class Result {
		@Getter
		private final boolean isSuccess;
		private final boolean isNegative;
		private final int hourPart;
		private final int minutePart;
		private final int secondPart;

		private Result(boolean isSuccess, boolean isNegative, int hourPart, int minutePart, int secondPart) {
			this.isSuccess = isSuccess;
			this.isNegative = isNegative;
			this.hourPart = hourPart;
			this.minutePart = minutePart;
			this.secondPart = secondPart;
		}

		public static Result succeeded(boolean isNegative, int hourPart, int minutePart, int secondPart) {
			return new Result(true, isNegative, hourPart, minutePart, secondPart);
		}

		public static Result failed() {
			return new Result(false, false, 0, 0, 0);
		}

		public int asDuration() {
			if (!this.isSuccess) {
				throw new RuntimeException("failed");
			}

			return (this.isNegative ? -1 : 1) * (this.hourPart * 60 + this.minutePart*60 + this.secondPart);
		}

		public String format() {
			if (!this.isSuccess) {
				throw new RuntimeException("failed");
			}
			;
			return StringUtils.join(this.isNegative ? "-" : "", String.valueOf(this.hourPart * 60), ":",
															StringUtil.padLeft(String.valueOf(this.minutePart), 2, '0'), ":", 
															StringUtil.padLeft(String.valueOf(this.secondPart), 2, '0'));
		}
	}
}

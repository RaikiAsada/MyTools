package nts.gul.time;

public class DateTimeUtil {

	public static class DayOfWeek {
		
		public static int toLegacyCalendarValue(java.time.DayOfWeek dayOfWeek) {
			return (dayOfWeek.getValue() % 7) + 1;
		}
	}
}
